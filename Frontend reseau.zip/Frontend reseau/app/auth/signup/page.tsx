// app/auth/signup/page.tsx
'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';

export default function SignupPage() {
    const [userType, setUserType] = useState<'individual' | 'company'>('individual');

    return (
        <div className="auth-page">
            <div className="auth-card auth-staggered" style={{ maxWidth: '600px' }}>
                <div style={{ marginBottom: '20px' }}>
                    <Link href="/" style={{ color: '#666', fontSize: '0.9em', display: 'flex', alignItems: 'center', gap: '5px', textDecoration: 'none' }}>
                        <i className="fas fa-arrow-left"></i> Retour
                    </Link>
                </div>

                <div style={{ textAlign: 'center', marginBottom: '15px' }}>
                    <Image src="/images/logo.jpg" alt="Logo Yowyob" width={60} height={60} style={{ borderRadius: '50%', objectFit: 'cover' }} />
                </div>

                <div className="auth-header">
                    <h2>Inscription</h2>
                </div>

                <div className="user-type-toggle">
                    <button
                        type="button"
                        onClick={() => setUserType('individual')}
                        className={`toggle-btn ${userType === 'individual' ? 'active' : ''}`}
                    >
                        Individu
                    </button>
                    <button
                        type="button"
                        onClick={() => setUserType('company')}
                        className={`toggle-btn ${userType === 'company' ? 'active' : ''}`}
                    >
                        Entreprise
                    </button>
                </div>

                <form className="auth-staggered">
                    <div className="auth-form-grid">
                        <div className="auth-form-group full-width">
                            <label>
                                {userType === 'individual' ? 'Nom complet' : 'Nom de l\'entreprise'}
                            </label>
                            <input
                                type="text"
                                className="auth-form-control"
                            />
                        </div>

                        <div className="auth-form-group">
                            <label>Email</label>
                            <input
                                type="email"
                                className="auth-form-control"
                            />
                        </div>

                        <div className="auth-form-group">
                            <label>Téléphone</label>
                            <input
                                type="tel"
                                className="auth-form-control"
                            />
                        </div>

                        <div className="auth-form-group full-width">
                            <label>Domaine d'activités</label>
                            <input
                                type="text"
                                className="auth-form-control"
                                placeholder="Ex: Informatique, Commerce, Santé..."
                            />
                        </div>

                        {/* Champs conditionnels */}
                        {userType === 'company' ? (
                            <>
                                <div className="auth-form-group">
                                    <label>Localisation</label>
                                    <input
                                        type="text"
                                        className="auth-form-control"
                                    />
                                </div>
                                <div className="auth-form-group">
                                    <label>Logo</label>
                                    <input
                                        type="file"
                                        className="auth-form-control"
                                        style={{ background: 'white' }}
                                    />
                                </div>
                            </>
                        ) : (
                            <>
                                <div className="auth-form-group">
                                    <label>Profession</label>
                                    <input
                                        type="text"
                                        className="auth-form-control"
                                    />
                                </div>
                                <div className="auth-form-group">
                                    <label>Photo de profil</label>
                                    <input
                                        type="file"
                                        className="auth-form-control"
                                        style={{ background: 'white' }}
                                    />
                                </div>
                            </>
                        )}

                        <div className="auth-form-group full-width">
                            <label>Mot de passe</label>
                            <input
                                type="password"
                                className="auth-form-control"
                            />
                        </div>

                    </div>

                    <button type="submit" className="btn btn-primary" style={{ width: '100%', padding: '12px', marginTop: '10px', fontSize: '1.1em' }}>
                        S'inscrire
                    </button>
                </form>

                <div style={{ marginTop: '25px', textAlign: 'center', fontSize: '0.95em' }}>
                    Déjà un compte ? <Link href="/auth/login" style={{ fontWeight: 'bold' }}>Se connecter</Link>
                </div>
            </div>
        </div>
    );
}
