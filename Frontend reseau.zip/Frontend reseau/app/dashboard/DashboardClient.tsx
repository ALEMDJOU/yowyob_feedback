"use client";

import React, { useState, useEffect } from 'react';
import FeedSidebar from '@/components/FeedSidebar';
import MagicPageEnhancer from '@/components/MagicPageEnhancer';
import '../feed.css';

export default function DashboardClient({ children }: { children: React.ReactNode }) {
    const [isCollapsed, setIsCollapsed] = useState(false);

    useEffect(() => {
        // Auto-collapse on mobile by default
        const handleResize = () => {
            if (window.innerWidth <= 768) {
                setIsCollapsed(true);
            } else {
                setIsCollapsed(false);
            }
        };

        // Set initial state
        handleResize();

        window.addEventListener('resize', handleResize);
        return () => window.removeEventListener('resize', handleResize);
    }, []);

    const toggleSidebar = () => {
        setIsCollapsed(!isCollapsed);
    };

    return (
        <MagicPageEnhancer>
            <div className="dashboard-container">
                <FeedSidebar isCollapsed={isCollapsed} toggleSidebar={toggleSidebar} />

                <main className="main-content">
                    <div className="mobile-dashboard-header">
                        <button
                            id="toggleSidebar"
                            className="sidebar-toggle"
                            onClick={toggleSidebar}
                            aria-label="Toggle Sidebar"
                        >
                            <i className="fas fa-bars"></i>
                        </button>
                        <span className="app-name-mobile">Yowyob</span>
                    </div>

                    <button
                        className="sidebar-toggle desktop-toggle"
                        onClick={toggleSidebar}
                        aria-label="Toggle Sidebar"
                    >
                        <i className="fas fa-bars"></i>
                    </button>

                    {children}
                </main>
            </div>
        </MagicPageEnhancer>
    );
}
