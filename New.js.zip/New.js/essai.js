var link = document.getElementById("myLink");
var href = link.getAttribute("href"); // on recupere la valeur du lien
document.getElementById("myLink").innerHTML = "my name is fofack Alemdjou henri joel";
var linky = link.parentNode;
alert(linky);