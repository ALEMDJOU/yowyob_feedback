// =========================================
// YOWYOB FEEDBACK - DASHBOARD ENTREPRISES
// =========================================

'use strict';

document.addEventListener('DOMContentLoaded', () => {
    initSidebarToggle();
    initAddCompanyMenu();
    initScrollAnimations(); // IMPORTANT : Pour les animations des entreprises
});

/**
 * Gère la rétractation/expansion de la sidebar.
 */
function initSidebarToggle() {
    // Utilise l'ID et la classe du bouton dans companies.html
    const toggleBtn = document.getElementById('sidebar-toggle-btn'); 
    const layout = document.querySelector('.dashboard-layout');

    if (!toggleBtn || !layout) return;

    toggleBtn.addEventListener('click', () => {
        // Ajoute ou supprime la classe 'collapsed' pour basculer le mode
        layout.classList.toggle('collapsed');
        
        // L'icône reste fa-bars, comme demandé.
    });
}

/**
 * Gère le menu déroulant "Ajouter une entreprise".
 */
function initAddCompanyMenu() {
    const addButton = document.getElementById('add-company-btn');
    const menu = document.getElementById('add-company-menu');

    if (!addButton || !menu) return;

    // Toggle le menu au clic sur le bouton
    addButton.addEventListener('click', (event) => {
        event.stopPropagation();
        menu.classList.toggle('visible');
    });

    // Cacher le menu si l'utilisateur clique n'importe où ailleurs
    document.addEventListener('click', (event) => {
        if (menu.classList.contains('visible') && !menu.contains(event.target) && event.target !== addButton) {
            menu.classList.remove('visible');
        }
    });
}

/**
 * Gère l'animation des éléments de la liste des entreprises au défilement
 * en utilisant l'API IntersectionObserver et la classe .animate-on-scroll.
 */
function initScrollAnimations() {
    const elements = document.querySelectorAll('.animate-on-scroll');
    if (elements.length === 0) return;

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                // Ajoute la classe 'visible' pour déclencher l'animation 'fadeInUp' (définie dans animations.css)
                entry.target.classList.add('visible');
                observer.unobserve(entry.target); // Arrête l'observation après la première animation
            }
        });
    }, {
        rootMargin: '0px',
        threshold: 0.1 // Déclenchement quand 10% de l'élément est visible
    });

    elements.forEach(element => {
        observer.observe(element);
    });
}