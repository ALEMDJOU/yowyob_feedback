/**
 * Dashboard Logic - Version Moderne & Optimisée
 */

const DashboardApp = {
    init() {
        this.cacheDOM();
        this.bindEvents();
        this.scrollToBottom();
    },

    cacheDOM() {
        this.menuItems = document.querySelectorAll('.wa-item');
        this.contentArea = document.getElementById('contentArea');
        this.searchInput = document.getElementById('searchInput');
        this.mainTitle = document.getElementById('currentTitle');
        this.mainAvatar = document.getElementById('currentAvatar');
    },

    bindEvents() {
        // Navigation au clic
        this.menuItems.forEach(item => {
            item.addEventListener('click', (e) => {
                this.handleMenuClick(item, e);
            });
        });

        // Barre de recherche (Filtre)
        this.searchInput.addEventListener('input', (e) => {
            this.filterMenu(e.target.value);
        });
    },

    // Effet "Ripple" (Vague) style Material Design
    createRipple(event, element) {
        const circle = document.createElement("span");
        const diameter = Math.max(element.clientWidth, element.clientHeight);
        const radius = diameter / 2;

        circle.style.width = circle.style.height = `${diameter}px`;
        circle.style.left = `${event.clientX - element.getBoundingClientRect().left - radius}px`;
        circle.style.top = `${event.clientY - element.getBoundingClientRect().top - radius}px`;
        circle.classList.add("ripple");

        const ripple = element.getElementsByClassName("ripple")[0];

        if (ripple) {
            ripple.remove();
        }

        element.appendChild(circle);
    },

    handleMenuClick(item, event) {
        // 1. Déclencher l'effet Ripple
        this.createRipple(event, item);

        // 2. Gestion de la classe Active
        this.menuItems.forEach(i => i.classList.remove('active'));
        item.classList.add('active');

        // 3. Mise à jour de l'interface (Header droit)
        const name = item.querySelector('.wa-name').innerText;
        const iconHtml = item.querySelector('.wa-item-avatar').innerHTML;
        const colorClass = item.querySelector('.wa-item-avatar').classList[1] || ''; // Garder la couleur

        this.animateHeaderChange(name, iconHtml, colorClass);
    },

    animateHeaderChange(name, iconHtml, colorClass) {
        // Simple fade out/in pour le titre
        this.mainTitle.style.opacity = '0';
        
        setTimeout(() => {
            // Mise à jour du texte
            this.mainTitle.innerText = name;
            
            // Mise à jour de l'icône et sa couleur
            this.mainAvatar.innerHTML = iconHtml;
            this.mainAvatar.className = 'wa-item-avatar'; // Reset classes
            if (colorClass) this.mainAvatar.classList.add(colorClass);

            this.mainTitle.style.opacity = '1';
        }, 200);
    },

    filterMenu(searchText) {
        const term = searchText.toLowerCase();
        this.menuItems.forEach(item => {
            const name = item.querySelector('.wa-name').innerText.toLowerCase();
            if (name.includes(term)) {
                item.style.display = 'flex';
            } else {
                item.style.display = 'none';
            }
        });
    },

    scrollToBottom() {
        this.contentArea.scrollTop = this.contentArea.scrollHeight;
    }
};

// Lancement de l'application au chargement
document.addEventListener('DOMContentLoaded', () => {
    DashboardApp.init();
});