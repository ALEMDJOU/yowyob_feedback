// Effets au scroll + header transparent
window.addEventListener('scroll', () => {
  const header = document.querySelector('.header');
  if (window.scrollY > 100) {
    header.style.background = 'rgba(15, 15, 26, 0.98)';
    header.style.padding = '1rem 5%';
  } else {
    header.style.background = 'rgba(15, 15, 26, 0.95)';
    header.style.padding = '1.5rem 5%';
  }
});

// Animation progressive des cartes au scroll
const observerOptions = {
  threshold: 0.1,
  rootMargin: '0px 0px -100px 0px'
};

const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.style.opacity = '1';
      entry.target.style.transform = 'translateY(0)';
    }
  });
}, observerOptions);

document.querySelectorAll('.feature-card').forEach(card => {
  card.style.opacity = '0';
  card.style.transform = 'translateY(40px)';
  card.style.transition = 'all 0.8s ease';
  observer.observe(card);
});