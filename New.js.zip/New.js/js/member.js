'use strict';

document.addEventListener('DOMContentLoaded', () => {
    // 1. Rétractation de la Sidebar
    const sidebar = document.getElementById('sidebar');
    const toggleBtn = document.getElementById('sidebar-toggle-btn');

    if (toggleBtn && sidebar) {
        // Ajout du bouton "barres" pour la rétractation
        toggleBtn.addEventListener('click', () => {
            sidebar.classList.toggle('collapsed');
        });
    }

    // 2. Gestion de la Modale de Suppression
    const deleteModal = document.getElementById('delete-modal-overlay');
    const closeBtn = deleteModal.querySelector('.close-modal-btn');
    const cancelBtn = deleteModal.querySelector('.btn-cancel');
    const deleteIcons = document.querySelectorAll('.delete-icon');
    const memberToDeleteSpan = document.getElementById('member-to-delete');

    function openModal(memberName) {
        memberToDeleteSpan.textContent = memberName;
        deleteModal.classList.add('show');
        document.body.style.overflow = 'hidden'; // Empêche le défilement du corps
    }

    function closeModal() {
        deleteModal.classList.remove('show');
        document.body.style.overflow = ''; // Rétablit le défilement
    }

    // Ouvre la modale lorsqu'on clique sur l'icône de suppression
    deleteIcons.forEach(icon => {
        icon.addEventListener('click', (e) => {
            const memberName = e.currentTarget.getAttribute('data-member-name');
            openModal(memberName);
        });
    });

    // Fermeture par le bouton 'X' et 'Annuler'
    closeBtn.addEventListener('click', closeModal);
    cancelBtn.addEventListener('click', closeModal);

    // Fermeture par clic en dehors de la modale
    deleteModal.addEventListener('click', (e) => {
        if (e.target === deleteModal) {
            closeModal();
        }
    });

    // Optionnel : Gérer la suppression définitive ici (pourrait être une requête AJAX)
    const confirmDeleteBtn = deleteModal.querySelector('.btn-delete-confirm');
    confirmDeleteBtn.addEventListener('click', () => {
        alert(`Suppression de ${memberToDeleteSpan.textContent} confirmée ! (Ceci est un prototype)`);
        closeModal();
    });
});