'use strict';

// Configuration
const CONFIG = {
    scrollThreshold: 0.15
};

document.addEventListener('DOMContentLoaded', () => {
    initScrollAnimations();
    init3DEffects();
});

// ========================================
// ANIMATIONS AU SCROLL
// ========================================

function initScrollAnimations() {
    const observerOptions = {
        threshold: CONFIG.scrollThreshold,
        rootMargin: '0px 0px -100px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const delay = entry.target.dataset.delay || 0;
                setTimeout(() => {
                    entry.target.classList.add('visible');
                }, delay);
                // Optional: Stop observing once visible if you don't want re-animation
                // observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    // Observer les éléments à animer
    const elementsToAnimate = document.querySelectorAll('.animate-on-scroll');
    elementsToAnimate.forEach(el => observer.observe(el));

    // Observer les titres de section
    const sectionTitles = document.querySelectorAll('.section-title');
    sectionTitles.forEach(title => observer.observe(title));
}

// ========================================
// EFFETS 3D SUR LES BOXES
// ========================================

function init3DEffects() {
    const boxes = document.querySelectorAll('.step-item');

    boxes.forEach(box => {
        box.addEventListener('mousemove', (e) => {
            const rect = box.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;

            const centerX = rect.width / 2;
            const centerY = rect.height / 2;

            const rotateX = (y - centerY) / 10;
            const rotateY = (centerX - x) / 10;

            box.style.transform = `
                perspective(1000px)
                translateZ(30px)
                rotateX(${rotateX}deg)
                rotateY(${rotateY}deg)
                scale(1.05)
            `;
        });

        box.addEventListener('mouseleave', () => {
            box.style.transform = 'perspective(1000px) translateZ(0) rotateX(0) rotateY(0) scale(1)';
        });
    });
}
