// =========================================
// YOWYOB FEEDBACK - DASHBOARD INTERACTIVITY
// =========================================

'use strict';

document.addEventListener('DOMContentLoaded', () => {
    initAddProjectMenu();
    initHamburgerMenu();
});

function initAddProjectMenu() {
    const addButton = document.getElementById('add-project-btn');
    const menu = document.getElementById('add-project-menu');

    if (!addButton || !menu) return;

    // Toggle le menu au clic sur le bouton
    addButton.addEventListener('click', (event) => {
        event.stopPropagation(); // Empêche l'événement de se propager au document
        menu.classList.toggle('visible');
    });

    // Cacher le menu si l'utilisateur clique n'importe où ailleurs
    document.addEventListener('click', (event) => {
        if (menu.classList.contains('visible') && !menu.contains(event.target) && event.target !== addButton) {
            menu.classList.remove('visible');
        }
    });

    // Gérer l'action de création/jonction (à compléter côté serveur)
    document.getElementById('create-project-link').addEventListener('click', (event) => {
        event.preventDefault();
        alert("Action: Créer un nouveau projet (Redirection vers le formulaire)");
        menu.classList.remove('visible');
    });

    document.getElementById('join-project-link').addEventListener('click', (event) => {
        event.preventDefault();
        alert("Action: Joindre un projet existant (Affichage d'un modal de recherche/code)");
        menu.classList.remove('visible');
    });
}

function initHamburgerMenu() {
    const hamburgerBtn = document.getElementById('hamburger-btn');
    const closeSidebarBtn = document.getElementById('close-sidebar');
    const sidebar = document.getElementById('main-sidebar');
    const overlay = document.getElementById('sidebar-overlay');
    const mainContent = document.querySelector('.main-content');

    if (!hamburgerBtn || !sidebar) return;

    // Ouvrir le menu hamburger
    hamburgerBtn.addEventListener('click', () => {
        sidebar.classList.add('mobile-active');
        overlay.classList.add('active');
        document.body.style.overflow = 'hidden'; // Empêcher le défilement de la page
    });

    // Fermer le menu avec le bouton de fermeture
    if (closeSidebarBtn) {
        closeSidebarBtn.addEventListener('click', closeSidebar);
    }

    // Fermer le menu avec l'overlay
    overlay.addEventListener('click', closeSidebar);

    // Fermer le menu en appuyant sur la touche Échap
    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && sidebar.classList.contains('mobile-active')) {
            closeSidebar();
        }
    });

    // Fermer le menu en cliquant sur un lien dans la sidebar
    const sidebarLinks = sidebar.querySelectorAll('a');
    sidebarLinks.forEach(link => {
        link.addEventListener('click', () => {
            // Petit délai pour permettre la navigation avant de fermer
            setTimeout(closeSidebar, 300);
        });
    });

    function closeSidebar() {
        sidebar.classList.remove('mobile-active');
        overlay.classList.remove('active');
        document.body.style.overflow = ''; // Rétablir le défilement
    }

    // Fermer automatiquement le menu lors du redimensionnement si on repasse en desktop
    window.addEventListener('resize', () => {
        if (window.innerWidth > 1024 && sidebar.classList.contains('mobile-active')) {
            closeSidebar();
        }
    });
}