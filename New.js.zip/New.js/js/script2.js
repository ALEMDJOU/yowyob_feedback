// =========================================
// YOWYOB FEEDBACK - ANIMATIONS MODERNES
// =========================================

'use strict';

// Configuration
const CONFIG = {
    particleCount: 80,
    scrollThreshold: 0.15,
    animationDelay: 150
};

// =========================================
// INITIALISATION
// =========================================

document.addEventListener('DOMContentLoaded', () => {
    initParticles();
    initScrollAnimations();
    initModal();
    initSmoothScroll();
    initNavbarScroll();
    initParallax();
    initHeroAnimation();
    init3DEffects();
});

// =========================================
// SYSTÈME DE PARTICULES
// =========================================

function initParticles() {
    const particlesContainer = document.getElementById('particles');
    if (!particlesContainer) return;

    for (let i = 0; i < CONFIG.particleCount; i++) {
        createParticle(particlesContainer);
    }
}

function createParticle(container) {
    const particle = document.createElement('div');
    particle.className = 'particle';
    
    // Position aléatoire
    const startX = Math.random() * 100;
    const drift = (Math.random() - 0.5) * 100;
    const duration = 10 + Math.random() * 20;
    const delay = Math.random() * 10;
    
    // Taille et couleur
    const size = 5 + Math.random() * 5;
    const colors = ['#6A1B9A', '#8E24AA', '#CE93D8'];
    
    particle.style.width = `${size}px`;
    particle.style.height = `${size}px`;
    particle.style.background = colors[Math.floor(Math.random() * colors.length)];
    particle.style.left = `${startX}vw`;
    
    container.appendChild(particle);
    
    // Animation CSS personnalisée pour le mouvement
    particle.animate([
        { transform: `translateY(0) translateX(0)`, opacity: 0.8 },
        { transform: `translateY(100vh) translateX(${drift}vw)`, opacity: 0 }
    ], {
        duration: duration * 1000,
        delay: delay * 1000,
        iterations: Infinity,
        easing: 'linear'
    });
}

// =========================================
// SCROLL ET ANIMATIONS
// =========================================

function initScrollAnimations() {
    const observer = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const delay = entry.target.getAttribute('data-delay') || 0;
                setTimeout(() => {
                    entry.target.classList.add('is-visible');
                }, delay);
                observer.unobserve(entry.target);
            }
        });
    }, {
        rootMargin: '0px',
        threshold: CONFIG.scrollThreshold
    });

    document.querySelectorAll('.animate-on-scroll').forEach(element => {
        observer.observe(element);
    });
}

function initSmoothScroll() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });
}

function initNavbarScroll() {
    const navbar = document.querySelector('.navbar');
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    });
}

function initParallax() {
    const hero = document.querySelector('.hero-section');
    if (!hero) return;
    window.addEventListener('scroll', () => {
        const scrolled = window.scrollY;
        // Déplace le contenu du héros légèrement moins vite que le défilement
        hero.querySelector('.container').style.transform = `translateY(${scrolled * 0.3}px)`;
        // Déplace les particules légèrement
        hero.querySelector('#particles').style.transform = `translateY(${scrolled * 0.1}px)`;
    });
}

function initHeroAnimation() {
    // Révélation de texte pour le H1 (animation dans animations.css)
    const h1 = document.querySelector('.hero-content h1');
    if (h1) {
        h1.style.animation = 'textReveal 2s forwards';
    }

    // Fade-in pour le reste du contenu du héros
    document.querySelectorAll('.hero-content > *:not(h1)').forEach((el, index) => {
        el.style.animation = `fadeInUp 1s ease-out forwards ${1.5 + index * 0.3}s`;
        el.style.opacity = 0;
    });
}

function init3DEffects() {
    document.querySelectorAll('.feature-item, .step-item').forEach(card => {
        card.addEventListener('mousemove', (e) => {
            const rect = card.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            const centerX = rect.width / 2;
            const centerY = rect.height / 2;
            const rotateX = ((y - centerY) / centerY) * 10; // Inclinaison max 10 deg
            const rotateY = ((x - centerX) / centerX) * -10; // Inclinaison max -10 deg
            
            card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale(1.03)`;
        });
        
        card.addEventListener('mouseleave', () => {
            card.style.transform = 'perspective(1000px) rotateX(0) rotateY(0) scale(1)';
        });
    });
}


// =========================================
// MODALE ET CONNEXION
// =========================================

function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification ${type} fade-in`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // Animation de disparition
    setTimeout(() => {
        notification.classList.add('fade-out');
        notification.addEventListener('animationend', () => notification.remove());
    }, 3000);
}


function initModal() {
    const loginBtn = document.getElementById('loginBtn');
    const loginModal = document.getElementById('loginModal');
    const closeModalBtn = loginModal ? loginModal.querySelector('.close-modal-btn') : null;
    
    if (loginBtn && loginModal) {
        loginBtn.addEventListener('click', (e) => {
            e.preventDefault();
            loginModal.classList.add('show');
            document.body.style.overflow = 'hidden'; // Empêcher le défilement du corps
        });
    }

    if (closeModalBtn) {
        closeModalBtn.addEventListener('click', () => {
            loginModal.classList.remove('show');
            document.body.style.overflow = '';
        });
    }

    if (loginModal) {
        loginModal.addEventListener('click', (e) => {
            if (e.target === loginModal) {
                loginModal.classList.remove('show');
                document.body.style.overflow = '';
            }
        });
    }
    
    // Gestionnaire de soumission du formulaire de connexion
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Simuler la connexion et la redirection
            showNotification('Connexion réussie ! Redirection...', 'success');
            
            // Masquer la modale
            loginModal.classList.remove('show');

            // Redirection vers la nouvelle page d'accueil après un court délai
            setTimeout(() => {
                window.location.href = 'home-auth.html'; // <<< MODIFICATION ICI
            }, 1500); // Délai de 1.5 secondes pour que l'utilisateur lise la notification
        });
    }
}


// =========================================
// EASTER EGG (Optionnel)
// =========================================

let clickCount = 0;
const logo = document.querySelector('.navbar .logo img');

if (logo) {
    logo.addEventListener('click', () => {
        clickCount++;
        if (clickCount >= 7) {
            createConfetti();
            showNotification('🎉 Vous avez trouvé l\'easter egg !', 'success');
            clickCount = 0;
        }
    });
}
