document.addEventListener('DOMContentLoaded', () => {
    const modals = {
        login: document.getElementById('loginModal'),
        register: document.getElementById('registerModal'),
        forgot: document.getElementById('forgotModal')
    };

    const closeAll = () => Object.values(modals).forEach(m => m.classList.remove('active'));

    // Ouvrir depuis la navbar (ajuste les ID si nécessaire)
    document.getElementById('loginBtn').onclick = () => { closeAll(); modals.login.classList.add('active'); };

    // Switcher entre les formulaires
    document.getElementById('toRegister').onclick = (e) => { e.preventDefault(); closeAll(); modals.register.classList.add('active'); };
    document.getElementById('backToLogin').onclick = (e) => { e.preventDefault(); closeAll(); modals.login.classList.add('active'); };
    document.getElementById('toForgot').onclick = (e) => { e.preventDefault(); closeAll(); modals.forgot.classList.add('active'); };
    document.getElementById('forgotBackToLogin').onclick = (e) => { e.preventDefault(); closeAll(); modals.login.classList.add('active'); };

    // Fermeture
    document.querySelectorAll('[data-close]').forEach(btn => btn.onclick = closeAll);
    window.onclick = (e) => { if(e.target.classList.contains('modal-overlay')) closeAll(); };
});
