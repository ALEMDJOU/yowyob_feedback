
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { OrganizationJsonLd, WebsiteJsonLd } from '@/components/JsonLd';
import React from 'react';
import type { Metadata } from 'next';

export const metadata: Metadata = {
    title: 'Accueil - Feedbacks authentiques sur stages et formations',
    description: 'Découvrez des feedbacks authentiques sur les stages, formations et expériences professionnelles. Rejoignez des milliers d\'étudiants et professionnels pour partager vos avis.',
    openGraph: {
        title: 'Yowyob Feedback - Accueil',
        description: 'Feedbacks authentiques sur les stages et formations',
        images: ['/images/og-home.jpg'],
    },
};

export default function MarketingLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    return (
        <>
            <OrganizationJsonLd />
            <WebsiteJsonLd />
            <Header />
            <main>
                {children}
            </main>
            <Footer />
        </>
    );
}
