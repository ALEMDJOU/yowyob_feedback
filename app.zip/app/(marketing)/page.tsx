// app/page.tsx
import LandingPage from '@/components/LandingPage';

export default function Home() {
  return (
    <main>
      <LandingPage />
    </main>
  );
}