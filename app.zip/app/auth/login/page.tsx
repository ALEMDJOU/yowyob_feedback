// app/auth/login/page.tsx
"use client";

import React, { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import { useTranslation } from '@/components/I18nProvider';

export default function LoginPage() {
  const { t } = useTranslation();
  const router = useRouter();
  const [showPassword, setShowPassword] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Rediriger vers le dashboard après la connexion
    router.push('/dashboard/feed');
  };

  return (
    <div className="auth-page">
      <div className="auth-card auth-staggered">
        <div style={{ marginBottom: '20px' }}>
          <Link href="/" style={{ color: '#666', fontSize: '0.9em', display: 'flex', alignItems: 'center', gap: '5px', textDecoration: 'none' }} title="Retour à l'accueil">
            <i className="fas fa-arrow-left"></i>
          </Link>
        </div>

        <div style={{ textAlign: 'center', marginBottom: '15px' }}>
          <Image src="/images/logo.jpg" alt="Logo Yowyob" width={60} height={60} style={{ borderRadius: '50%', objectFit: 'cover' }} />
        </div>

        <div className="auth-header">
          <h2>{t('header.login')}</h2>
        </div>

        <form className="auth-staggered" onSubmit={handleSubmit}>
          <div className="auth-form-group">
            <label htmlFor="email">Email</label>
            <div className="auth-input-wrapper">
              <i className="fas fa-envelope input-icon"></i>
              <input
                type="email"
                id="email"
                className="auth-form-control"
                placeholder="votre@email.com"
              />
            </div>
          </div>

          <div className="auth-form-group">
            <label htmlFor="password">{t('auth.password')}</label>
            <div className="auth-input-wrapper password-wrapper">
              <i className="fas fa-lock input-icon"></i>
              <input
                type={showPassword ? "text" : "password"}
                id="password"
                className="auth-form-control"
                placeholder="••••••••"
              />
              <button
                type="button"
                className="password-toggle-btn"
                onClick={() => setShowPassword(!showPassword)}
                aria-label={showPassword ? "Masquer le mot de passe" : "Afficher le mot de passe"}
              >
                <i className={`fas fa-eye${showPassword ? '' : '-slash'}`}></i>
              </button>
            </div>
          </div>

          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '25px', flexWrap: 'wrap', gap: '10px' }}>
            <label style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer' }}>
              <input type="checkbox" />
              <span>{t('auth.rememberMe')}</span>
            </label>
            <Link href="/auth/forgot-password" style={{ color: 'var(--primary-color)', fontSize: '0.9em' }}>
              {t('auth.forgotPassword')}
            </Link>
          </div>

          <button type="submit" className="btn btn-primary" style={{ width: '100%', padding: '12px', marginBottom: '15px' }}>
            {t('auth.loginButton')}
          </button>

          <button type="button" className="btn btn-secondary" style={{ width: '100%', padding: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '10px' }}>
            <Image src="/images/logo_google.png" alt="Google" width={20} height={20} style={{ objectFit: 'contain' }} /> {t('auth.googleLogin')}
          </button>
        </form>

        <div style={{ marginTop: '25px', textAlign: 'center', fontSize: '0.95em' }}>
          {t('auth.noAccount')} <Link href="/auth/signup" style={{ fontWeight: 'bold' }}>{t('auth.registerTitle')}</Link>
        </div>
      </div>
    </div>
  );
}
