// app/auth/signup/page.tsx
'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';

export default function SignupPage() {
    const [userType, setUserType] = useState<'individual' | 'company'>('individual');
    const [showPassword, setShowPassword] = useState(false);
    const [showConfirmPassword, setShowConfirmPassword] = useState(false);

    return (
        <div className="auth-page">
            <div className="auth-card auth-staggered" style={{ maxWidth: '600px' }}>
                <div style={{ marginBottom: '20px' }}>
                    <Link href="/" style={{ color: '#666', fontSize: '0.9em', display: 'flex', alignItems: 'center', gap: '5px', textDecoration: 'none', title: 'Retour à l\'accueil' }}>
                        <i className="fas fa-arrow-left"></i>
                    </Link>
                </div>

                <div style={{ textAlign: 'center', marginBottom: '15px' }}>
                    <Image src="/images/logo.jpg" alt="Logo Yowyob" width={60} height={60} style={{ borderRadius: '50%', objectFit: 'cover' }} />
                </div>

                <div className="auth-header">
                    <h2>Inscription</h2>
                </div>

                <div className="user-type-toggle">
                    <button
                        type="button"
                        onClick={() => setUserType('individual')}
                        className={`toggle-btn ${userType === 'individual' ? 'active' : ''}`}
                    >
                        Individu
                    </button>
                    <button
                        type="button"
                        onClick={() => setUserType('company')}
                        className={`toggle-btn ${userType === 'company' ? 'active' : ''}`}
                    >
                        Entreprise
                    </button>
                </div>

                <form className="auth-staggered">
                    <div className="auth-form-grid">
                        <div className="auth-form-group full-width">
                            <label>
                                {userType === 'individual' ? 'Nom complet' : 'Nom de l\'entreprise'}
                            </label>
                            <div className="auth-input-wrapper">
                                <i className={`fas fa-${userType === 'individual' ? 'user' : 'building'} input-icon`}></i>
                                <input
                                    type="text"
                                    className="auth-form-control"
                                    placeholder={userType === 'individual' ? 'Ex: Jean Dupont' : 'Ex: Tech Solutions SA'}
                                />
                            </div>
                        </div>

                        <div className="auth-form-group">
                            <label>Email</label>
                            <div className="auth-input-wrapper">
                                <i className="fas fa-envelope input-icon"></i>
                                <input
                                    type="email"
                                    className="auth-form-control"
                                    placeholder="exemple@email.com"
                                />
                            </div>
                        </div>

                        <div className="auth-form-group">
                            <label>Téléphone</label>
                            <div className="auth-input-wrapper">
                                <i className="fas fa-phone input-icon"></i>
                                <input
                                    type="tel"
                                    className="auth-form-control"
                                    placeholder="+33 6 12 34 56 78"
                                />
                            </div>
                        </div>

                        <div className="auth-form-group full-width">
                            <label>Domaine d'activités</label>
                            <div className="auth-input-wrapper">
                                <i className="fas fa-briefcase input-icon"></i>
                                <input
                                    type="text"
                                    className="auth-form-control"
                                    placeholder="Ex: Informatique, Commerce, Santé..."
                                />
                            </div>
                        </div>

                        {/* Champs conditionnels */}
                        {userType === 'company' ? (
                            <>
                                <div className="auth-form-group">
                                    <label>Localisation</label>
                                    <div className="auth-input-wrapper">
                                        <i className="fas fa-map-marker-alt input-icon"></i>
                                        <input
                                            type="text"
                                            className="auth-form-control"
                                            placeholder="Ex: Paris, France"
                                        />
                                    </div>
                                </div>
                                <div className="auth-form-group">
                                    <label>Logo</label>
                                    <div className="auth-input-wrapper">
                                        <i className="fas fa-image input-icon"></i>
                                        <input
                                            type="file"
                                            className="auth-form-control"
                                        />
                                    </div>
                                </div>
                            </>
                        ) : (
                            <>
                                <div className="auth-form-group">
                                    <label>Profession</label>
                                    <div className="auth-input-wrapper">
                                        <i className="fas fa-briefcase input-icon"></i>
                                        <input
                                            type="text"
                                            className="auth-form-control"
                                            placeholder="Ex: Développeur, Designer, Manager..."
                                        />
                                    </div>
                                </div>
                                <div className="auth-form-group">
                                    <label>Photo de profil</label>
                                    <div className="auth-input-wrapper">
                                        <i className="fas fa-camera input-icon"></i>
                                        <input
                                            type="file"
                                            className="auth-form-control"
                                        />
                                    </div>
                                </div>
                            </>
                        )}

                        <div className="auth-form-group full-width">
                            <label>Mot de passe</label>
                            <div className="auth-input-wrapper password-wrapper">
                                <i className="fas fa-lock input-icon"></i>
                                <input
                                    type={showPassword ? "text" : "password"}
                                    className="auth-form-control"
                                    placeholder="Entrez un mot de passe sécurisé"
                                />
                                <button
                                    type="button"
                                    className="password-toggle-btn"
                                    onClick={() => setShowPassword(!showPassword)}
                                    aria-label={showPassword ? "Masquer le mot de passe" : "Afficher le mot de passe"}
                                >
                                    <i className={`fas fa-eye${showPassword ? '' : '-slash'}`}></i>
                                </button>
                            </div>
                        </div>

                        <div className="auth-form-group full-width">
                            <label>Confirmer le mot de passe</label>
                            <div className="auth-input-wrapper password-wrapper">
                                <i className="fas fa-lock input-icon"></i>
                                <input
                                    type={showConfirmPassword ? "text" : "password"}
                                    className="auth-form-control"
                                    placeholder="Confirmez votre mot de passe"
                                />
                                <button
                                    type="button"
                                    className="password-toggle-btn"
                                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                                    aria-label={showConfirmPassword ? "Masquer le mot de passe" : "Afficher le mot de passe"}
                                >
                                    <i className={`fas fa-eye${showConfirmPassword ? '' : '-slash'}`}></i>
                                </button>
                            </div>
                        </div>

                    </div>

                    <button type="submit" className="btn btn-primary" style={{ width: '100%', padding: '12px', marginTop: '10px', fontSize: '1.1em' }}>
                        S'inscrire
                    </button>
                </form>

                <div style={{ marginTop: '25px', textAlign: 'center', fontSize: '0.95em' }}>
                    Déjà un compte ? <Link href="/auth/login" style={{ fontWeight: 'bold' }}>Se connecter</Link>
                </div>
            </div>
        </div>
    );
}
