"use client";

import { useState, useEffect } from 'react';
import FeedSidebar from '@/components/FeedSidebar';
import MagicPageEnhancer from '@/components/MagicPageEnhancer';
import '../feed.css';

export default function DashboardClient({ children }: { children: React.ReactNode }) {
    const [isCollapsed, setIsCollapsed] = useState(false);
    const [isMobile, setIsMobile] = useState(false);

    useEffect(() => {
        // Détection mobile/desktop avec breakpoint à 768px
        const handleResize = () => {
            const mobile = window.innerWidth <= 768;
            setIsMobile(mobile);

            // Sur mobile, le sidebar est fermé par défaut (drawer)
            // Sur desktop, le sidebar est ouvert par défaut
            if (mobile) {
                setIsCollapsed(true);
            } else {
                setIsCollapsed(false);
            }
        };

        // Set initial state
        handleResize();

        window.addEventListener('resize', handleResize);
        return () => window.removeEventListener('resize', handleResize);
    }, []);

    const toggleSidebar = () => {
        setIsCollapsed(!isCollapsed);
    };

    return (
        <MagicPageEnhancer>
            {/* Skip links pour l'accessibilité */}
            <a href="#main-content" className="skip-link">
                Aller au contenu principal
            </a>
            <a href="#sidebar-navigation" className="skip-link">
                Aller à la navigation
            </a>

            <div className="dashboard-container">
                <div id="sidebar-navigation">
                    <FeedSidebar
                        isCollapsed={isCollapsed}
                        toggleSidebar={toggleSidebar}
                        isMobile={isMobile}
                    />
                </div>

                <main id="main-content" className="main-content" tabIndex={-1}>
                    {/* Header mobile avec bouton hamburger */}
                    {isMobile && (
                        <div className="mobile-dashboard-header">
                            <button
                                className="sidebar-toggle"
                                onClick={toggleSidebar}
                                aria-label="Ouvrir le menu"
                                aria-expanded={!isCollapsed}
                            >
                                <i className="fas fa-bars"></i>
                            </button>
                            <span className="app-name-mobile">Yowyob Feedback</span>
                        </div>
                    )}
                    {children}
                </main>
            </div>
        </MagicPageEnhancer>
    );
}
