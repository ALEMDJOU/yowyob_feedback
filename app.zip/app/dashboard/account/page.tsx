"use client";
import React from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { useTranslation } from '@/components/I18nProvider';
import ProjectFeedbackGroup from '@/components/ProjectFeedbackGroup';
import { FeedbackData } from '@/components/FeedbackCard';

// styles are imported by the follower layout

export default function FollowerIndexPage() {
  const { t } = useTranslation();

  // Données de test pour "Mon Compte" (similaire à Profile)
  const myProjectGroups: Record<string, any> = {
    'portfolio-site': {
      projectName: 'Portfolio Website',
      projectAvatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      creatorUsername: 'henri_fofack_dev',
      feedbacks: [
        {
          id: 'my-f1',
          businessName: 'Henri Fofack',
          businessLogo: '/images/porw.jpg',
          businessUsername: 'henri_fofack_dev',
          projectName: 'Portfolio Website',
          projectAvatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
          projectId: 'portfolio-site',
          time: '2 heures',
          content: 'J\'ai terminé l\'intégration de la section contact. Tout fonctionne comme prévu.',
          likes: 5,
          liked: false,
          comments: [],
          isAuthor: true
        }
      ]
    },
    'mobile-app': {
      projectName: 'Mobile App Redesign',
      projectAvatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      creatorUsername: 'henri_fofack_dev',
      feedbacks: [
        {
          id: 'my-f2',
          businessName: 'Henri Fofack',
          businessLogo: '/images/porw.jpg',
          businessUsername: 'henri_fofack_dev',
          projectName: 'Mobile App Redesign',
          projectAvatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
          projectId: 'mobile-app',
          time: '1 jour',
          content: 'Les nouvelles maquettes sont prêtes pour la revue. J\'ai mis l\'accent sur l\'accessibilité pour cette version.',
          likes: 12,
          liked: true,
          comments: [],
          isAuthor: true
        },
        {
          id: 'my-f3',
          businessName: 'Henri Fofack',
          businessLogo: '/images/porw.jpg',
          businessUsername: 'henri_fofack_dev',
          projectName: 'Mobile App Redesign',
          projectAvatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
          projectId: 'mobile-app',
          time: '3 jours',
          content: 'Retour sur les tests utilisateurs : la navigation est beaucoup plus fluide.',
          likes: 8,
          liked: false,
          comments: [],
          isAuthor: true
        }
      ]
    }
  };

  return (
    <>
      <header className="content-header">
        <div className="header-title">
          <i className="fas fa-user-circle title-icon" aria-hidden="true"></i>
          <h1>{t('account.title')}</h1>
        </div>
      </header>

      <div className="profile-page">
        <section className="profile-header-ig">
          <div className="profile-avatar-container-ig">
            <Image src="/images/porw.jpg" alt="Photo de profil" width={150} height={150} className="profile-avatar-ig" />
          </div>

          <div className="profile-info-container-ig">
            <div className="profile-top-row-ig">
              <h1 className="profile-username-ig">henri_fofack_dev</h1>
              <i className="fas fa-check-circle certified-icon-ig"></i>
              <Link href="/dashboard/account/edit" className="btn btn-secondary edit-profile-btn-ig">
                {t('account.editProfile')}
              </Link>
            </div>

            <div className="profile-stats-ig">
              <span className="stat-item-ig"><span className="stat-number">42</span> {t('account.stats_feedbacks')}</span>
              <Link href="/dashboard/account/followers" className="stat-item-ig link"><span className="stat-number">1,234</span> {t('account.stats_followers')}</Link>
              <Link href="/dashboard/account/following" className="stat-item-ig link"><span className="stat-number">150</span> {t('account.stats_following')}</Link>
            </div>

            <div className="profile-bio-ig">
              <p className="profile-name-ig">Henri Fofack | utilisateur yowyob depuis 4 ans</p>
              <p className="profile-description-ig">Développeur d'applications | CEO de Yowyob Feedback.</p>
              <a href="#" className="profile-website-ig">https://yowyob.com</a>
            </div>
          </div>
        </section>

        <hr className="separator-ig" />

        <div className="profile-main-content-full" style={{ width: '100%' }}>
          <div className="feedbacks-column-full">
            <h3 className="section-title"><i className="fas fa-comment-dots"></i> {t('account.section_feedbacks')}</h3>

            <div className="project-groups-container">
              {Object.entries(myProjectGroups).map(([projectId, group]: [string, any]) => (
                <ProjectFeedbackGroup
                  key={projectId}
                  projectId={projectId}
                  projectName={group.projectName}
                  projectAvatar={group.projectAvatar}
                  creatorUsername={group.creatorUsername}
                  profileUsername="henri_fofack_dev"
                  feedbacks={group.feedbacks as FeedbackData[]}
                  initiallyExpanded={true}
                  allowActions={false} // Pas d'actions sur la vue 'Mon Compte'
                />
              ))}
            </div>

            {Object.keys(myProjectGroups).length === 0 && (
              <div className="no-feedbacks-message">
                <i className="fas fa-inbox"></i>
                <p>{t('profile.noFeedbacks')}</p>
              </div>
            )}

          </div>
        </div>
      </div>
    </>
  );
}
