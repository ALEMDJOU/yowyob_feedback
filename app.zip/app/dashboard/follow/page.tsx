"use client";

import React from 'react';
import Script from 'next/script';
import { useTranslation } from '@/components/I18nProvider';
import FeedbackCard, { FeedbackData } from '@/components/FeedbackCard';

export default function FollowPage() {
    const { t } = useTranslation();

    const initialFeedbacks: FeedbackData[] = [
        {
            id: '1',
            businessName: 'Tech Innov S.A.',
            businessLogo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
            businessUsername: 'techinnov',
            projectName: 'Quantum Leap',
            projectAvatar: 'https://i.ibb.co/6P8N9zR/company-logo.png',
            projectId: 'quantum-leap',
            time: '5 minutes',
            content: 'Excellent travail sur ce projet ! L\'équipe a été réactive et à l\'écoute. Le produit final dépasse nos attentes. Très satisfait du résultat.',
            likes: 12,
            liked: false,
            comments: [
                {
                    id: 'c1',
                    author: 'Marie Dubois',
                    text: 'Très intéressant ! J\'ai hâte de tester 🎉',
                    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
                    likes: 3,
                    liked: false,
                    replies: [],
                    isAnonymous: false
                },
                {
                    id: 'c2',
                    author: 'Membre anonyme',
                    text: 'Excellente initiative !',
                    likes: 0,
                    liked: false,
                    replies: [],
                    isAnonymous: true
                }
            ]
        },
        {
            id: '2',
            businessName: 'Global Corp',
            businessLogo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
            businessUsername: 'globalcorp',
            projectName: 'Service Client Premium',
            projectAvatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
            projectId: 'service-client',
            time: '1 heure',
            content: 'Service impeccable ! Support réactif et solutions efficaces. Je recommande vivement cette équipe pour vos projets.',
            likes: 45,
            liked: false,
            comments: [
                {
                    id: 'c3',
                    author: 'Sophie Laurent',
                    text: 'Je confirme, leur service est top ! 👍',
                    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
                    likes: 5,
                    liked: true,
                    replies: [],
                    isAnonymous: false
                }
            ]
        },
        {
            id: '3',
            businessName: 'Design Studio',
            businessLogo: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
            businessUsername: 'designstudio',
            projectName: 'Refonte UI/UX',
            projectAvatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
            projectId: 'refonte-ui',
            time: '2 heures',
            content: 'Excellente expérience avec l\'équipe de Design Studio ! Interface moderne, navigation fluide et design soigné. Bravo pour ce travail de qualité !',
            likes: 28,
            liked: false,
            comments: []
        }
    ];

    const [searchQuery, setSearchQuery] = React.useState('');

    // Filter feedbacks based on search query
    const filteredFeedbacks = React.useMemo(() => {
        if (!searchQuery.trim()) return initialFeedbacks;

        const query = searchQuery.toLowerCase();
        return initialFeedbacks.filter(feedback =>
            feedback.content.toLowerCase().includes(query) ||
            feedback.businessName.toLowerCase().includes(query) ||
            feedback.projectName.toLowerCase().includes(query)
        );
    }, [searchQuery]);

    return (
        <>
            <link rel="stylesheet" href="/feed.css" />

            <header className="content-header">
                <div className="header-title">
                    <i className="fas fa-bell title-icon"></i>
                    <h1>{t('sidebar.subscriptions')}</h1>
                </div>
            </header>

            <div className="control-bar">
                <div className="search-box">
                    <i className="fas fa-search search-icon"></i>
                    <input
                        type="text"
                        placeholder={t('feed.searchPlaceholder')}
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                    />
                </div>
            </div>

            <section className="feedback-section">
                {filteredFeedbacks.map(data => (
                    <FeedbackCard key={data.id} data={data} />
                ))}
            </section>

            <Script src="/feed.js" strategy="lazyOnload" />
        </>
    );
}
