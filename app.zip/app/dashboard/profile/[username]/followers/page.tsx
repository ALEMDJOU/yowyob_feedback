'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { useParams, useRouter } from 'next/navigation';

interface Follower {
    username: string;
    name: string;
    avatar: string;
    description: string;
    followersCount: number;
    certified: boolean;
    isFollowedByMe: boolean;
}

const mockFollowers: Follower[] = [
    {
        username: 'alice_dev',
        name: 'Alice Martin',
        avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
        description: 'Designer UI/UX passionnée par l\'innovation',
        followersCount: 892,
        certified: false,
        isFollowedByMe: true
    },
    {
        username: 'bob_tech',
        name: 'Bob Dupont',
        avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
        description: 'Développeur Backend | Python & Node.js',
        followersCount: 1234,
        certified: true,
        isFollowedByMe: false
    },
    {
        username: 'claire_design',
        name: 'Claire Moreau',
        avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
        description: 'Graphiste freelance | Branding',
        followersCount: 567,
        certified: false,
        isFollowedByMe: true
    }
];

export default function ProfileFollowersPage() {
    const params = useParams();
    const router = useRouter();
    const username = (params?.username as string) || 'utilisateur';
    const [followers, setFollowers] = useState<Follower[]>(mockFollowers);

    const handleToggleFollow = (targetUsername: string) => {
        setFollowers(followers.map(follower => {
            if (follower.username === targetUsername) {
                return {
                    ...follower,
                    isFollowedByMe: !follower.isFollowedByMe
                };
            }
            return follower;
        }));
    };

    return (
        <div style={{
            maxWidth: '800px',
            margin: '0 auto',
            padding: '20px'
        }}>
            {/* En-tête */}
            <div style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                marginBottom: '24px',
                paddingBottom: '16px',
                borderBottom: '1px solid #E5E7EB'
            }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                    <i className="fas fa-users" style={{ color: 'var(--primary-color)', fontSize: '1.5rem' }}></i>
                    <h1 style={{ color: '#1F2937', fontSize: '1.75rem', margin: 0, fontWeight: 700 }}>
                        Abonnés de @{username}
                    </h1>
                </div>
                <button
                    onClick={() => router.back()}
                    style={{
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: '8px',
                        color: 'var(--primary-color)',
                        background: 'none',
                        border: 'none',
                        cursor: 'pointer',
                        fontSize: '0.95rem',
                        fontWeight: 600,
                        transition: 'color 0.2s'
                    }}
                    onMouseEnter={(e) => e.currentTarget.style.color = 'var(--primary-dark)'}
                    onMouseLeave={(e) => e.currentTarget.style.color = 'var(--primary-color)'}
                >
                    <i className="fas fa-arrow-left"></i>
                    Retour au profil
                </button>
            </div>

            {/* Compteur */}
            <div style={{
                marginBottom: '20px',
                padding: '16px 20px',
                background: '#F9FAFB',
                borderRadius: '10px',
                border: '1px solid #E5E7EB'
            }}>
                <p style={{
                    margin: 0,
                    color: '#6B7280',
                    fontSize: '0.95rem',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px'
                }}>
                    <i className="fas fa-info-circle" style={{ color: 'var(--primary-color)' }}></i>
                    <strong style={{ color: '#1F2937' }}>{followers.length}</strong> personne{followers.length > 1 ? 's' : ''} {followers.length > 1 ? 'suivent' : 'suit'} ce compte
                </p>
            </div>

            {/* Liste des abonnés */}
            <div style={{
                background: 'white',
                borderRadius: '12px',
                boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06)',
                border: '1px solid #E5E7EB',
                overflow: 'hidden'
            }}>
                {followers.length > 0 ? (
                    followers.map((follower, index) => (
                        <div
                            key={follower.username}
                            style={{
                                padding: '20px',
                                borderBottom: index < followers.length - 1 ? '1px solid #E5E7EB' : 'none',
                                display: 'flex',
                                alignItems: 'center',
                                gap: '16px',
                                transition: 'background-color 0.2s'
                            }}
                            onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#F9FAFB'}
                            onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'white'}
                        >
                            {/* Avatar */}
                            <Link href={`/dashboard/profile/${follower.username}`}>
                                <img
                                    src={follower.avatar}
                                    alt={follower.name}
                                    style={{
                                        width: '60px',
                                        height: '60px',
                                        borderRadius: '50%',
                                        objectFit: 'cover',
                                        border: '2px solid #E5E7EB',
                                        cursor: 'pointer'
                                    }}
                                />
                            </Link>

                            {/* Informations */}
                            <div style={{ flex: 1, minWidth: 0 }}>
                                <Link
                                    href={`/dashboard/profile/${follower.username}`}
                                    style={{
                                        textDecoration: 'none',
                                        display: 'block',
                                        marginBottom: '4px'
                                    }}
                                >
                                    <div style={{
                                        display: 'flex',
                                        alignItems: 'center',
                                        gap: '6px',
                                        marginBottom: '4px'
                                    }}>
                                        <h3 style={{
                                            margin: 0,
                                            color: '#1F2937',
                                            fontSize: '1rem',
                                            fontWeight: 700,
                                            overflow: 'hidden',
                                            textOverflow: 'ellipsis',
                                            whiteSpace: 'nowrap'
                                        }}>
                                            {follower.name}
                                        </h3>
                                        {follower.certified && (
                                            <i className="fas fa-check-circle" style={{
                                                color: 'var(--primary-color)',
                                                fontSize: '0.9rem'
                                            }}></i>
                                        )}
                                    </div>
                                </Link>
                                <p style={{
                                    margin: '0 0 6px 0',
                                    color: '#9CA3AF',
                                    fontSize: '0.9rem'
                                }}>
                                    @{follower.username}
                                </p>
                                <p style={{
                                    margin: '0 0 6px 0',
                                    color: '#6B7280',
                                    fontSize: '0.9rem',
                                    overflow: 'hidden',
                                    textOverflow: 'ellipsis',
                                    whiteSpace: 'nowrap'
                                }}>
                                    {follower.description}
                                </p>
                            </div>

                            {/* Bouton Suivre / Déjà abonné */}
                            <button
                                onClick={() => handleToggleFollow(follower.username)}
                                style={{
                                    padding: '10px 20px',
                                    backgroundColor: follower.isFollowedByMe ? 'white' : 'var(--primary-color)',
                                    border: follower.isFollowedByMe ? '1.5px solid #E5E7EB' : 'none',
                                    borderRadius: '8px',
                                    color: follower.isFollowedByMe ? '#6B7280' : 'white',
                                    fontSize: '0.9rem',
                                    fontWeight: 600,
                                    cursor: 'pointer',
                                    transition: 'all 0.2s',
                                    whiteSpace: 'nowrap'
                                }}
                                onMouseEnter={(e) => {
                                    if (follower.isFollowedByMe) {
                                        e.currentTarget.style.backgroundColor = '#FEF2F2';
                                        e.currentTarget.style.borderColor = '#EF4444';
                                        e.currentTarget.style.color = '#EF4444';
                                    } else {
                                        e.currentTarget.style.backgroundColor = 'var(--primary-dark)';
                                    }
                                }}
                                onMouseLeave={(e) => {
                                    if (follower.isFollowedByMe) {
                                        e.currentTarget.style.backgroundColor = 'white';
                                        e.currentTarget.style.borderColor = '#E5E7EB';
                                        e.currentTarget.style.color = '#6B7280';
                                    } else {
                                        e.currentTarget.style.backgroundColor = 'var(--primary-color)';
                                    }
                                }}
                            >
                                {follower.isFollowedByMe ? (
                                    <>
                                        <i className="fas fa-user-minus" style={{ marginRight: '6px' }}></i>
                                        Suivi(e)
                                    </>
                                ) : (
                                    <>
                                        <i className="fas fa-user-plus" style={{ marginRight: '6px' }}></i>
                                        Suivre
                                    </>
                                )}
                            </button>
                        </div>
                    ))
                ) : (
                    <div style={{
                        padding: '60px 20px',
                        textAlign: 'center'
                    }}>
                        <i className="fas fa-users" style={{
                            fontSize: '3rem',
                            color: '#D1D5DB',
                            marginBottom: '16px',
                            display: 'block'
                        }}></i>
                        <p style={{
                            color: '#6B7280',
                            fontSize: '1rem',
                            margin: 0
                        }}>
                            Aucun abonné pour le moment
                        </p>
                    </div>
                )}
            </div>
        </div>
    );
}
