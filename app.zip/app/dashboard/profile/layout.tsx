import React from 'react';
import '../../feed.css';
import '../account/css/profile.css';
import '../account/css/follow-button.css';

export default function ProfileLayout({ children }: { children: React.ReactNode }) {
    return (
        <>
            <style>{`.navbar, .footer { display: none !important; } .main { margin: 0; }`}</style>
            {children}
        </>
    );
}
