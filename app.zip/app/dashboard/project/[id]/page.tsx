'use client';

import React, { useState } from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import FeedbackCard, { FeedbackData } from '@/components/FeedbackCard';
import { useTranslation } from '@/components/I18nProvider';

// Données mock pour le groupe
const getProjectData = (id: string) => {
    const projects: Record<string, any> = {
        'p1-bd-group': {
            name: 'Groupe BD',
            description: 'Projet de base de données collaborative pour le suivi des tâches.',
            avatar: 'https://i.ibb.co/6P8N9zR/company-logo.png',
            membersCount: 12,
            role: 'admin'
        },
        'p2-kadea-stage': {
            name: 'Stage Kadea',
            description: 'Accompagnement et suivi du stage chez Kadea Tech.',
            avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
            membersCount: 5,
            role: 'invite'
        },
        'p3-react-proj': {
            name: 'Projet React',
            description: 'Développement d\'une application React moderne avec TypeScript.',
            avatar: 'https://i.ibb.co/6P8N9zR/company-logo.png',
            membersCount: 8,
            role: 'admin'
        },
    };
    return projects[id] || {
        name: 'Projet',
        description: 'Description du projet',
        avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
        membersCount: 0,
        role: 'invite'
    };
};

// Feedbacks mock pour le projet
const getProjectFeedbacks = (id: string): FeedbackData[] => {
    return [
        {
            id: '1',
            businessName: 'Alice Martin',
            businessLogo: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
            businessUsername: 'alice',
            projectName: getProjectData(id).name,
            projectAvatar: getProjectData(id).avatar,
            projectId: id,
            time: 'Il y a 2 heures',
            content: 'Excellente avancée sur le projet cette semaine ! L\'équipe a réussi à livrer toutes les fonctionnalités prévues. Bravo à tous pour votre travail acharné. 🎉',
            likes: 8,
            liked: false,
            isAuthor: true, // This user is the author of this feedback
            comments: [
                {
                    id: 'c1',
                    author: 'Bob Dupont',
                    text: 'Merci Alice ! C\'était un vrai plaisir de collaborer sur ce sprint.',
                    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
                    likes: 2,
                    liked: false,
                    replies: [],
                    isAnonymous: false
                }
            ]
        },
        {
            id: '2',
            businessName: 'Sophie Bernard',
            businessLogo: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
            businessUsername: 'sophie',
            projectName: getProjectData(id).name,
            projectAvatar: getProjectData(id).avatar,
            projectId: id,
            time: 'Hier à 15:30',
            content: 'Petit rappel : la réunion de sprint planning est prévue demain à 10h. Merci de préparer vos points à discuter. 📅',
            likes: 5,
            liked: true,
            comments: []
        },
        {
            id: '3',
            businessName: 'Thomas Lefebvre',
            businessLogo: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
            businessUsername: 'thomas',
            projectName: getProjectData(id).name,
            projectAvatar: getProjectData(id).avatar,
            projectId: id,
            time: 'Il y a 3 jours',
            content: 'J\'ai mis à jour la documentation du projet. Vous pouvez la consulter dans l\'onglet "Ressources". N\'hésitez pas si vous avez des questions ! 📚',
            likes: 12,
            liked: false,
            comments: [
                {
                    id: 'c2',
                    author: 'Claire Moreau',
                    text: 'Super, merci Thomas ! 👍',
                    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
                    likes: 1,
                    liked: false,
                    replies: [],
                    isAnonymous: false
                },
                {
                    id: 'c3',
                    author: 'Membre anonyme',
                    text: 'Très utile, merci !',
                    likes: 0,
                    liked: false,
                    replies: [],
                    isAnonymous: true
                }
            ]
        }
    ];
};

export default function ProjectDetailPage() {
    const params = useParams();
    const projectId = params?.id as string;
    // On charge les données initiales
    const initialProjectData = getProjectData(projectId);

    // State pour les infos du projet (pour permettre la modification locale)
    const [project, setProject] = useState({
        ...initialProjectData,
        joinCode: 'GRP-' + Math.floor(1000 + Math.random() * 9000) // Code aléatoire mocké
    });

    const feedbacks = getProjectFeedbacks(projectId);
    const [showNewPostBox, setShowNewPostBox] = useState(false);
    const [newPostContent, setNewPostContent] = useState('');
    const [showEmojiPicker, setShowEmojiPicker] = useState(false);
    const fileInputRef = React.useRef<HTMLInputElement>(null);

    const emojis = ['😊', '❤️', '👍', '🎉', '🔥', '💯', '👏', '🙌', '😍', '🎯', '✨', '💪', '🚀', '⭐', '💡', '🎊'];

    const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            // TODO: Gérer l'upload du fichier
            console.log("Fichier sélectionné:", file.name);
        }
    };

    // Nouveaux states pour la feature Info & Admin
    const [showInfo, setShowInfo] = useState(false);
    const [isEditing, setIsEditing] = useState(false);
    const { t } = useTranslation();

    const handlePublish = () => {
        if (newPostContent.trim()) {
            // TODO: Envoyer le nouveau post via API
            setNewPostContent('');
            setShowNewPostBox(false);
            setShowEmojiPicker(false);
        }
    };

    const addEmoji = (emoji: string) => {
        setNewPostContent(prev => prev + emoji);
        setShowEmojiPicker(false); // Fermer le picker après sélection
    };

    const handleSaveInfo = () => {
        // Simuler la sauvegarde
        setIsEditing(false);
        console.log("Saved project info:", project);
    };

    const handleCancelEdit = () => {
        // Revenir aux données initiales (ici on reset juste le mode edit car on a modifié le state directement pour simplifier la démo)
        // Dans une vraie app, on aurait un state temporaire pour l'édition
        setIsEditing(false);
    };

    return (
        <div style={{ paddingBottom: '20px', minHeight: '100%' }}> {/* Wrapper pour gérer le spacing global */}
            <link rel="stylesheet" href="/feed.css" />

            {/* Header compact avec retour et bouton Info */}
            <div style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                marginBottom: '20px'
            }}>
                <Link
                    href="/dashboard/project"
                    style={{
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: '8px',
                        color: '#6A1B9A',
                        textDecoration: 'none',
                        fontSize: '0.95rem',
                        fontWeight: 600,
                        transition: 'color 0.2s'
                    }}
                >
                    <i className="fas fa-arrow-left"></i>
                    Retour aux projets
                </Link>

                <button
                    onClick={() => setShowInfo(!showInfo)}
                    style={{
                        padding: '8px 16px',
                        backgroundColor: showInfo ? '#E5E7EB' : 'white',
                        border: '1px solid #D1D5DB',
                        borderRadius: '20px',
                        color: '#374151',
                        fontSize: '0.9rem',
                        fontWeight: 500,
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '8px',
                        transition: 'all 0.2s'
                    }}
                >
                    <i className={`fas fa-info-circle ${showInfo ? 'text-primary' : ''}`}></i>
                    {showInfo ? 'Masquer infos' : 'Voir les informations du groupe'}
                </button>
            </div>

            {/* Section Informations du Groupe (Collapsible) */}
            {showInfo && (
                <div style={{
                    background: 'white',
                    borderRadius: '12px',
                    padding: '24px',
                    marginBottom: '20px',
                    boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
                    border: '1px solid #E5E7EB',
                    animation: 'fadeIn 0.3s ease-out'
                }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '20px' }}>
                        <h2 style={{ margin: 0, fontSize: '1.25rem', color: '#111827' }}>Informations du groupe</h2>
                        {project.role === 'admin' && !isEditing && (
                            <button
                                onClick={() => setIsEditing(true)}
                                style={{
                                    color: '#6A1B9A',
                                    background: 'none',
                                    border: 'none',
                                    fontWeight: 600,
                                    cursor: 'pointer',
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '6px'
                                }}
                            >
                                <i className="fas fa-pen"></i> Modifier
                            </button>
                        )}
                    </div>

                    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
                        {/* Avatar et Nom */}
                        <div style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
                            <div style={{ position: 'relative' }}>
                                <img
                                    src={project.avatar}
                                    alt={project.name}
                                    style={{
                                        width: '80px',
                                        height: '80px',
                                        borderRadius: '16px',
                                        objectFit: 'cover',
                                        border: '2px solid #E5E7EB'
                                    }}
                                />
                                {isEditing && (
                                    <button style={{
                                        position: 'absolute',
                                        bottom: -5,
                                        right: -5,
                                        background: '#6A1B9A',
                                        color: 'white',
                                        border: '2px solid white',
                                        borderRadius: '50%',
                                        width: '32px',
                                        height: '32px',
                                        cursor: 'pointer',
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'center'
                                    }}>
                                        <i className="fas fa-camera" style={{ fontSize: '0.8rem' }}></i>
                                    </button>
                                )}
                            </div>

                            <div style={{ flex: 1 }}>
                                {isEditing ? (
                                    <input
                                        type="text"
                                        value={project.name}
                                        onChange={(e) => setProject({ ...project, name: e.target.value })}
                                        style={{
                                            fontSize: '1.5rem',
                                            fontWeight: 700,
                                            padding: '8px',
                                            border: '1px solid #D1D5DB',
                                            borderRadius: '8px',
                                            width: '100%',
                                            marginBottom: '8px'
                                        }}
                                    />
                                ) : (
                                    <h1 style={{ margin: 0, fontSize: '1.75rem', fontWeight: 700, color: '#1F2937' }}>
                                        {project.name}
                                    </h1>
                                )}

                                {isEditing ? (
                                    <input
                                        type="text"
                                        value={project.description}
                                        onChange={(e) => setProject({ ...project, description: e.target.value })}
                                        style={{
                                            fontSize: '0.95rem',
                                            padding: '8px',
                                            border: '1px solid #D1D5DB',
                                            borderRadius: '8px',
                                            width: '100%',
                                            marginTop: '8px'
                                        }}
                                        placeholder="Description du groupe"
                                    />
                                ) : (
                                    <p style={{ margin: '4px 0 0 0', color: '#6B7280', fontSize: '0.95rem' }}>
                                        {project.description}
                                    </p>
                                )}
                            </div>
                        </div>

                        {/* Code d'adhésion (Admin only) */}
                        {project.role === 'admin' && (
                            <div style={{
                                padding: '16px',
                                backgroundColor: '#F9FAFB',
                                borderRadius: '8px',
                                border: '1px dashed #D1D5DB'
                            }}>
                                <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '8px' }}>
                                    <i className="fas fa-key" style={{ color: '#6A1B9A' }}></i>
                                    <span style={{ fontWeight: 600, color: '#374151', fontSize: '0.9rem' }}>Code d'adhésion</span>
                                </div>
                                {isEditing ? (
                                    <input
                                        type="text"
                                        value={project.joinCode}
                                        onChange={(e) => setProject({ ...project, joinCode: e.target.value })}
                                        style={{
                                            fontFamily: 'monospace',
                                            fontSize: '1.1rem',
                                            padding: '8px',
                                            border: '1px solid #D1D5DB',
                                            borderRadius: '6px',
                                            width: '100%',
                                            letterSpacing: '1px'
                                        }}
                                    />
                                ) : (
                                    <div style={{
                                        fontFamily: 'monospace',
                                        fontSize: '1.2rem',
                                        fontWeight: 700,
                                        color: '#111827',
                                        letterSpacing: '1px'
                                    }}>
                                        {project.joinCode}
                                    </div>
                                )}
                                <p style={{ margin: '8px 0 0 0', fontSize: '0.8rem', color: '#6B7280' }}>
                                    Partagez ce code pour inviter des membres.
                                </p>
                            </div>
                        )}

                        {/* Liste des membres */}
                        <div>
                            <h3 style={{ fontSize: '1rem', fontWeight: 600, color: '#374151', marginBottom: '12px' }}>
                                Membres ({project.membersCount})
                            </h3>
                            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                                {/* Admin (Moi) */}
                                <div style={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '6px',
                                    padding: '6px 12px',
                                    backgroundColor: '#F3E5F5',
                                    borderRadius: '20px',
                                    border: '1px solid #E1BEE7',
                                    fontSize: '0.85rem',
                                    color: '#6A1B9A'
                                }}>
                                    <i className="fas fa-user-shield"></i>
                                    <span>Moi</span>
                                </div>

                                {/* Membres anonymes */}
                                {[...Array(Math.min(5, project.membersCount - 1))].map((_, i) => (
                                    <div key={i} style={{
                                        display: 'flex',
                                        alignItems: 'center',
                                        gap: '6px',
                                        padding: '6px 12px',
                                        backgroundColor: '#F3F4F6',
                                        borderRadius: '20px',
                                        border: '1px solid #E5E7EB',
                                        fontSize: '0.85rem',
                                        color: '#4B5563'
                                    }}>
                                        <i className="fas fa-user-secret"></i>
                                        <span>Membre Anonyme</span>
                                    </div>
                                ))}
                                {project.membersCount > 6 && (
                                    <div style={{ padding: '6px 12px', color: '#6B7280', fontSize: '0.85rem' }}>
                                        +{project.membersCount - 6} autres
                                    </div>
                                )}
                            </div>
                        </div>

                        {/* Actions Save/Cancel */}
                        {isEditing && (
                            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px', marginTop: '10px' }}>
                                <button
                                    onClick={handleCancelEdit}
                                    style={{
                                        padding: '8px 16px',
                                        backgroundColor: 'white',
                                        border: '1px solid #D1D5DB',
                                        borderRadius: '6px',
                                        color: '#374151',
                                        cursor: 'pointer'
                                    }}
                                >
                                    Annuler
                                </button>
                                <button
                                    onClick={handleSaveInfo}
                                    style={{
                                        padding: '8px 16px',
                                        backgroundColor: '#6A1B9A',
                                        border: 'none',
                                        borderRadius: '6px',
                                        color: 'white',
                                        fontWeight: 600,
                                        cursor: 'pointer'
                                    }}
                                >
                                    Enregistrer
                                </button>
                            </div>
                        )}
                    </div>
                </div>
            )}

            {/* Fil de publications */}
            <section className="feedback-section" style={{ marginTop: '0px', marginBottom: '80px' }}> {/* Add marginBottom to prevent overlap */}
                {feedbacks.map(feedback => (
                    <FeedbackCard
                        key={feedback.id}
                        data={feedback}
                        hideProjectInfo={true}
                        allowActions={true}
                        isAnonymousContext={true}
                    />
                ))}
            </section>

            {/* Zone de création de nouvelle publication - sticky en bas */}
            <div className="sticky-footer-input">
                {!showNewPostBox ? (
                    <button
                        onClick={() => setShowNewPostBox(true)}
                        style={{
                            width: '100%',
                            padding: '14px 20px',
                            backgroundColor: '#F9FAFB',
                            border: '1px solid #E5E7EB',
                            borderRadius: '10px',
                            color: '#6B7280',
                            fontSize: '0.95rem',
                            textAlign: 'left',
                            cursor: 'pointer',
                            display: 'flex',
                            alignItems: 'center',
                            transition: 'all 0.2s ease'
                        }}
                        onMouseEnter={(e) => {
                            e.currentTarget.style.backgroundColor = '#F3F4F6';
                            e.currentTarget.style.borderColor = '#D1D5DB';
                        }}
                        onMouseLeave={(e) => {
                            e.currentTarget.style.backgroundColor = '#F9FAFB';
                            e.currentTarget.style.borderColor = '#E5E7EB';
                        }}
                    >
                        <img
                            src="/images/porw.jpg"
                            alt="Me"
                            style={{ width: '30px', height: '30px', borderRadius: '50%', marginRight: '12px', objectFit: 'cover' }}
                        />
                        <span>Partager une mise à jour avec le groupe...</span>
                    </button>
                ) : (
                    <div>
                        <textarea
                            value={newPostContent}
                            onChange={(e) => setNewPostContent(e.target.value)}
                            placeholder="Publiez vos avis !!"
                            autoFocus
                            style={{
                                width: '100%',
                                minHeight: '120px',
                                padding: '14px',
                                border: '1px solid #E5E7EB',
                                borderRadius: '10px',
                                fontSize: '0.95rem',
                                fontFamily: 'Montserrat, sans-serif',
                                resize: 'vertical',
                                marginBottom: '12px',
                                outline: 'none'
                            }}
                            onFocus={(e) => e.target.style.borderColor = '#6A1B9A'}
                            onBlur={(e) => e.target.style.borderColor = '#E5E7EB'}
                        />

                        {/* Toolbar et Actions */}
                        <div style={{
                            display: 'flex',
                            justifyContent: 'space-between',
                            alignItems: 'center',
                            marginTop: '8px'
                        }}>
                            {/* Attachments - Left side */}
                            <div style={{ display: 'flex', gap: '8px', position: 'relative' }}>
                                <input
                                    type="file"
                                    ref={fileInputRef}
                                    style={{ display: 'none' }}
                                    onChange={handleFileSelect}
                                />
                                <button
                                    onClick={() => fileInputRef.current?.click()}
                                    style={{
                                        background: 'none',
                                        border: 'none',
                                        cursor: 'pointer',
                                        color: '#6B7280',
                                        padding: '8px',
                                        borderRadius: '50%',
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                        transition: 'background 0.2s'
                                    }}
                                    onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#F3F4F6'}
                                    onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
                                    title="Joindre un fichier"
                                >
                                    <i className="fas fa-paperclip" style={{ fontSize: '1.2rem' }}></i>
                                </button>

                                <button
                                    onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                                    style={{
                                        background: 'none',
                                        border: 'none',
                                        cursor: 'pointer',
                                        color: showEmojiPicker ? '#6A1B9A' : '#6B7280',
                                        padding: '8px',
                                        borderRadius: '50%',
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                        transition: 'background 0.2s'
                                    }}
                                    onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#F3F4F6'}
                                    onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
                                    title="Ajouter un emoji"
                                >
                                    <i className="far fa-smile" style={{ fontSize: '1.2rem' }}></i>
                                </button>

                                {/* Emoji Picker Popover */}
                                {showEmojiPicker && (
                                    <div style={{
                                        position: 'absolute',
                                        bottom: '100%',
                                        left: '0',
                                        marginBottom: '10px',
                                        background: 'white',
                                        border: '1px solid #E5E7EB',
                                        borderRadius: '12px',
                                        padding: '12px',
                                        boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
                                        display: 'flex',
                                        flexWrap: 'wrap',
                                        gap: '8px',
                                        width: '240px',
                                        zIndex: 10
                                    }}>
                                        {emojis.map(emoji => (
                                            <button
                                                key={emoji}
                                                onClick={() => addEmoji(emoji)}
                                                style={{
                                                    background: 'transparent',
                                                    border: 'none',
                                                    borderRadius: '6px',
                                                    fontSize: '1.5rem',
                                                    cursor: 'pointer',
                                                    padding: '4px',
                                                    transition: 'transform 0.1s'
                                                }}
                                                onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.2)'}
                                                onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}
                                            >
                                                {emoji}
                                            </button>
                                        ))}
                                    </div>
                                )}
                            </div>

                            {/* Buttons - Right side */}
                            <div style={{ display: 'flex', gap: '10px' }}>
                                <button
                                    onClick={() => {
                                        setShowNewPostBox(false);
                                        setNewPostContent('');
                                        setShowEmojiPicker(false);
                                    }}
                                    style={{
                                        padding: '10px 20px',
                                        backgroundColor: '#F3F4F6',
                                        border: '1px solid #E5E7EB',
                                        borderRadius: '8px',
                                        color: '#6B7280',
                                        fontSize: '0.9rem',
                                        fontWeight: 600,
                                        cursor: 'pointer',
                                        transition: 'all 0.2s'
                                    }}
                                >
                                    Annuler
                                </button>
                                <button
                                    onClick={handlePublish}
                                    disabled={!newPostContent.trim()}
                                    style={{
                                        padding: '10px 20px',
                                        backgroundColor: newPostContent.trim() ? '#6A1B9A' : '#D1D5DB',
                                        border: 'none',
                                        borderRadius: '8px',
                                        color: 'white',
                                        fontSize: '0.9rem',
                                        fontWeight: 600,
                                        cursor: newPostContent.trim() ? 'pointer' : 'not-allowed',
                                        transition: 'all 0.2s'
                                    }}
                                >
                                    Publier
                                </button>
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
}
