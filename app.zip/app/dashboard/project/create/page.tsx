'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import Image from 'next/image';

export default function CreateProjectPage() {
    const router = useRouter();
    const [formData, setFormData] = useState({
        name: '',
        description: '',
        avatar: ''
    });
    const [avatarPreview, setAvatarPreview] = useState<string>('');
    const [generatedCode, setGeneratedCode] = useState<string>('');
    const [isCreated, setIsCreated] = useState(false);
    const [copiedCode, setCopiedCode] = useState(false);

    // Générer un code d'adhésion unique (format: XXX-XXX-XXX)
    const generateCode = () => {
        const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // Sans O, I, 0, 1 pour éviter confusion
        let code = '';
        for (let i = 0; i < 3; i++) {
            for (let j = 0; j < 3; j++) {
                code += chars.charAt(Math.floor(Math.random() * chars.length));
            }
            if (i < 2) code += '-';
        }
        return code;
    };

    const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                const result = reader.result as string;
                setAvatarPreview(result);
                setFormData(prev => ({ ...prev, avatar: result }));
            };
            reader.readAsDataURL(file);
        }
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();

        if (!formData.name.trim() || !formData.description.trim()) {
            alert('Veuillez remplir tous les champs obligatoires');
            return;
        }

        // Générer le code d'adhésion
        const code = generateCode();
        setGeneratedCode(code);

        // TODO: Envoyer les données à l'API
        console.log('Groupe créé:', { ...formData, code });

        setIsCreated(true);
    };

    const copyCode = () => {
        navigator.clipboard.writeText(generatedCode);
        setCopiedCode(true);
        setTimeout(() => setCopiedCode(false), 2000);
    };

    if (isCreated) {
        return (
            <>
                <link rel="stylesheet" href="/feed.css" />

                <div style={{
                    maxWidth: '600px',
                    margin: '0 auto',
                    padding: '40px 20px'
                }}>
                    <div style={{
                        background: 'white',
                        borderRadius: '16px',
                        padding: '40px',
                        boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
                        border: '1px solid #E5E7EB',
                        textAlign: 'center'
                    }}>
                        <div style={{
                            width: '80px',
                            height: '80px',
                            margin: '0 auto 24px',
                            background: '#10B981',
                            borderRadius: '50%',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center'
                        }}>
                            <i className="fas fa-check" style={{ fontSize: '2.5rem', color: 'white' }}></i>
                        </div>

                        <h1 style={{
                            fontSize: '1.75rem',
                            fontWeight: 700,
                            color: '#1F2937',
                            marginBottom: '12px'
                        }}>
                            Groupe créé avec succès !
                        </h1>

                        <p style={{
                            fontSize: '1rem',
                            color: '#6B7280',
                            marginBottom: '32px'
                        }}>
                            Votre groupe <strong>{formData.name}</strong> a été créé.
                        </p>

                        {/* Code d'adhésion */}
                        <div style={{
                            background: '#F9FAFB',
                            border: '2px dashed #6A1B9A',
                            borderRadius: '12px',
                            padding: '24px',
                            marginBottom: '24px'
                        }}>
                            <p style={{
                                fontSize: '0.9rem',
                                color: '#6B7280',
                                marginBottom: '12px',
                                fontWeight: 600
                            }}>
                                Code d'adhésion au groupe
                            </p>

                            <div style={{
                                fontSize: '2rem',
                                fontWeight: 700,
                                color: '#6A1B9A',
                                fontFamily: 'monospace',
                                letterSpacing: '4px',
                                marginBottom: '16px'
                            }}>
                                {generatedCode}
                            </div>

                            <button
                                onClick={copyCode}
                                style={{
                                    padding: '10px 20px',
                                    backgroundColor: copiedCode ? '#10B981' : '#6A1B9A',
                                    color: 'white',
                                    border: 'none',
                                    borderRadius: '8px',
                                    fontSize: '0.9rem',
                                    fontWeight: 600,
                                    cursor: 'pointer',
                                    transition: 'all 0.2s',
                                    display: 'inline-flex',
                                    alignItems: 'center',
                                    gap: '8px'
                                }}
                            >
                                <i className={`fas ${copiedCode ? 'fa-check' : 'fa-copy'}`}></i>
                                {copiedCode ? 'Code copié !' : 'Copier le code'}
                            </button>

                            <p style={{
                                fontSize: '0.85rem',
                                color: '#9CA3AF',
                                marginTop: '16px',
                                lineHeight: 1.5
                            }}>
                                <i className="fas fa-info-circle"></i> Partagez ce code avec les personnes que vous souhaitez inviter dans ce groupe. Vous pourrez le retrouver dans les paramètres du groupe.
                            </p>
                        </div>

                        <div style={{
                            display: 'flex',
                            gap: '12px',
                            justifyContent: 'center',
                            flexWrap: 'wrap'
                        }}>
                            <Link
                                href="/dashboard/project"
                                style={{
                                    padding: '12px 24px',
                                    backgroundColor: '#F3F4F6',
                                    color: '#1F2937',
                                    border: '1px solid #E5E7EB',
                                    borderRadius: '8px',
                                    fontSize: '0.95rem',
                                    fontWeight: 600,
                                    textDecoration: 'none',
                                    transition: 'all 0.2s',
                                    display: 'inline-block'
                                }}
                            >
                                Retour aux projets
                            </Link>

                            <button
                                onClick={() => router.push('/dashboard/project')}
                                style={{
                                    padding: '12px 24px',
                                    backgroundColor: '#6A1B9A',
                                    color: 'white',
                                    border: 'none',
                                    borderRadius: '8px',
                                    fontSize: '0.95rem',
                                    fontWeight: 600,
                                    cursor: 'pointer',
                                    transition: 'all 0.2s'
                                }}
                            >
                                Accéder au groupe
                            </button>
                        </div>
                    </div>
                </div>
            </>
        );
    }

    return (
        <>
            <link rel="stylesheet" href="/feed.css" />

            <div className="form-container">
                {/* Header */}
                <Link
                    href="/dashboard/project"
                    style={{
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: '8px',
                        color: '#6A1B9A',
                        textDecoration: 'none',
                        fontSize: '0.95rem',
                        fontWeight: 600,
                        marginBottom: '24px',
                        transition: 'color 0.2s'
                    }}
                    onMouseEnter={(e) => e.currentTarget.style.color = '#4A148C'}
                    onMouseLeave={(e) => e.currentTarget.style.color = '#6A1B9A'}
                >
                    <i className="fas fa-arrow-left"></i>
                    Retour aux projets
                </Link>

                <div className="form-card">
                    <div className="form-header">
                        <div style={{
                            width: '80px',
                            height: '80px',
                            margin: '0 auto 20px',
                            background: '#F3E5F5',
                            borderRadius: '50%',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center'
                        }}>
                            <i className="fas fa-layer-group" style={{ fontSize: '2.5rem', color: '#6A1B9A' }}></i>
                        </div>
                        <h1 className="form-title">
                            Créer un nouveau projet
                        </h1>
                        <p className="form-description">
                            Donnez vie à vos idées. Créez un espace collaboratif pour votre équipe et commencez à travailler ensemble.
                        </p>
                    </div>

                    <form onSubmit={handleSubmit} style={{ marginTop: '40px' }}>
                        {/* Photo de profil */}
                        <div style={{ marginBottom: '24px' }}>
                            <label style={{
                                display: 'block',
                                fontSize: '0.9rem',
                                fontWeight: 600,
                                color: '#1F2937',
                                marginBottom: '8px'
                            }}>
                                Photo du groupe
                            </label>

                            <div className="image-upload-container">
                                <div className="preview-box">
                                    {avatarPreview ? (
                                        <img
                                            src={avatarPreview}
                                            alt="Aperçu"
                                            style={{
                                                width: '100%',
                                                height: '100%',
                                                objectFit: 'cover'
                                            }}
                                        />
                                    ) : (
                                        <i className="fas fa-image" style={{
                                            fontSize: '2rem',
                                            color: '#9CA3AF'
                                        }}></i>
                                    )}
                                </div>

                                <label style={{
                                    padding: '10px 20px',
                                    backgroundColor: '#F3F4F6',
                                    border: '1px solid #E5E7EB',
                                    borderRadius: '8px',
                                    color: '#1F2937',
                                    fontSize: '0.9rem',
                                    fontWeight: 600,
                                    cursor: 'pointer',
                                    transition: 'all 0.2s',
                                    display: 'inline-block'
                                }}>
                                    <i className="fas fa-upload" style={{ marginRight: '8px' }}></i>
                                    Choisir une image
                                    <input
                                        type="file"
                                        accept="image/*"
                                        onChange={handleImageChange}
                                        style={{ display: 'none' }}
                                    />
                                </label>
                            </div>
                        </div>

                        {/* Nom du groupe */}
                        <div style={{ marginBottom: '24px' }}>
                            <label htmlFor="name" style={{
                                display: 'block',
                                fontSize: '0.9rem',
                                fontWeight: 600,
                                color: '#1F2937',
                                marginBottom: '8px'
                            }}>
                                Nom du groupe <span style={{ color: '#EF4444' }}>*</span>
                            </label>
                            <input
                                type="text"
                                id="name"
                                value={formData.name}
                                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                                placeholder="Ex: Groupe BD, Projet React..."
                                required
                                style={{
                                    width: '100%',
                                    padding: '12px 16px',
                                    border: '1px solid #E5E7EB',
                                    borderRadius: '8px',
                                    fontSize: '0.95rem',
                                    fontFamily: 'Montserrat, sans-serif',
                                    transition: 'all 0.2s'
                                }}
                                onFocus={(e) => {
                                    e.currentTarget.style.borderColor = '#6A1B9A';
                                    e.currentTarget.style.boxShadow = '0 0 0 3px rgba(124, 58, 237, 0.1)';
                                }}
                                onBlur={(e) => {
                                    e.currentTarget.style.borderColor = '#E5E7EB';
                                    e.currentTarget.style.boxShadow = 'none';
                                }}
                            />
                        </div>

                        {/* Description */}
                        <div style={{ marginBottom: '32px' }}>
                            <label htmlFor="description" style={{
                                display: 'block',
                                fontSize: '0.9rem',
                                fontWeight: 600,
                                color: '#1F2937',
                                marginBottom: '8px'
                            }}>
                                Description <span style={{ color: '#EF4444' }}>*</span>
                            </label>
                            <textarea
                                id="description"
                                value={formData.description}
                                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                                placeholder="Décrivez brièvement l'objectif de ce groupe..."
                                required
                                rows={4}
                                style={{
                                    width: '100%',
                                    padding: '12px 16px',
                                    border: '1px solid #E5E7EB',
                                    borderRadius: '8px',
                                    fontSize: '0.95rem',
                                    fontFamily: 'Montserrat, sans-serif',
                                    resize: 'vertical',
                                    transition: 'all 0.2s'
                                }}
                                onFocus={(e) => {
                                    e.currentTarget.style.borderColor = '#6A1B9A';
                                    e.currentTarget.style.boxShadow = '0 0 0 3px rgba(124, 58, 237, 0.1)';
                                }}
                                onBlur={(e) => {
                                    e.currentTarget.style.borderColor = '#E5E7EB';
                                    e.currentTarget.style.boxShadow = 'none';
                                }}
                            />
                        </div>

                        {/* Boutons */}
                        <div className="form-actions">
                            <Link
                                href="/dashboard/project"
                                style={{
                                    padding: '12px 24px',
                                    backgroundColor: '#F3F4F6',
                                    color: '#1F2937',
                                    border: '1px solid #E5E7EB',
                                    borderRadius: '8px',
                                    fontSize: '0.95rem',
                                    fontWeight: 600,
                                    textDecoration: 'none',
                                    transition: 'all 0.2s',
                                    display: 'inline-block'
                                }}
                            >
                                Annuler
                            </Link>

                            <button
                                type="submit"
                                style={{
                                    padding: '12px 24px',
                                    backgroundColor: '#6A1B9A',
                                    color: 'white',
                                    border: 'none',
                                    borderRadius: '8px',
                                    fontSize: '0.95rem',
                                    fontWeight: 600,
                                    cursor: 'pointer',
                                    transition: 'all 0.2s',
                                    display: 'inline-flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    gap: '8px'
                                }}
                                onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#4A148C'}
                                onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#6A1B9A'}
                            >
                                <i className="fas fa-plus-circle"></i>
                                Créer le groupe
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </>
    );
}
