'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

export default function JoinProjectPage() {
    const router = useRouter();
    const [code, setCode] = useState(['', '', '']);
    const [pseudo, setPseudo] = useState('');
    const [error, setError] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    const handleCodeChange = (index: number, value: string) => {
        // N'accepter que les lettres et chiffres
        const sanitized = value.toUpperCase().replace(/[^A-Z0-9]/g, '');

        if (sanitized.length <= 3) {
            const newCode = [...code];
            newCode[index] = sanitized;
            setCode(newCode);
            setError('');

            // Auto-focus sur le segment suivant si ce segment est complet
            if (sanitized.length === 3 && index < 2) {
                const nextInput = document.getElementById(`code-${index + 1}`);
                nextInput?.focus();
            }
        }
    };

    const handlePaste = (e: React.ClipboardEvent) => {
        e.preventDefault();
        const pastedText = e.clipboardData.getData('text').toUpperCase().replace(/[^A-Z0-9]/g, '');

        if (pastedText.length === 9) {
            setCode([
                pastedText.slice(0, 3),
                pastedText.slice(3, 6),
                pastedText.slice(6, 9)
            ]);
            setError('');
        }
    };

    const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
        // Retour arrière : passer au segment précédent si vide
        if (e.key === 'Backspace' && code[index] === '' && index > 0) {
            const prevInput = document.getElementById(`code-${index - 1}`);
            prevInput?.focus();
        }
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');

        const fullCode = code.join('');

        if (fullCode.length !== 9) {
            setError('Veuillez entrer un code complet (9 caractères)');
            return;
        }

        if (!pseudo.trim()) {
            setError('Veuillez choisir un pseudo');
            return;
        }

        setIsLoading(true);

        // TODO: Vérifier le code avec l'API
        // Simuler une vérification
        setTimeout(() => {
            // Exemple de codes valides pour la démo
            const validCodes = ['ABC-DEF-GHI', 'XYZ-123-456'];
            const codeWithDashes = code.join('-');

            if (validCodes.includes(codeWithDashes)) {
                // Succès - rediriger vers la liste des projets
                // TODO: L'API devrait retourner l'ID du projet pour rediriger vers /dashboard/project/{projectId}
                router.push('/dashboard/project');
            } else {
                setError('Code invalide. Veuillez vérifier et réessayer.');
                setIsLoading(false);
            }
        }, 1000);
    };

    return (
        <>
            <link rel="stylesheet" href="/feed.css" />

            <link rel="stylesheet" href="/feed.css" />

            <div className="form-container">
                {/* Header */}
                <Link
                    href="/dashboard/project"
                    style={{
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: '8px',
                        color: '#6A1B9A',
                        textDecoration: 'none',
                        fontSize: '0.95rem',
                        fontWeight: 600,
                        marginBottom: '24px',
                        transition: 'color 0.2s'
                    }}
                    onMouseEnter={(e) => e.currentTarget.style.color = '#4A148C'}
                    onMouseLeave={(e) => e.currentTarget.style.color = '#6A1B9A'}
                >
                    <i className="fas fa-arrow-left"></i>
                    Retour aux projets
                </Link>

                <div className="form-card">
                    <div className="form-header">
                        <div style={{
                            width: '80px',
                            height: '80px',
                            margin: '0 auto 24px',
                            background: '#F3F4F6',
                            borderRadius: '50%',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center'
                        }}>
                            <i className="fas fa-user-plus" style={{
                                fontSize: '2rem',
                                color: '#6A1B9A'
                            }}></i>
                        </div>

                        <h1 className="form-title">
                            Rejoindre un groupe
                        </h1>

                        <p className="form-description">
                            Entrez le code d'adhésion que vous avez reçu pour rejoindre un groupe existant
                        </p>
                    </div>

                    {/* Explication du format */}
                    <div style={{
                        background: '#F9FAFB',
                        border: '1px solid #E5E7EB',
                        borderRadius: '10px',
                        padding: '16px',
                        marginBottom: '32px',
                        textAlign: 'left'
                    }}>
                        <p style={{
                            fontSize: '0.85rem',
                            color: '#6B7280',
                            marginBottom: '8px',
                            display: 'flex',
                            alignItems: 'center',
                            gap: '8px'
                        }}>
                            <i className="fas fa-info-circle" style={{ color: '#6A1B9A' }}></i>
                            <strong>Format du code :</strong>
                        </p>
                        <p style={{
                            fontSize: '0.85rem',
                            color: '#6B7280',
                            marginLeft: '28px'
                        }}>
                            Le code d'adhésion est composé de 9 caractères (lettres et chiffres) au format <strong>XXX-XXX-XXX</strong>
                        </p>
                    </div>

                    {/* Formulaire */}
                    <form onSubmit={handleSubmit}>
                        <div style={{ marginBottom: '24px' }}>
                            <label style={{
                                display: 'block',
                                fontSize: '0.9rem',
                                fontWeight: 600,
                                color: '#1F2937',
                                marginBottom: '16px'
                            }}>
                                Code d'adhésion
                            </label>

                            {/* Champs de saisie du code */}
                            <div className="join-code-container">
                                {code.map((segment, index) => (
                                    <React.Fragment key={index}>
                                        <input
                                            type="text"
                                            id={`code-${index}`}
                                            value={segment}
                                            onChange={(e) => handleCodeChange(index, e.target.value)}
                                            onKeyDown={(e) => handleKeyDown(index, e)}
                                            onPaste={index === 0 ? handlePaste : undefined}
                                            placeholder="XXX"
                                            maxLength={3}
                                            className="join-code-input"
                                        />
                                        {index < 2 && (
                                            <span className="join-code-separator">
                                                -
                                            </span>
                                        )}
                                    </React.Fragment>
                                ))}
                            </div>

                            <label style={{
                                display: 'block',
                                fontSize: '0.9rem',
                                fontWeight: 600,
                                color: '#1F2937',
                                marginBottom: '16px',
                                marginTop: '32px'
                            }}>
                                Pseudo dans le groupe
                            </label>

                            <input
                                type="text"
                                value={pseudo}
                                onChange={(e) => setPseudo(e.target.value)}
                                placeholder="Votre pseudo (ex: Alex)"
                                style={{
                                    width: '100%',
                                    padding: '14px',
                                    fontSize: '1rem',
                                    border: '1px solid #E5E7EB',
                                    borderRadius: '10px',
                                    textAlign: 'center',
                                    fontWeight: 500,
                                    marginBottom: '16px',
                                    backgroundColor: '#F9FAFB'
                                }}
                                onFocus={(e) => {
                                    e.currentTarget.style.borderColor = '#6A1B9A';
                                    e.currentTarget.style.backgroundColor = 'white';
                                }}
                                onBlur={(e) => {
                                    e.currentTarget.style.borderColor = '#E5E7EB';
                                    e.currentTarget.style.backgroundColor = '#F9FAFB';
                                }}
                            />

                            {/* Message d'erreur */}
                            {error && (
                                <div style={{
                                    padding: '12px',
                                    background: '#FEF2F2',
                                    border: '1px solid #FCA5A5',
                                    borderRadius: '8px',
                                    color: '#DC2626',
                                    fontSize: '0.9rem',
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '8px',
                                    justifyContent: 'center'
                                }}>
                                    <i className="fas fa-exclamation-circle"></i>
                                    {error}
                                </div>
                            )}
                        </div>

                        {/* Boutons */}
                        <div className="form-actions" style={{ justifyContent: 'center' }}>
                            <Link
                                href="/dashboard/project"
                                style={{
                                    padding: '12px 24px',
                                    backgroundColor: '#F3F4F6',
                                    color: '#1F2937',
                                    border: '1px solid #E5E7EB',
                                    borderRadius: '8px',
                                    fontSize: '0.95rem',
                                    fontWeight: 600,
                                    textDecoration: 'none',
                                    transition: 'all 0.2s',
                                    display: 'inline-block'
                                }}
                            >
                                Annuler
                            </Link>

                            <button
                                type="submit"
                                disabled={isLoading || code.join('').length !== 9 || !pseudo.trim()}
                                style={{
                                    padding: '12px 24px',
                                    backgroundColor: (isLoading || code.join('').length !== 9 || !pseudo.trim()) ? '#D1D5DB' : '#6A1B9A',
                                    color: 'white',
                                    border: 'none',
                                    borderRadius: '8px',
                                    fontSize: '0.95rem',
                                    fontWeight: 600,
                                    cursor: (isLoading || code.join('').length !== 9 || !pseudo.trim()) ? 'not-allowed' : 'pointer',
                                    transition: 'all 0.2s',
                                    display: 'inline-flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    gap: '8px',
                                    opacity: (isLoading || code.join('').length !== 9 || !pseudo.trim()) ? 0.6 : 1
                                }}
                                onMouseEnter={(e) => {
                                    if (code.join('').length === 9 && pseudo.trim() && !isLoading) {
                                        e.currentTarget.style.backgroundColor = '#4A148C';
                                    }
                                }}
                                onMouseLeave={(e) => {
                                    if (code.join('').length === 9 && pseudo.trim() && !isLoading) {
                                        e.currentTarget.style.backgroundColor = '#6A1B9A';
                                    }
                                }}
                            >
                                {isLoading ? (
                                    <>
                                        <i className="fas fa-spinner fa-spin"></i>
                                        Vérification...
                                    </>
                                ) : (
                                    <>
                                        <i className="fas fa-sign-in-alt"></i>
                                        Rejoindre
                                    </>
                                )}
                            </button>
                        </div>
                    </form>

                    {/* Aide */}
                    <div style={{
                        marginTop: '32px',
                        paddingTop: '24px',
                        borderTop: '1px solid #E5E7EB'
                    }}>
                        <p style={{
                            fontSize: '0.85rem',
                            color: '#9CA3AF',
                            lineHeight: 1.6
                        }}>
                            Vous n'avez pas de code ? Demandez à l'administrateur du groupe de vous partager le code d'adhésion.
                        </p>
                    </div>
                </div>
            </div>
        </>
    );
}
