
'use client';

import React, { useState, useRef, useEffect } from 'react';
import { useTranslation } from '@/components/I18nProvider';
import Link from 'next/link';
import './projects.css';
import '../../feed.css';

interface Project {
    id: string;
    name: string;
    description: string;
    avatar: string;
    membersCount: number;
    lastActivity: string;
    unread: number;
    role: 'admin' | 'invite';
    creatorUsername: string; // Username du créateur du groupe
}

const mockProjects: Project[] = [
    {
        id: "p1-bd-group",
        name: "Groupe BD",
        description: "Projet de base de données collaborative pour le suivi des tâches.",
        avatar: "https://i.ibb.co/6P8N9zR/company-logo.png",
        membersCount: 12,
        lastActivity: "Actif il y a 10 min",
        unread: 2,
        role: 'admin',
        creatorUsername: 'techinnov'
    },
    {
        id: "p2-kadea-stage",
        name: "Stage Kadea",
        description: "Accompagnement et suivi du stage chez Kadea Tech.",
        avatar: "https://i.ibb.co/Qf983vG/avatar-placeholder.png",
        membersCount: 5,
        lastActivity: "Actif hier",
        unread: 0,
        role: 'invite',
        creatorUsername: 'globalcorp'
    },
    {
        id: "p3-react-proj",
        name: "Projet React",
        description: "Développement d'une application React moderne avec TypeScript.",
        avatar: "https://i.ibb.co/6P8N9zR/company-logo.png",
        membersCount: 8,
        lastActivity: "Actif lundi",
        unread: 5,
        role: 'admin',
        creatorUsername: 'techinnov'
    },
    {
        id: "p4-support",
        name: "Support Yowyob",
        description: "Équipe de support client et assistance technique.",
        avatar: "https://i.ibb.co/Qf983vG/avatar-placeholder.png",
        membersCount: 15,
        lastActivity: "Actif le 15/12",
        unread: 0,
        role: 'invite',
        creatorUsername: 'designstudio'
    },
];

export default function ProjectsPage() {
    const { t } = useTranslation();
    const [projects] = useState<Project[]>(mockProjects);
    const [showMenu, setShowMenu] = useState(false);
    const menuRef = useRef<HTMLDivElement>(null);

    // Close menu when clicking outside
    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
                setShowMenu(false);
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, []);

    return (
        <main className="projects-container">
            <header className="content-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div className="header-title">
                    <i className="fas fa-folder-open title-icon" aria-hidden="true"></i>
                    <h1>{t('sidebar.projects')}</h1>
                </div>

                <div className="add-project-btn-container" ref={menuRef}>
                    <button
                        onClick={() => setShowMenu(!showMenu)}
                        className="add-project-btn"
                        aria-label="Menu création projet"
                        aria-expanded={showMenu}
                    >
                        <i className="fas fa-plus" aria-hidden="true"></i>
                    </button>

                    {showMenu && (
                        <div className="project-menu-dropdown" role="menu">
                            <Link
                                href="/dashboard/project/create"
                                className="menu-item"
                                role="menuitem"
                            >
                                <i className="fas fa-plus-circle menu-item-icon" aria-hidden="true"></i>
                                Créer un projet
                            </Link>
                            <Link
                                href="/dashboard/project/join"
                                className="menu-item"
                                role="menuitem"
                            >
                                <i className="fas fa-user-plus menu-item-icon" aria-hidden="true"></i>
                                Rejoindre un projet
                            </Link>
                        </div>
                    )}
                </div>
            </header>

            <section className="project-list" aria-label="Liste des projets">
                {projects.length > 0 ? (
                    projects.map((project) => (
                        <Link key={project.id} href={`/dashboard/project/${project.id}`} style={{ textDecoration: 'none' }}>
                            <article className="project-card">
                                {/* Header avec avatar et nom */}
                                <div className="project-header">
                                    <img
                                        src={project.avatar}
                                        alt={project.name}
                                        className="project-avatar"
                                    />
                                    <div className="project-info">
                                        <h2 className="project-name">
                                            {project.name}
                                        </h2>
                                        <p className="project-members">
                                            <i className="fas fa-users" style={{ fontSize: '0.8rem' }} aria-hidden="true"></i>
                                            {project.membersCount} membres
                                        </p>
                                    </div>
                                </div>

                                {/* Description */}
                                <p className="project-description">
                                    {project.description}
                                </p>

                                {/* Footer avec activité et notifications */}
                                <div className="project-footer">
                                    <span className="last-activity">
                                        <i className="far fa-clock" aria-hidden="true"></i>
                                        {project.lastActivity}
                                    </span>

                                    {project.unread > 0 && (
                                        <span className="unread-badge" aria-label={`${project.unread} notifications non lues`}>
                                            {project.unread}
                                        </span>
                                    )}
                                </div>
                            </article>
                        </Link>
                    ))
                ) : (
                    <div style={{
                        gridColumn: '1 / -1',
                        textAlign: 'center',
                        padding: '60px 20px',
                        backgroundColor: 'white',
                        borderRadius: '12px',
                        border: '1px solid #E5E7EB'
                    }}>
                        <div style={{
                            width: '80px',
                            height: '80px',
                            backgroundColor: '#F3F4F6',
                            borderRadius: '50%',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            margin: '0 auto 20px auto'
                        }}>
                            <i className="fas fa-folder-open" style={{ fontSize: '2.5rem', color: '#9CA3AF' }}></i>
                        </div>
                        <h3 style={{ fontSize: '1.25rem', fontWeight: 600, color: '#374151', marginBottom: '8px' }}>Aucun projet pour le moment</h3>
                        <p style={{ color: '#6B7280', marginBottom: '24px' }}>Vous n'avez pas encore rejoint ou créé de projet.</p>
                        <Link href="/dashboard/project/create" style={{
                            display: 'inline-flex',
                            alignItems: 'center',
                            gap: '8px',
                            backgroundColor: '#6A1B9A',
                            color: 'white',
                            padding: '10px 20px',
                            borderRadius: '8px',
                            textDecoration: 'none',
                            fontWeight: 600
                        }}>
                            <i className="fas fa-plus"></i> Créer votre premier projet
                        </Link>
                    </div>
                )}
            </section>
        </main >
    );
}
