// app/layout.tsx
import './globals.css';
import { Montserrat } from 'next/font/google';
import { I18nProvider } from '@/components/I18nProvider';
import MagicPageEnhancer from '@/components/MagicPageEnhancer';
import ConditionalYowbot from '@/components/ConditionalYowbot';
import type { Metadata } from 'next';

// Configuration de la police Montserrat
const montserrat = Montserrat({
  weight: ['400', '600', '700', '900'],
  subsets: ['latin'],
  display: 'swap',
});

// Métadonnées SEO complètes
export const metadata: Metadata = {
  title: {
    default: 'Yowyob Feedback - Plateforme de feedbacks authentiques',
    template: '%s | Yowyob Feedback'
  },
  description: 'Consultez et partagez des feedbacks authentiques sur les stages, formations et expériences professionnelles. Rejoignez une communauté engagée de professionnels et étudiants.',
  keywords: ['feedback', 'stage', 'formation', 'avis', 'témoignages', 'expérience professionnelle', 'étudiants', 'employeurs'],
  authors: [{ name: 'Yowyob Feedback' }],
  creator: 'Yowyob Feedback',
  publisher: 'Yowyob Feedback',
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  openGraph: {
    type: 'website',
    locale: 'fr_FR',
    url: 'https://yowyob-feedback.com',
    siteName: 'Yowyob Feedback',
    title: 'Yowyob Feedback - Plateforme de feedbacks authentiques',
    description: 'Consultez et partagez des feedbacks authentiques sur les stages, formations et expériences professionnelles.',
    images: [
      {
        url: '/images/og-image.jpg',
        width: 1200,
        height: 630,
        alt: 'Yowyob Feedback - Plateforme de feedbacks',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Yowyob Feedback - Plateforme de feedbacks authentiques',
    description: 'Consultez et partagez des feedbacks authentiques sur les stages et formations.',
    images: ['/images/twitter-image.jpg'],
    creator: '@yowyob',
  },
  verification: {
    google: 'votre-code-google-verification',
  },
  alternates: {
    canonical: 'https://yowyob-feedback.com',
    languages: {
      'fr-FR': 'https://yowyob-feedback.com/fr',
      'en-US': 'https://yowyob-feedback.com/en',
    },
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="fr">
      <body className={montserrat.className}>
        {/* MagicPageEnhancer enveloppe tout pour les particules et l'animation d'entrée globale */}
        <MagicPageEnhancer>
          <I18nProvider>
            {/* Header and Footer are now in (marketing)/layout.tsx */}

            {children}

          </I18nProvider>
        </MagicPageEnhancer>
        <ConditionalYowbot />
      </body>
    </html>
  );
}