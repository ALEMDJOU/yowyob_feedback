// app/manifest.ts
import { MetadataRoute } from 'next';

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: 'Yowyob Feedback - Plateforme de feedbacks authentiques',
    short_name: 'Yowyob',
    description: 'Consultez et partagez des feedbacks authentiques sur les stages et formations',
    start_url: '/',
    display: 'standalone',
    background_color: '#ffffff',
    theme_color: '#6A1B9A',
    icons: [
      {
        src: '/images/logo.jpg',
        sizes: '192x192',
        type: 'image/jpeg',
      },
      {
        src: '/images/logo.jpg',
        sizes: '512x512',
        type: 'image/jpeg',
      },
    ],
  };
}
