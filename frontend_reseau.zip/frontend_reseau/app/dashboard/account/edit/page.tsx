'use client';

import React, { useState, useRef } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

type UserType = 'person' | 'business';

export default function EditProfilePage() {
    const router = useRouter();

    // États du formulaire
    const [userType, setUserType] = useState<UserType>('person');
    const [name, setName] = useState('John Doe');
    const [description, setDescription] = useState('Passionné de technologie et de développement web.');
    const [photoPreview, setPhotoPreview] = useState('https://i.ibb.co/Qf983vG/avatar-placeholder.png');
    const [photoFile, setPhotoFile] = useState<File | null>(null);

    // États pour le changement de mot de passe
    const [showPasswordSection, setShowPasswordSection] = useState(false);
    const [currentPassword, setCurrentPassword] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');

    // États UI
    const [isLoading, setIsLoading] = useState(false);
    const [errors, setErrors] = useState<Record<string, string>>({});
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            setPhotoFile(file);
            const reader = new FileReader();
            reader.onloadend = () => {
                setPhotoPreview(reader.result as string);
            };
            reader.readAsDataURL(file);
        }
    };

    const validateForm = (): boolean => {
        const newErrors: Record<string, string> = {};

        if (!name.trim()) {
            newErrors.name = 'Le nom est requis';
        }

        if (!description.trim()) {
            newErrors.description = 'La description est requise';
        }

        if (showPasswordSection) {
            if (!currentPassword) {
                newErrors.currentPassword = 'Le mot de passe actuel est requis';
            }
            if (!newPassword) {
                newErrors.newPassword = 'Le nouveau mot de passe est requis';
            } else if (newPassword.length < 8) {
                newErrors.newPassword = 'Le mot de passe doit contenir au moins 8 caractères';
            }
            if (newPassword !== confirmPassword) {
                newErrors.confirmPassword = 'Les mots de passe ne correspondent pas';
            }
        }

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();

        if (!validateForm()) {
            return;
        }

        setIsLoading(true);

        // TODO: Implémenter l'appel API pour mettre à jour le profil
        setTimeout(() => {
            setIsLoading(false);
            router.push('/dashboard/account');
        }, 1500);
    };

    const getNameLabel = () => {
        return userType === 'person' ? 'Nom complet' : 'Nom de l\'entreprise';
    };

    const getNamePlaceholder = () => {
        return userType === 'person' ? 'Votre nom complet' : 'Nom de votre entreprise';
    };

    const getDescriptionLabel = () => {
        return userType === 'person' ? 'Biographie' : 'Description de l\'entreprise';
    };

    const getDescriptionPlaceholder = () => {
        return userType === 'person'
            ? 'Parlez un peu de vous...'
            : 'Décrivez votre entreprise et ses activités...';
    };

    return (
        <>
            <link rel="stylesheet" href="/feed.css" />

            <div style={{
                maxWidth: '800px',
                margin: '0 auto',
                padding: '20px'
            }}>
                {/* En-tête */}
                <div style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    marginBottom: '24px',
                    paddingBottom: '16px',
                    borderBottom: '1px solid #E5E7EB'
                }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                        <i className="fas fa-user-edit" style={{ color: '#7C3AED', fontSize: '1.5rem' }}></i>
                        <h1 style={{ color: '#1F2937', fontSize: '1.75rem', margin: 0, fontWeight: 700 }}>
                            Modifier le profil
                        </h1>
                    </div>
                    <Link
                        href="/dashboard/account"
                        style={{
                            display: 'inline-flex',
                            alignItems: 'center',
                            gap: '8px',
                            color: '#7C3AED',
                            textDecoration: 'none',
                            fontSize: '0.95rem',
                            fontWeight: 600,
                            transition: 'color 0.2s'
                        }}
                        onMouseEnter={(e) => e.currentTarget.style.color = '#6D28D9'}
                        onMouseLeave={(e) => e.currentTarget.style.color = '#7C3AED'}
                    >
                        <i className="fas fa-times"></i>
                        Annuler
                    </Link>
                </div>

                <form onSubmit={handleSubmit}>
                    <div style={{
                        background: 'white',
                        borderRadius: '12px',
                        padding: '32px',
                        boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06)',
                        border: '1px solid #E5E7EB'
                    }}>
                        {/* Sélecteur de type d'utilisateur */}
                        <div style={{ marginBottom: '32px' }}>
                            <label style={{
                                display: 'block',
                                fontSize: '0.9rem',
                                fontWeight: 600,
                                color: '#1F2937',
                                marginBottom: '12px'
                            }}>
                                Type de compte
                            </label>
                            <div style={{
                                display: 'flex',
                                gap: '12px',
                                padding: '4px',
                                background: '#F9FAFB',
                                borderRadius: '10px',
                                border: '1px solid #E5E7EB'
                            }}>
                                <button
                                    type="button"
                                    onClick={() => setUserType('person')}
                                    style={{
                                        flex: 1,
                                        padding: '12px 20px',
                                        backgroundColor: userType === 'person' ? '#7C3AED' : 'transparent',
                                        color: userType === 'person' ? 'white' : '#6B7280',
                                        border: 'none',
                                        borderRadius: '8px',
                                        fontSize: '0.95rem',
                                        fontWeight: 600,
                                        cursor: 'pointer',
                                        transition: 'all 0.2s',
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                        gap: '8px'
                                    }}
                                >
                                    <i className="fas fa-user"></i>
                                    Personne
                                </button>
                                <button
                                    type="button"
                                    onClick={() => setUserType('business')}
                                    style={{
                                        flex: 1,
                                        padding: '12px 20px',
                                        backgroundColor: userType === 'business' ? '#7C3AED' : 'transparent',
                                        color: userType === 'business' ? 'white' : '#6B7280',
                                        border: 'none',
                                        borderRadius: '8px',
                                        fontSize: '0.95rem',
                                        fontWeight: 600,
                                        cursor: 'pointer',
                                        transition: 'all 0.2s',
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                        gap: '8px'
                                    }}
                                >
                                    <i className="fas fa-building"></i>
                                    Entreprise
                                </button>
                            </div>
                        </div>

                        {/* Photo de profil */}
                        <div style={{ marginBottom: '32px' }}>
                            <label style={{
                                display: 'block',
                                fontSize: '0.9rem',
                                fontWeight: 600,
                                color: '#1F2937',
                                marginBottom: '12px'
                            }}>
                                Photo de profil
                            </label>
                            <div style={{
                                display: 'flex',
                                alignItems: 'center',
                                gap: '20px'
                            }}>
                                <img
                                    src={photoPreview}
                                    alt="Preview"
                                    style={{
                                        width: '100px',
                                        height: '100px',
                                        borderRadius: '50%',
                                        objectFit: 'cover',
                                        border: '3px solid #E5E7EB'
                                    }}
                                />
                                <div style={{ flex: 1 }}>
                                    <input
                                        ref={fileInputRef}
                                        type="file"
                                        accept="image/*"
                                        onChange={handlePhotoChange}
                                        style={{ display: 'none' }}
                                    />
                                    <button
                                        type="button"
                                        onClick={() => fileInputRef.current?.click()}
                                        style={{
                                            padding: '12px 20px',
                                            backgroundColor: '#F3F4F6',
                                            border: '1px solid #E5E7EB',
                                            borderRadius: '8px',
                                            color: '#1F2937',
                                            fontSize: '0.9rem',
                                            fontWeight: 600,
                                            cursor: 'pointer',
                                            transition: 'all 0.2s',
                                            display: 'inline-flex',
                                            alignItems: 'center',
                                            gap: '8px'
                                        }}
                                        onMouseEnter={(e) => {
                                            e.currentTarget.style.backgroundColor = '#E5E7EB';
                                        }}
                                        onMouseLeave={(e) => {
                                            e.currentTarget.style.backgroundColor = '#F3F4F6';
                                        }}
                                    >
                                        <i className="fas fa-camera"></i>
                                        Changer la photo
                                    </button>
                                    <p style={{
                                        marginTop: '8px',
                                        fontSize: '0.8rem',
                                        color: '#9CA3AF'
                                    }}>
                                        Format recommandé : carré, minimum 400x400px
                                    </p>
                                </div>
                            </div>
                        </div>

                        {/* Nom */}
                        <div style={{ marginBottom: '24px' }}>
                            <label style={{
                                display: 'block',
                                fontSize: '0.9rem',
                                fontWeight: 600,
                                color: '#1F2937',
                                marginBottom: '8px'
                            }}>
                                {getNameLabel()}
                            </label>
                            <input
                                type="text"
                                value={name}
                                onChange={(e) => {
                                    setName(e.target.value);
                                    if (errors.name) {
                                        setErrors({ ...errors, name: '' });
                                    }
                                }}
                                placeholder={getNamePlaceholder()}
                                style={{
                                    width: '100%',
                                    padding: '12px 16px',
                                    border: `1px solid ${errors.name ? '#EF4444' : '#E5E7EB'}`,
                                    borderRadius: '8px',
                                    fontSize: '0.95rem',
                                    fontFamily: 'Montserrat, sans-serif',
                                    transition: 'all 0.2s',
                                    backgroundColor: errors.name ? '#FEF2F2' : 'white'
                                }}
                                onFocus={(e) => {
                                    if (!errors.name) {
                                        e.currentTarget.style.borderColor = '#7C3AED';
                                        e.currentTarget.style.boxShadow = '0 0 0 3px rgba(124, 58, 237, 0.1)';
                                    }
                                }}
                                onBlur={(e) => {
                                    if (!errors.name) {
                                        e.currentTarget.style.borderColor = '#E5E7EB';
                                        e.currentTarget.style.boxShadow = 'none';
                                    }
                                }}
                            />
                            {errors.name && (
                                <p style={{
                                    marginTop: '6px',
                                    fontSize: '0.85rem',
                                    color: '#EF4444',
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '6px'
                                }}>
                                    <i className="fas fa-exclamation-circle"></i>
                                    {errors.name}
                                </p>
                            )}
                        </div>

                        {/* Description */}
                        <div style={{ marginBottom: '24px' }}>
                            <label style={{
                                display: 'block',
                                fontSize: '0.9rem',
                                fontWeight: 600,
                                color: '#1F2937',
                                marginBottom: '8px'
                            }}>
                                {getDescriptionLabel()}
                            </label>
                            <textarea
                                value={description}
                                onChange={(e) => {
                                    setDescription(e.target.value);
                                    if (errors.description) {
                                        setErrors({ ...errors, description: '' });
                                    }
                                }}
                                placeholder={getDescriptionPlaceholder()}
                                rows={4}
                                style={{
                                    width: '100%',
                                    padding: '12px 16px',
                                    border: `1px solid ${errors.description ? '#EF4444' : '#E5E7EB'}`,
                                    borderRadius: '8px',
                                    fontSize: '0.95rem',
                                    fontFamily: 'Montserrat, sans-serif',
                                    resize: 'vertical',
                                    transition: 'all 0.2s',
                                    backgroundColor: errors.description ? '#FEF2F2' : 'white'
                                }}
                                onFocus={(e) => {
                                    if (!errors.description) {
                                        e.currentTarget.style.borderColor = '#7C3AED';
                                        e.currentTarget.style.boxShadow = '0 0 0 3px rgba(124, 58, 237, 0.1)';
                                    }
                                }}
                                onBlur={(e) => {
                                    if (!errors.description) {
                                        e.currentTarget.style.borderColor = '#E5E7EB';
                                        e.currentTarget.style.boxShadow = 'none';
                                    }
                                }}
                            />
                            {errors.description && (
                                <p style={{
                                    marginTop: '6px',
                                    fontSize: '0.85rem',
                                    color: '#EF4444',
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '6px'
                                }}>
                                    <i className="fas fa-exclamation-circle"></i>
                                    {errors.description}
                                </p>
                            )}
                        </div>

                        {/* Section changement de mot de passe */}
                        <div style={{
                            marginBottom: '32px',
                            paddingTop: '24px',
                            borderTop: '1px solid #E5E7EB'
                        }}>
                            <button
                                type="button"
                                onClick={() => setShowPasswordSection(!showPasswordSection)}
                                style={{
                                    width: '100%',
                                    padding: '14px 20px',
                                    backgroundColor: '#F9FAFB',
                                    border: '1px solid #E5E7EB',
                                    borderRadius: '8px',
                                    color: '#1F2937',
                                    fontSize: '0.95rem',
                                    fontWeight: 600,
                                    cursor: 'pointer',
                                    transition: 'all 0.2s',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'space-between'
                                }}
                                onMouseEnter={(e) => {
                                    e.currentTarget.style.backgroundColor = '#F3F4F6';
                                }}
                                onMouseLeave={(e) => {
                                    e.currentTarget.style.backgroundColor = '#F9FAFB';
                                }}
                            >
                                <span style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                                    <i className="fas fa-lock"></i>
                                    Changer le mot de passe
                                </span>
                                <i className={`fas fa-chevron-${showPasswordSection ? 'up' : 'down'}`}></i>
                            </button>

                            {showPasswordSection && (
                                <div style={{
                                    marginTop: '20px',
                                    padding: '20px',
                                    backgroundColor: '#F9FAFB',
                                    borderRadius: '8px',
                                    border: '1px solid #E5E7EB'
                                }}>
                                    {/* Mot de passe actuel */}
                                    <div style={{ marginBottom: '20px' }}>
                                        <label style={{
                                            display: 'block',
                                            fontSize: '0.9rem',
                                            fontWeight: 600,
                                            color: '#1F2937',
                                            marginBottom: '8px'
                                        }}>
                                            Mot de passe actuel
                                        </label>
                                        <input
                                            type="password"
                                            value={currentPassword}
                                            onChange={(e) => {
                                                setCurrentPassword(e.target.value);
                                                if (errors.currentPassword) {
                                                    setErrors({ ...errors, currentPassword: '' });
                                                }
                                            }}
                                            placeholder="Entrez votre mot de passe actuel"
                                            style={{
                                                width: '100%',
                                                padding: '12px 16px',
                                                border: `1px solid ${errors.currentPassword ? '#EF4444' : '#E5E7EB'}`,
                                                borderRadius: '8px',
                                                fontSize: '0.95rem',
                                                fontFamily: 'Montserrat, sans-serif',
                                                backgroundColor: errors.currentPassword ? '#FEF2F2' : 'white'
                                            }}
                                        />
                                        {errors.currentPassword && (
                                            <p style={{
                                                marginTop: '6px',
                                                fontSize: '0.85rem',
                                                color: '#EF4444',
                                                display: 'flex',
                                                alignItems: 'center',
                                                gap: '6px'
                                            }}>
                                                <i className="fas fa-exclamation-circle"></i>
                                                {errors.currentPassword}
                                            </p>
                                        )}
                                    </div>

                                    {/* Nouveau mot de passe */}
                                    <div style={{ marginBottom: '20px' }}>
                                        <label style={{
                                            display: 'block',
                                            fontSize: '0.9rem',
                                            fontWeight: 600,
                                            color: '#1F2937',
                                            marginBottom: '8px'
                                        }}>
                                            Nouveau mot de passe
                                        </label>
                                        <input
                                            type="password"
                                            value={newPassword}
                                            onChange={(e) => {
                                                setNewPassword(e.target.value);
                                                if (errors.newPassword) {
                                                    setErrors({ ...errors, newPassword: '' });
                                                }
                                            }}
                                            placeholder="Minimum 8 caractères"
                                            style={{
                                                width: '100%',
                                                padding: '12px 16px',
                                                border: `1px solid ${errors.newPassword ? '#EF4444' : '#E5E7EB'}`,
                                                borderRadius: '8px',
                                                fontSize: '0.95rem',
                                                fontFamily: 'Montserrat, sans-serif',
                                                backgroundColor: errors.newPassword ? '#FEF2F2' : 'white'
                                            }}
                                        />
                                        {errors.newPassword && (
                                            <p style={{
                                                marginTop: '6px',
                                                fontSize: '0.85rem',
                                                color: '#EF4444',
                                                display: 'flex',
                                                alignItems: 'center',
                                                gap: '6px'
                                            }}>
                                                <i className="fas fa-exclamation-circle"></i>
                                                {errors.newPassword}
                                            </p>
                                        )}
                                    </div>

                                    {/* Confirmer mot de passe */}
                                    <div>
                                        <label style={{
                                            display: 'block',
                                            fontSize: '0.9rem',
                                            fontWeight: 600,
                                            color: '#1F2937',
                                            marginBottom: '8px'
                                        }}>
                                            Confirmer le mot de passe
                                        </label>
                                        <input
                                            type="password"
                                            value={confirmPassword}
                                            onChange={(e) => {
                                                setConfirmPassword(e.target.value);
                                                if (errors.confirmPassword) {
                                                    setErrors({ ...errors, confirmPassword: '' });
                                                }
                                            }}
                                            placeholder="Confirmer le nouveau mot de passe"
                                            style={{
                                                width: '100%',
                                                padding: '12px 16px',
                                                border: `1px solid ${errors.confirmPassword ? '#EF4444' : '#E5E7EB'}`,
                                                borderRadius: '8px',
                                                fontSize: '0.95rem',
                                                fontFamily: 'Montserrat, sans-serif',
                                                backgroundColor: errors.confirmPassword ? '#FEF2F2' : 'white'
                                            }}
                                        />
                                        {errors.confirmPassword && (
                                            <p style={{
                                                marginTop: '6px',
                                                fontSize: '0.85rem',
                                                color: '#EF4444',
                                                display: 'flex',
                                                alignItems: 'center',
                                                gap: '6px'
                                            }}>
                                                <i className="fas fa-exclamation-circle"></i>
                                                {errors.confirmPassword}
                                            </p>
                                        )}
                                    </div>
                                </div>
                            )}
                        </div>

                        {/* Boutons d'action */}
                        <div style={{
                            display: 'flex',
                            gap: '12px',
                            justifyContent: 'flex-end',
                            paddingTop: '24px',
                            borderTop: '1px solid #E5E7EB'
                        }}>
                            <Link
                                href="/dashboard/account"
                                style={{
                                    padding: '12px 24px',
                                    backgroundColor: '#F3F4F6',
                                    color: '#1F2937',
                                    border: '1px solid #E5E7EB',
                                    borderRadius: '8px',
                                    fontSize: '0.95rem',
                                    fontWeight: 600,
                                    textDecoration: 'none',
                                    transition: 'all 0.2s',
                                    display: 'inline-flex',
                                    alignItems: 'center',
                                    gap: '8px'
                                }}
                            >
                                Annuler
                            </Link>

                            <button
                                type="submit"
                                disabled={isLoading}
                                style={{
                                    padding: '12px 24px',
                                    backgroundColor: isLoading ? '#D1D5DB' : '#7C3AED',
                                    color: 'white',
                                    border: 'none',
                                    borderRadius: '8px',
                                    fontSize: '0.95rem',
                                    fontWeight: 600,
                                    cursor: isLoading ? 'not-allowed' : 'pointer',
                                    transition: 'all 0.2s',
                                    display: 'inline-flex',
                                    alignItems: 'center',
                                    gap: '8px',
                                    opacity: isLoading ? 0.6 : 1
                                }}
                                onMouseEnter={(e) => {
                                    if (!isLoading) {
                                        e.currentTarget.style.backgroundColor = '#6D28D9';
                                    }
                                }}
                                onMouseLeave={(e) => {
                                    if (!isLoading) {
                                        e.currentTarget.style.backgroundColor = '#7C3AED';
                                    }
                                }}
                            >
                                {isLoading ? (
                                    <>
                                        <i className="fas fa-spinner fa-spin"></i>
                                        Enregistrement...
                                    </>
                                ) : (
                                    <>
                                        <i className="fas fa-save"></i>
                                        Enregistrer
                                    </>
                                )}
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </>
    );
}
