'use client';

import React, { useState } from 'react';
import Link from 'next/link';

interface Follower {
    username: string;
    name: string;
    avatar: string;
    description: string;
    followersCount: number;
    certified: boolean;
    isFollowedBack: boolean;
}

const mockFollowers: Follower[] = [
    {
        username: 'alice_dev',
        name: 'Alice Martin',
        avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
        description: 'Designer UI/UX passionnée par l\'innovation',
        followersCount: 892,
        certified: false,
        isFollowedBack: true
    },
    {
        username: 'bob_tech',
        name: 'Bob Dupont',
        avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
        description: 'Développeur Backend | Python & Node.js',
        followersCount: 1234,
        certified: true,
        isFollowedBack: false
    },
    {
        username: 'claire_design',
        name: 'Claire Moreau',
        avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
        description: 'Graphiste freelance | Branding',
        followersCount: 567,
        certified: false,
        isFollowedBack: true
    },
    {
        username: 'thomas_code',
        name: 'Thomas Lefebvre',
        avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
        description: 'Full Stack Developer | React & TypeScript',
        followersCount: 2341,
        certified: true,
        isFollowedBack: false
    },
    {
        username: 'sophie_ux',
        name: 'Sophie Bernard',
        avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
        description: 'UX Researcher | Human-Centered Design',
        followersCount: 1876,
        certified: false,
        isFollowedBack: true
    }
];

export default function FollowersPage() {
    const [followers, setFollowers] = useState<Follower[]>(mockFollowers);

    const handleToggleFollow = (username: string) => {
        setFollowers(followers.map(follower => {
            if (follower.username === username) {
                return {
                    ...follower,
                    isFollowedBack: !follower.isFollowedBack
                };
            }
            return follower;
        }));
    };

    return (
        <>
            <link rel="stylesheet" href="/feed.css" />

            <div style={{
                maxWidth: '800px',
                margin: '0 auto',
                padding: '20px'
            }}>
                {/* En-tête */}
                <div style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    marginBottom: '24px',
                    paddingBottom: '16px',
                    borderBottom: '1px solid #E5E7EB'
                }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                        <i className="fas fa-users" style={{ color: '#7C3AED', fontSize: '1.5rem' }}></i>
                        <h1 style={{ color: '#1F2937', fontSize: '1.75rem', margin: 0, fontWeight: 700 }}>
                            Abonnés
                        </h1>
                    </div>
                    <Link
                        href="/dashboard/account"
                        style={{
                            display: 'inline-flex',
                            alignItems: 'center',
                            gap: '8px',
                            color: '#7C3AED',
                            textDecoration: 'none',
                            fontSize: '0.95rem',
                            fontWeight: 600,
                            transition: 'color 0.2s'
                        }}
                        onMouseEnter={(e) => e.currentTarget.style.color = '#6D28D9'}
                        onMouseLeave={(e) => e.currentTarget.style.color = '#7C3AED'}
                    >
                        <i className="fas fa-arrow-left"></i>
                        Retour au profil
                    </Link>
                </div>

                {/* Compteur */}
                <div style={{
                    marginBottom: '20px',
                    padding: '16px 20px',
                    background: '#F9FAFB',
                    borderRadius: '10px',
                    border: '1px solid #E5E7EB'
                }}>
                    <p style={{
                        margin: 0,
                        color: '#6B7280',
                        fontSize: '0.95rem',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '8px'
                    }}>
                        <i className="fas fa-info-circle" style={{ color: '#7C3AED' }}></i>
                        <strong style={{ color: '#1F2937' }}>{followers.length}</strong> personne{followers.length > 1 ? 's' : ''} vous {followers.length > 1 ? 'suivent' : 'suit'}
                    </p>
                </div>

                {/* Liste des abonnés */}
                <div style={{
                    background: 'white',
                    borderRadius: '12px',
                    boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06)',
                    border: '1px solid #E5E7EB',
                    overflow: 'hidden'
                }}>
                    {followers.length > 0 ? (
                        followers.map((follower, index) => (
                            <div
                                key={follower.username}
                                style={{
                                    padding: '20px',
                                    borderBottom: index < followers.length - 1 ? '1px solid #E5E7EB' : 'none',
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '16px',
                                    transition: 'background-color 0.2s'
                                }}
                                onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#F9FAFB'}
                                onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'white'}
                            >
                                {/* Avatar */}
                                <Link href={`/dashboard/account/user/${follower.username}`}>
                                    <img
                                        src={follower.avatar}
                                        alt={follower.name}
                                        style={{
                                            width: '60px',
                                            height: '60px',
                                            borderRadius: '50%',
                                            objectFit: 'cover',
                                            border: '2px solid #E5E7EB',
                                            cursor: 'pointer'
                                        }}
                                    />
                                </Link>

                                {/* Informations */}
                                <div style={{ flex: 1, minWidth: 0 }}>
                                    <Link
                                        href={`/dashboard/account/user/${follower.username}`}
                                        style={{
                                            textDecoration: 'none',
                                            display: 'block',
                                            marginBottom: '4px'
                                        }}
                                    >
                                        <div style={{
                                            display: 'flex',
                                            alignItems: 'center',
                                            gap: '6px',
                                            marginBottom: '4px'
                                        }}>
                                            <h3 style={{
                                                margin: 0,
                                                color: '#1F2937',
                                                fontSize: '1rem',
                                                fontWeight: 700,
                                                overflow: 'hidden',
                                                textOverflow: 'ellipsis',
                                                whiteSpace: 'nowrap'
                                            }}>
                                                {follower.name}
                                            </h3>
                                            {follower.certified && (
                                                <i className="fas fa-check-circle" style={{
                                                    color: '#7C3AED',
                                                    fontSize: '0.9rem'
                                                }}></i>
                                            )}
                                        </div>
                                    </Link>
                                    <p style={{
                                        margin: '0 0 6px 0',
                                        color: '#9CA3AF',
                                        fontSize: '0.9rem'
                                    }}>
                                        @{follower.username}
                                    </p>
                                    <p style={{
                                        margin: '0 0 6px 0',
                                        color: '#6B7280',
                                        fontSize: '0.9rem',
                                        overflow: 'hidden',
                                        textOverflow: 'ellipsis',
                                        whiteSpace: 'nowrap'
                                    }}>
                                        {follower.description}
                                    </p>
                                    <p style={{
                                        margin: 0,
                                        color: '#9CA3AF',
                                        fontSize: '0.85rem',
                                        display: 'flex',
                                        alignItems: 'center',
                                        gap: '4px'
                                    }}>
                                        <i className="fas fa-users" style={{ fontSize: '0.75rem' }}></i>
                                        {follower.followersCount.toLocaleString()} abonnés
                                    </p>
                                </div>

                                {/* Bouton Suivre / Déjà abonné */}
                                <button
                                    onClick={() => handleToggleFollow(follower.username)}
                                    style={{
                                        padding: '10px 20px',
                                        backgroundColor: follower.isFollowedBack ? 'white' : '#7C3AED',
                                        border: follower.isFollowedBack ? '1.5px solid #E5E7EB' : 'none',
                                        borderRadius: '8px',
                                        color: follower.isFollowedBack ? '#6B7280' : 'white',
                                        fontSize: '0.9rem',
                                        fontWeight: 600,
                                        cursor: 'pointer',
                                        transition: 'all 0.2s',
                                        whiteSpace: 'nowrap'
                                    }}
                                    onMouseEnter={(e) => {
                                        if (follower.isFollowedBack) {
                                            e.currentTarget.style.backgroundColor = '#F3F4F6';
                                            e.currentTarget.style.borderColor = '#D1D5DB';
                                        } else {
                                            e.currentTarget.style.backgroundColor = '#6D28D9';
                                        }
                                    }}
                                    onMouseLeave={(e) => {
                                        if (follower.isFollowedBack) {
                                            e.currentTarget.style.backgroundColor = 'white';
                                            e.currentTarget.style.borderColor = '#E5E7EB';
                                        } else {
                                            e.currentTarget.style.backgroundColor = '#7C3AED';
                                        }
                                    }}
                                >
                                    {follower.isFollowedBack ? (
                                        <>
                                            <i className="fas fa-check" style={{ marginRight: '6px' }}></i>
                                            Déjà abonné
                                        </>
                                    ) : (
                                        <>
                                            <i className="fas fa-user-plus" style={{ marginRight: '6px' }}></i>
                                            Suivre
                                        </>
                                    )}
                                </button>
                            </div>
                        ))
                    ) : (
                        <div style={{
                            padding: '60px 20px',
                            textAlign: 'center'
                        }}>
                            <i className="fas fa-users" style={{
                                fontSize: '3rem',
                                color: '#D1D5DB',
                                marginBottom: '16px',
                                display: 'block'
                            }}></i>
                            <p style={{
                                color: '#6B7280',
                                fontSize: '1rem',
                                margin: 0
                            }}>
                                Vous n'avez pas encore d'abonnés
                            </p>
                        </div>
                    )}
                </div>
            </div>
        </>
    );
}
