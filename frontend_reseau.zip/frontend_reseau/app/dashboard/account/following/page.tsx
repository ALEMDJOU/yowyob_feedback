'use client';

import React, { useState } from 'react';
import Link from 'next/link';

interface FollowingUser {
    username: string;
    name: string;
    avatar: string;
    description: string;
    followersCount: number;
    certified: boolean;
}

const mockFollowing: FollowingUser[] = [
    {
        username: 'techinnov',
        name: 'Tech Innov S.A.',
        avatar: 'https://i.ibb.co/6P8N9zR/company-logo.png',
        description: 'Innovation technologique au service des entreprises 🚀',
        followersCount: 3456,
        certified: true
    },
    {
        username: 'globalcorp',
        name: 'Global Corp',
        avatar: 'https://i.ibb.co/6P8N9zR/company-logo.png',
        description: 'Leader mondial des services professionnels',
        followersCount: 5231,
        certified: true
    },
    {
        username: 'designstudio',
        name: 'Design Studio',
        avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
        description: 'Créativité & Design | UI/UX',
        followersCount: 2187,
        certified: false
    },
    {
        username: 'devmaster',
        name: 'Dev Master',
        avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
        description: 'Full Stack Developer | Mentor',
        followersCount: 1543,
        certified: false
    }
];

export default function FollowingPage() {
    const [following, setFollowing] = useState<FollowingUser[]>(mockFollowing);

    const handleUnfollow = (username: string) => {
        // TODO: Implémenter l'appel API pour ne plus suivre
        setFollowing(following.filter(user => user.username !== username));
    };

    return (
        <>
            <link rel="stylesheet" href="/feed.css" />

            <div style={{
                maxWidth: '800px',
                margin: '0 auto',
                padding: '20px'
            }}>
                {/* En-tête */}
                <div style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    marginBottom: '24px',
                    paddingBottom: '16px',
                    borderBottom: '1px solid #E5E7EB'
                }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                        <i className="fas fa-user-friends" style={{ color: '#7C3AED', fontSize: '1.5rem' }}></i>
                        <h1 style={{ color: '#1F2937', fontSize: '1.75rem', margin: 0, fontWeight: 700 }}>
                            Abonnements
                        </h1>
                    </div>
                    <Link
                        href="/dashboard/account"
                        style={{
                            display: 'inline-flex',
                            alignItems: 'center',
                            gap: '8px',
                            color: '#7C3AED',
                            textDecoration: 'none',
                            fontSize: '0.95rem',
                            fontWeight: 600,
                            transition: 'color 0.2s'
                        }}
                        onMouseEnter={(e) => e.currentTarget.style.color = '#6D28D9'}
                        onMouseLeave={(e) => e.currentTarget.style.color = '#7C3AED'}
                    >
                        <i className="fas fa-arrow-left"></i>
                        Retour au profil
                    </Link>
                </div>

                {/* Compteur */}
                <div style={{
                    marginBottom: '20px',
                    padding: '16px 20px',
                    background: '#F9FAFB',
                    borderRadius: '10px',
                    border: '1px solid #E5E7EB'
                }}>
                    <p style={{
                        margin: 0,
                        color: '#6B7280',
                        fontSize: '0.95rem',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '8px'
                    }}>
                        <i className="fas fa-info-circle" style={{ color: '#7C3AED' }}></i>
                        Vous suivez <strong style={{ color: '#1F2937' }}>{following.length}</strong> compte{following.length > 1 ? 's' : ''}
                    </p>
                </div>

                {/* Liste des abonnements */}
                <div style={{
                    background: 'white',
                    borderRadius: '12px',
                    boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06)',
                    border: '1px solid #E5E7EB',
                    overflow: 'hidden'
                }}>
                    {following.length > 0 ? (
                        following.map((user, index) => (
                            <div
                                key={user.username}
                                style={{
                                    padding: '20px',
                                    borderBottom: index < following.length - 1 ? '1px solid #E5E7EB' : 'none',
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '16px',
                                    transition: 'background-color 0.2s'
                                }}
                                onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#F9FAFB'}
                                onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'white'}
                            >
                                {/* Avatar */}
                                <Link href={`/dashboard/account/user/${user.username}`}>
                                    <img
                                        src={user.avatar}
                                        alt={user.name}
                                        style={{
                                            width: '60px',
                                            height: '60px',
                                            borderRadius: '50%',
                                            objectFit: 'cover',
                                            border: '2px solid #E5E7EB',
                                            cursor: 'pointer'
                                        }}
                                    />
                                </Link>

                                {/* Informations */}
                                <div style={{ flex: 1, minWidth: 0 }}>
                                    <Link
                                        href={`/dashboard/account/user/${user.username}`}
                                        style={{
                                            textDecoration: 'none',
                                            display: 'block',
                                            marginBottom: '4px'
                                        }}
                                    >
                                        <div style={{
                                            display: 'flex',
                                            alignItems: 'center',
                                            gap: '6px',
                                            marginBottom: '4px'
                                        }}>
                                            <h3 style={{
                                                margin: 0,
                                                color: '#1F2937',
                                                fontSize: '1rem',
                                                fontWeight: 700,
                                                overflow: 'hidden',
                                                textOverflow: 'ellipsis',
                                                whiteSpace: 'nowrap'
                                            }}>
                                                {user.name}
                                            </h3>
                                            {user.certified && (
                                                <i className="fas fa-check-circle" style={{
                                                    color: '#7C3AED',
                                                    fontSize: '0.9rem'
                                                }}></i>
                                            )}
                                        </div>
                                    </Link>
                                    <p style={{
                                        margin: '0 0 6px 0',
                                        color: '#9CA3AF',
                                        fontSize: '0.9rem'
                                    }}>
                                        @{user.username}
                                    </p>
                                    <p style={{
                                        margin: '0 0 6px 0',
                                        color: '#6B7280',
                                        fontSize: '0.9rem',
                                        overflow: 'hidden',
                                        textOverflow: 'ellipsis',
                                        whiteSpace: 'nowrap'
                                    }}>
                                        {user.description}
                                    </p>
                                    <p style={{
                                        margin: 0,
                                        color: '#9CA3AF',
                                        fontSize: '0.85rem',
                                        display: 'flex',
                                        alignItems: 'center',
                                        gap: '4px'
                                    }}>
                                        <i className="fas fa-users" style={{ fontSize: '0.75rem' }}></i>
                                        {user.followersCount.toLocaleString()} abonnés
                                    </p>
                                </div>

                                {/* Bouton Ne plus suivre */}
                                <button
                                    onClick={() => handleUnfollow(user.username)}
                                    style={{
                                        padding: '10px 20px',
                                        backgroundColor: 'white',
                                        border: '1.5px solid #E5E7EB',
                                        borderRadius: '8px',
                                        color: '#6B7280',
                                        fontSize: '0.9rem',
                                        fontWeight: 600,
                                        cursor: 'pointer',
                                        transition: 'all 0.2s',
                                        whiteSpace: 'nowrap'
                                    }}
                                    onMouseEnter={(e) => {
                                        e.currentTarget.style.backgroundColor = '#FEF2F2';
                                        e.currentTarget.style.borderColor = '#EF4444';
                                        e.currentTarget.style.color = '#EF4444';
                                    }}
                                    onMouseLeave={(e) => {
                                        e.currentTarget.style.backgroundColor = 'white';
                                        e.currentTarget.style.borderColor = '#E5E7EB';
                                        e.currentTarget.style.color = '#6B7280';
                                    }}
                                >
                                    <i className="fas fa-user-minus" style={{ marginRight: '6px' }}></i>
                                    Ne plus suivre
                                </button>
                            </div>
                        ))
                    ) : (
                        <div style={{
                            padding: '60px 20px',
                            textAlign: 'center'
                        }}>
                            <i className="fas fa-user-friends" style={{
                                fontSize: '3rem',
                                color: '#D1D5DB',
                                marginBottom: '16px',
                                display: 'block'
                            }}></i>
                            <p style={{
                                color: '#6B7280',
                                fontSize: '1rem',
                                margin: 0
                            }}>
                                Vous ne suivez personne pour le moment
                            </p>
                        </div>
                    )}
                </div>
            </div>
        </>
    );
}
