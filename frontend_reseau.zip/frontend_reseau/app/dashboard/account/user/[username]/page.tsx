"use client";
import React, { useEffect } from 'react';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import FollowButton from '@/components/FollowButton';
import ProjectFeedbackGroup from '@/components/ProjectFeedbackGroup';
import { FeedbackData } from '@/components/FeedbackCard';

// Données de test - à remplacer par des appels API
const getUserProfile = (username: string) => {
    const profiles: Record<string, any> = {
        techinnov: {
            name: 'Tech Innov S.A.',
            avatar: 'https://i.ibb.co/6P8N9zR/company-logo.png',
            description: 'Innovation technologique au service des entreprises 🚀 | Solutions digitales sur mesure',
            followersCount: 3456,
            followingCount: 892,
            feedbacksCount: 127,
            type: 'business',
            certified: true
        },
        globalcorp: {
            name: 'Global Corp',
            avatar: 'https://i.ibb.co/6P8N9zR/company-logo.png',
            description: 'Leader mondial des services professionnels | Support client d\'excellence',
            followersCount: 5231,
            followingCount: 1204,
            feedbacksCount: 203,
            type: 'business',
            certified: true
        },
        designstudio: {
            name: 'Design Studio',
            avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
            description: 'Créativité & Design | UI/UX | Identité visuelle',
            followersCount: 2187,
            followingCount: 643,
            feedbacksCount: 89,
            type: 'business',
            certified: false
        }
    };

    return profiles[username as string] || {
        name: username,
        avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
        description: 'Membre actif de la communauté Yowyob',
        followersCount: 0,
        followingCount: 0,
        feedbacksCount: 0,
        type: 'person',
        certified: false
    };
};

// Feedbacks groupés par projet - données de test
const getProjectFeedbacks = (username: string) => {
    const allFeedbacks: Record<string, any> = {
        techinnov: {
            'quantum-leap': {
                projectName: 'Quantum Leap',
                projectAvatar: 'https://i.ibb.co/6P8N9zR/company-logo.png',
                feedbacks: [
                    {
                        id: 'f1',
                        businessName: 'Tech Innov S.A.',
                        businessLogo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
                        businessUsername: 'techinnov',
                        projectName: 'Quantum Leap',
                        projectAvatar: 'https://i.ibb.co/6P8N9zR/company-logo.png',
                        projectId: 'quantum-leap',
                        time: '2 jours',
                        content: 'Excellent travail sur ce projet innovant ! L\'équipe a su transformer notre vision en réalité avec une approche professionnelle et créative.',
                        likes: 45,
                        liked: false,
                        comments: []
                    },
                    {
                        id: 'f2',
                        businessName: 'Tech Innov S.A.',
                        businessLogo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
                        businessUsername: 'techinnov',
                        projectName: 'Quantum Leap',
                        projectAvatar: 'https://i.ibb.co/6P8N9zR/company-logo.png',
                        projectId: 'quantum-leap',
                        time: '5 jours',
                        content: 'La phase de développement s\'est très bien déroulée. Communication fluide et livraison dans les délais.',
                        likes: 32,
                        liked: false,
                        comments: []
                    }
                ]
            },
            'ai-assistant': {
                projectName: 'AI Assistant Pro',
                projectAvatar: 'https://i.ibb.co/6P8N9zR/company-logo.png',
                feedbacks: [
                    {
                        id: 'f3',
                        businessName: 'Tech Innov S.A.',
                        businessLogo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
                        businessUsername: 'techinnov',
                        projectName: 'AI Assistant Pro',
                        projectAvatar: 'https://i.ibb.co/6P8N9zR/company-logo.png',
                        projectId: 'ai-assistant',
                        time: '1 semaine',
                        content: 'L\'intégration de l\'IA a été parfaitement réalisée. Nos utilisateurs adorent la nouvelle fonctionnalité !',
                        likes: 67,
                        liked: false,
                        comments: []
                    }
                ]
            }
        }
    };

    return allFeedbacks[username as string] || {};
};

export default function UserProfilePage() {
    const params = useParams();
    const username = (params?.username as string) || 'utilisateur';

    const profile = getUserProfile(username);
    const projectGroups = getProjectFeedbacks(username);

    // Scroll vers le projet si un hash est présent
    useEffect(() => {
        if (window.location.hash) {
            const element = document.querySelector(window.location.hash);
            if (element) {
                setTimeout(() => {
                    element.scrollIntoView({ behavior: 'smooth' });
                }, 100);
            }
        }
    }, []);

    return (
        <>
            <div className="content-header">
                <div className="header-title">
                    <i className="fas fa-user title-icon"></i>
                    <h1>Profil Utilisateur</h1>
                </div>
            </div>

            <div className="profile-page">
                {/* Header profil type Instagram */}
                <section className="profile-header-ig">
                    <div className="profile-avatar-container-ig">
                        <img
                            src={profile.avatar}
                            alt={`Photo de profil de ${profile.name}`}
                            width={150}
                            height={150}
                            className="profile-avatar-ig"
                        />
                    </div>

                    <div className="profile-info-container-ig">
                        <div className="profile-top-row-ig">
                            <h1 className="profile-username-ig">{profile.name}</h1>
                            {profile.certified && (
                                <i className="fas fa-check-circle certified-icon-ig" title="Compte certifié"></i>
                            )}
                            <FollowButton username={username} size="large" />
                        </div>

                        <div className="profile-stats-ig">
                            <span className="stat-item-ig">
                                <span className="stat-number">{profile.feedbacksCount}</span> feedbacks
                            </span>
                            <Link href="/dashboard/account/followers" className="stat-item-ig link">
                                <span className="stat-number">{profile.followersCount.toLocaleString()}</span> abonnés
                            </Link>
                            <Link href="/dashboard/account/following" className="stat-item-ig link">
                                <span className="stat-number">{profile.followingCount.toLocaleString()}</span> abonnements
                            </Link>
                        </div>

                        <div className="profile-bio-ig">
                            <p className="profile-description-ig">{profile.description}</p>
                        </div>
                    </div>
                </section>

                <hr className="separator-ig" />

                {/* Feedbacks regroupés par projet */}
                <section className="profile-feedbacks-section">
                    <h2 className="feedbacks-section-title">
                        <i className="fas fa-comment-dots"></i> Feedbacks par projet
                    </h2>

                    {Object.keys(projectGroups).length > 0 ? (
                        <div className="project-groups-container">
                            {Object.entries(projectGroups).map(([projectId, group]: [string, any]) => (
                                <ProjectFeedbackGroup
                                    key={projectId}
                                    projectId={projectId}
                                    projectName={group.projectName}
                                    projectAvatar={group.projectAvatar}
                                    feedbacks={group.feedbacks as FeedbackData[]}
                                    initiallyExpanded={window.location.hash === `#project-${projectId}`}
                                />
                            ))}
                        </div>
                    ) : (
                        <div className="no-feedbacks-message">
                            <i className="fas fa-inbox"></i>
                            <p>Aucun feedback pour le moment</p>
                        </div>
                    )}
                </section>
            </div>
        </>
    );
}
