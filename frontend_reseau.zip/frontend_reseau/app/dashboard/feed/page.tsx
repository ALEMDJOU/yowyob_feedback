"use client";

import React from 'react';
import Script from 'next/script';
import { useTranslation } from '@/components/I18nProvider';
import FeedbackCard, { FeedbackData } from '@/components/FeedbackCard';
import HorizontalSuggestions from '@/components/HorizontalSuggestions';
import { SuggestionData } from '@/lib/mockData';

export default function FeedPage() {
    const { t } = useTranslation();

    const suggestions: SuggestionData[] = [
        {
            id: '1',
            name: 'Tech Innov S.A.',
            username: 'techinnov',
            avatar: 'https://i.ibb.co/6P8N9zR/company-logo.png',
            bio: 'Innovation technologique au service des entreprises',
            followers: 3456,
            isFollowing: false,
            type: 'company'
        },
        {
            id: '2',
            name: 'Global Corp',
            username: 'globalcorp',
            avatar: 'https://i.ibb.co/6P8N9zR/company-logo.png',
            bio: 'Leader mondial des services professionnels',
            followers: 5231,
            isFollowing: false,
            type: 'company'
        },
        {
            id: '3',
            name: 'Design Studio',
            username: 'designstudio',
            avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
            bio: 'Créativité & Design | UI/UX',
            followers: 2187,
            isFollowing: false,
            type: 'company'
        },
        {
            id: '4',
            name: 'Henri Fofack',
            username: 'hfofack',
            avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
            bio: 'Développeur Full Stack passionné',
            followers: 892,
            isFollowing: true,
            type: 'intern'
        },
        {
            id: '5',
            name: 'Sophie Martin',
            username: 'smartin',
            avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
            bio: 'Designer UI/UX • Creative Director',
            followers: 1543,
            isFollowing: false,
            type: 'intern'
        }
    ];

    const initialFeedbacks: FeedbackData[] = [
        {
            id: '1',
            businessName: 'Tech Innov S.A.',
            businessLogo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
            businessUsername: 'techinnov',
            projectName: 'Quantum Leap',
            projectAvatar: 'https://i.ibb.co/6P8N9zR/company-logo.png',
            projectId: 'quantum-leap',
            time: '5 minutes',
            content: 'Interface très intuitive et fonctionnalités innovantes. L\'équipe a vraiment écouté nos besoins et a livré un produit de qualité. Recommandé !',
            likes: 12,
            liked: false,
            comments: [
                {
                    id: 'c1',
                    author: 'Marie Dubois',
                    text: 'Très intéressant ! J\'ai hâte de tester 🎉',
                    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
                    likes: 3,
                    liked: false,
                    replies: [],
                    isAnonymous: false
                },
                {
                    id: 'c2',
                    author: 'Membre anonyme',
                    text: 'Excellente initiative ! Je confirme la qualité du produit.',
                    likes: 1,
                    liked: false,
                    replies: [],
                    isAnonymous: true
                }
            ]
        },
        {
            id: '2',
            businessName: 'Global Corp',
            businessLogo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
            businessUsername: 'globalcorp',
            projectName: 'Service Client Premium',
            projectAvatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
            projectId: 'service-client',
            time: '1 heure',
            content: 'Le service client a été exceptionnel. Réponse rapide, professionnelle et solution adaptée à notre problème. Vraiment satisfait de cette expérience !',
            likes: 45,
            liked: false,
            comments: [
                {
                    id: 'c3',
                    author: 'Sophie Laurent',
                    text: 'Je confirme, leur service est top ! 👍',
                    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
                    likes: 5,
                    liked: true,
                    replies: [],
                    isAnonymous: false
                }
            ]
        }
    ];

    return (
        <>
            <link rel="stylesheet" href="/feed.css" />

            <header className="content-header">
                <div className="header-title">
                    <i className="fas fa-globe-americas title-icon"></i>
                    <h1>{t('feed.title')}</h1>
                </div>
            </header>

            <div className="control-bar">
                <div className="search-box">
                    <i className="fas fa-search search-icon"></i>
                    <input type="text" placeholder={t('feed.searchPlaceholder')} />
                </div>
            </div>

            {/* Affichage des 2 premiers feedbacks */}
            <section className="feedback-section">
                {initialFeedbacks.slice(0, 2).map(data => (
                    <FeedbackCard key={data.id} data={data} />
                ))}
            </section>

            {/* Section personnes/entreprises à suivre - après les 2 premiers feedbacks */}
            <HorizontalSuggestions
                suggestions={suggestions}
                title={t('feed.featuredTitle')}
            />

            <hr className="section-separator" />

            {/* Affichage du reste des feedbacks (à partir du 3ème) */}
            <section className="feedback-section">
                {initialFeedbacks.slice(2).map(data => (
                    <FeedbackCard key={data.id} data={data} />
                ))}
            </section>

            <Script src="/feed.js" strategy="lazyOnload" />
        </>
    );
}
