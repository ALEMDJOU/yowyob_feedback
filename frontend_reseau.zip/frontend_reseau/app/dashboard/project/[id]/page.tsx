'use client';

import React, { useState } from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import FeedbackCard, { FeedbackData } from '@/components/FeedbackCard';

// Données mock pour le groupe
const getProjectData = (id: string) => {
    const projects: Record<string, any> = {
        'p1-bd-group': {
            name: 'Groupe BD',
            description: 'Projet de base de données collaborative pour le suivi des tâches.',
            avatar: 'https://i.ibb.co/6P8N9zR/company-logo.png',
            membersCount: 12,
            role: 'admin'
        },
        'p2-kadea-stage': {
            name: 'Stage Kadea',
            description: 'Accompagnement et suivi du stage chez Kadea Tech.',
            avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
            membersCount: 5,
            role: 'invite'
        },
        'p3-react-proj': {
            name: 'Projet React',
            description: 'Développement d\'une application React moderne avec TypeScript.',
            avatar: 'https://i.ibb.co/6P8N9zR/company-logo.png',
            membersCount: 8,
            role: 'admin'
        },
    };
    return projects[id] || {
        name: 'Projet',
        description: 'Description du projet',
        avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
        membersCount: 0,
        role: 'invite'
    };
};

// Feedbacks mock pour le projet
const getProjectFeedbacks = (id: string): FeedbackData[] => {
    return [
        {
            id: '1',
            businessName: 'Alice Martin',
            businessLogo: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
            businessUsername: 'alice',
            projectName: getProjectData(id).name,
            projectAvatar: getProjectData(id).avatar,
            projectId: id,
            time: 'Il y a 2 heures',
            content: 'Excellente avancée sur le projet cette semaine ! L\'équipe a réussi à livrer toutes les fonctionnalités prévues. Bravo à tous pour votre travail acharné. 🎉',
            likes: 8,
            liked: false,
            comments: [
                {
                    id: 'c1',
                    author: 'Bob Dupont',
                    text: 'Merci Alice ! C\'était un vrai plaisir de collaborer sur ce sprint.',
                    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
                    likes: 2,
                    liked: false,
                    replies: [],
                    isAnonymous: false
                }
            ]
        },
        {
            id: '2',
            businessName: 'Sophie Bernard',
            businessLogo: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
            businessUsername: 'sophie',
            projectName: getProjectData(id).name,
            projectAvatar: getProjectData(id).avatar,
            projectId: id,
            time: 'Hier à 15:30',
            content: 'Petit rappel : la réunion de sprint planning est prévue demain à 10h. Merci de préparer vos points à discuter. 📅',
            likes: 5,
            liked: true,
            comments: []
        },
        {
            id: '3',
            businessName: 'Thomas Lefebvre',
            businessLogo: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
            businessUsername: 'thomas',
            projectName: getProjectData(id).name,
            projectAvatar: getProjectData(id).avatar,
            projectId: id,
            time: 'Il y a 3 jours',
            content: 'J\'ai mis à jour la documentation du projet. Vous pouvez la consulter dans l\'onglet "Ressources". N\'hésitez pas si vous avez des questions ! 📚',
            likes: 12,
            liked: false,
            comments: [
                {
                    id: 'c2',
                    author: 'Claire Moreau',
                    text: 'Super, merci Thomas ! 👍',
                    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
                    likes: 1,
                    liked: false,
                    replies: [],
                    isAnonymous: false
                },
                {
                    id: 'c3',
                    author: 'Membre anonyme',
                    text: 'Très utile, merci !',
                    likes: 0,
                    liked: false,
                    replies: [],
                    isAnonymous: true
                }
            ]
        }
    ];
};

export default function ProjectDetailPage() {
    const params = useParams();
    const projectId = params?.id as string;
    const project = getProjectData(projectId);
    const feedbacks = getProjectFeedbacks(projectId);
    const [showNewPostBox, setShowNewPostBox] = useState(false);
    const [newPostContent, setNewPostContent] = useState('');
    const [showEmojiPicker, setShowEmojiPicker] = useState(false);

    const emojis = ['😊', '❤️', '👍', '🎉', '🔥', '💯', '👏', '🙌', '😍', '🎯', '✨', '💪', '🚀', '⭐', '💡', '🎊'];

    const handlePublish = () => {
        if (newPostContent.trim()) {
            // TODO: Envoyer le nouveau post via API
            setNewPostContent('');
            setShowNewPostBox(false);
            setShowEmojiPicker(false);
        }
    };

    const addEmoji = (emoji: string) => {
        setNewPostContent(prev => prev + emoji);
    };

    return (
        <>
            <link rel="stylesheet" href="/feed.css" />

            {/* En-tête du projet */}
            <div style={{
                background: 'white',
                borderRadius: '12px',
                padding: '24px',
                marginBottom: '20px',
                boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06)',
                border: '1px solid #E5E7EB'
            }}>
                {/* Bouton retour */}
                <Link
                    href="/dashboard/project"
                    style={{
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: '8px',
                        color: '#7C3AED',
                        textDecoration: 'none',
                        fontSize: '0.95rem',
                        fontWeight: 600,
                        marginBottom: '20px',
                        transition: 'color 0.2s'
                    }}
                    onMouseEnter={(e) => e.currentTarget.style.color = '#6D28D9'}
                    onMouseLeave={(e) => e.currentTarget.style.color = '#7C3AED'}
                >
                    <i className="fas fa-arrow-left"></i>
                    Retour aux projets
                </Link>

                {/* Informations du groupe */}
                <div style={{ display: 'flex', alignItems: 'flex-start', gap: '20px' }}>
                    <img
                        src={project.avatar}
                        alt={project.name}
                        style={{
                            width: '80px',
                            height: '80px',
                            borderRadius: '16px',
                            objectFit: 'cover',
                            border: '2px solid #E5E7EB'
                        }}
                    />
                    <div style={{ flex: 1 }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '8px' }}>
                            <h1 style={{
                                margin: 0,
                                color: '#1F2937',
                                fontSize: '1.75rem',
                                fontWeight: 700
                            }}>
                                {project.name}
                            </h1>
                            {project.role === 'admin' && (
                                <span style={{
                                    backgroundColor: '#7C3AED',
                                    color: 'white',
                                    padding: '4px 12px',
                                    borderRadius: '6px',
                                    fontSize: '0.75rem',
                                    fontWeight: 600,
                                    textTransform: 'uppercase'
                                }}>
                                    Admin
                                </span>
                            )}
                        </div>
                        <p style={{
                            color: '#6B7280',
                            fontSize: '0.95rem',
                            margin: '0 0 12px 0',
                            lineHeight: 1.5
                        }}>
                            {project.description}
                        </p>
                        <div style={{
                            display: 'flex',
                            alignItems: 'center',
                            gap: '6px',
                            color: '#9CA3AF',
                            fontSize: '0.9rem'
                        }}>
                            <i className="fas fa-users"></i>
                            <span>{project.membersCount} membres</span>
                        </div>
                    </div>
                </div>
            </div>

            {/* Fil de publications */}
            <section className="feedback-section" style={{ marginTop: '20px' }}>
                {feedbacks.map(feedback => (
                    <FeedbackCard key={feedback.id} data={feedback} hideProjectInfo={true} />
                ))}
            </section>

            {/* Zone de création de nouvelle publication - en bas */}
            <div style={{
                background: 'white',
                borderRadius: '12px',
                padding: '20px',
                marginTop: '20px',
                boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06)',
                border: '1px solid #E5E7EB'
            }}>
                {!showNewPostBox ? (
                    <button
                        onClick={() => setShowNewPostBox(true)}
                        style={{
                            width: '100%',
                            padding: '14px 20px',
                            backgroundColor: '#F9FAFB',
                            border: '1px solid #E5E7EB',
                            borderRadius: '10px',
                            color: '#6B7280',
                            fontSize: '0.95rem',
                            textAlign: 'left',
                            cursor: 'pointer',
                            transition: 'all 0.2s ease'
                        }}
                        onMouseEnter={(e) => {
                            e.currentTarget.style.backgroundColor = '#F3F4F6';
                            e.currentTarget.style.borderColor = '#D1D5DB';
                        }}
                        onMouseLeave={(e) => {
                            e.currentTarget.style.backgroundColor = '#F9FAFB';
                            e.currentTarget.style.borderColor = '#E5E7EB';
                        }}
                    >
                        <i className="fas fa-edit" style={{ marginRight: '10px' }}></i>
                        Partager une mise à jour avec le groupe...
                    </button>
                ) : (
                    <div>
                        <textarea
                            value={newPostContent}
                            onChange={(e) => setNewPostContent(e.target.value)}
                            placeholder="Quoi de neuf dans ce projet ?"
                            style={{
                                width: '100%',
                                minHeight: '120px',
                                padding: '14px',
                                border: '1px solid #E5E7EB',
                                borderRadius: '10px',
                                fontSize: '0.95rem',
                                fontFamily: 'Montserrat, sans-serif',
                                resize: 'vertical',
                                marginBottom: '12px'
                            }}
                        />

                        {/* Sélecteur d'emojis */}
                        <div style={{ marginBottom: '12px' }}>
                            <button
                                onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                                style={{
                                    padding: '8px 14px',
                                    backgroundColor: '#F3F4F6',
                                    border: '1px solid #E5E7EB',
                                    borderRadius: '8px',
                                    color: '#6B7280',
                                    fontSize: '0.9rem',
                                    cursor: 'pointer',
                                    transition: 'all 0.2s',
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '6px'
                                }}
                                type="button"
                            >
                                <i className="far fa-smile"></i>
                                {showEmojiPicker ? 'Masquer emojis' : 'Ajouter emoji'}
                            </button>

                            {showEmojiPicker && (
                                <div style={{
                                    display: 'flex',
                                    flexWrap: 'wrap',
                                    gap: '8px',
                                    marginTop: '10px',
                                    padding: '12px',
                                    backgroundColor: '#F9FAFB',
                                    borderRadius: '10px',
                                    border: '1px solid #E5E7EB'
                                }}>
                                    {emojis.map(emoji => (
                                        <button
                                            key={emoji}
                                            onClick={() => addEmoji(emoji)}
                                            style={{
                                                background: 'white',
                                                border: '1px solid #E5E7EB',
                                                borderRadius: '6px',
                                                padding: '8px 10px',
                                                fontSize: '1.3rem',
                                                cursor: 'pointer',
                                                transition: 'all 0.2s',
                                                minWidth: '44px',
                                                height: '44px',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center'
                                            }}
                                            onMouseEnter={(e) => {
                                                e.currentTarget.style.backgroundColor = '#F3F4F6';
                                                e.currentTarget.style.transform = 'scale(1.1)';
                                            }}
                                            onMouseLeave={(e) => {
                                                e.currentTarget.style.backgroundColor = 'white';
                                                e.currentTarget.style.transform = 'scale(1)';
                                            }}
                                            type="button"
                                        >
                                            {emoji}
                                        </button>
                                    ))}
                                </div>
                            )}
                        </div>

                        <div style={{ display: 'flex', gap: '10px', justifyContent: 'flex-end' }}>
                            <button
                                onClick={() => {
                                    setShowNewPostBox(false);
                                    setNewPostContent('');
                                    setShowEmojiPicker(false);
                                }}
                                style={{
                                    padding: '10px 20px',
                                    backgroundColor: '#F3F4F6',
                                    border: '1px solid #E5E7EB',
                                    borderRadius: '8px',
                                    color: '#6B7280',
                                    fontSize: '0.9rem',
                                    fontWeight: 600,
                                    cursor: 'pointer',
                                    transition: 'all 0.2s'
                                }}
                            >
                                Annuler
                            </button>
                            <button
                                onClick={handlePublish}
                                disabled={!newPostContent.trim()}
                                style={{
                                    padding: '10px 20px',
                                    backgroundColor: newPostContent.trim() ? '#7C3AED' : '#D1D5DB',
                                    border: 'none',
                                    borderRadius: '8px',
                                    color: 'white',
                                    fontSize: '0.9rem',
                                    fontWeight: 600,
                                    cursor: newPostContent.trim() ? 'pointer' : 'not-allowed',
                                    transition: 'all 0.2s'
                                }}
                            >
                                Publier
                            </button>
                        </div>
                    </div>
                )}
            </div>
        </>
    );
}
