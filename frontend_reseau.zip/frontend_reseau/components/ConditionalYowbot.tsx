'use client';

import { usePathname } from 'next/navigation';
import YowbotFAB from './YowbotFAB';

export default function ConditionalYowbot() {
  const pathname = usePathname();

  // Ne pas afficher sur la page d'accueil et les pages auth
  if (pathname === '/' || pathname.startsWith('/auth')) {
    return null;
  }

  return <YowbotFAB />;
}
