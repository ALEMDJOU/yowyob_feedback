'use client';

import React from 'react';
import { usePathname } from 'next/navigation';
import { useTranslation } from './I18nProvider';

// Configuration des routes avec icônes et clés de traduction
const ROUTE_CONFIG: Record<
  string,
  {
    icon: string;
    titleKey: string;
  }
> = {
  '/dashboard/feed': {
    icon: 'fa-globe-americas',
    titleKey: 'feed.title',
  },
  '/dashboard/follow': {
    icon: 'fa-bell',
    titleKey: 'sidebar.subscriptions',
  },
  '/dashboard/project': {
    icon: 'fa-folder-open',
    titleKey: 'sidebar.projects',
  },
  '/dashboard/account': {
    icon: 'fa-user-circle',
    titleKey: 'sidebar.account',
  },
  '/dashboard/yowbot': {
    icon: 'fa-robot',
    titleKey: 'Yowbot',
  },
};

interface DynamicPageHeaderProps {
  // Titre personnalisé (remplace la détection automatique)
  customTitle?: string;
  // Icône personnalisée (remplace la détection automatique)
  customIcon?: string;
  // Afficher le bouton toggle menu pour mobile
  showMenuToggle?: boolean;
  // Callback pour le bouton menu
  onMenuToggle?: () => void;
  // Actions optionnelles (boutons droite)
  actions?: React.ReactNode;
}

export default function DynamicPageHeader({
  customTitle,
  customIcon,
  showMenuToggle = false,
  onMenuToggle,
  actions,
}: DynamicPageHeaderProps) {
  const pathname = usePathname();
  const { t } = useTranslation();

  // Déterminer la configuration de la route
  const routeConfig = pathname ? ROUTE_CONFIG[pathname] : null;

  // Déterminer l'icône à afficher
  const icon =
    customIcon || routeConfig?.icon || 'fa-file-alt'; // Icône par défaut

  // Déterminer le titre à afficher
  const title = customTitle
    ? customTitle
    : routeConfig?.titleKey
      ? t(routeConfig.titleKey)
      : 'Dashboard';

  return (
    <header className="content-header">
      <div className="header-title">
        {/* Bouton menu pour mobile (optionnel) */}
        {showMenuToggle && (
          <button
            className="menu-toggle-btn"
            onClick={onMenuToggle}
            aria-label="Toggle menu"
          >
            <i className="fas fa-bars"></i>
          </button>
        )}

        {/* Icône de la page */}
        <i className={`fas ${icon} title-icon`}></i>

        {/* Titre de la page */}
        <h1>{title}</h1>
      </div>

      {/* Actions optionnelles */}
      {actions && <div className="header-actions">{actions}</div>}
    </header>
  );
}
