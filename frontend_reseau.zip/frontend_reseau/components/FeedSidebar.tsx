"use client";
import { useEffect, useRef } from 'react';
import { useTranslation } from './I18nProvider';
import Image from 'next/image';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';

type Props = {
  isCollapsed: boolean;
  toggleSidebar: () => void;
  isMobile?: boolean; // Nouveau: indique si on est en mode mobile
};

export default function FeedSidebar({ isCollapsed, toggleSidebar, isMobile = false }: Props) {
  const { t } = useTranslation();
  const pathname = usePathname();
  const sidebarRef = useRef<HTMLElement>(null);
  const firstFocusableElementRef = useRef<HTMLElement | null>(null);
  const lastFocusableElementRef = useRef<HTMLElement | null>(null);

  const isActive = (path: string) => pathname === path || pathname?.startsWith(path + '/');

  // Gestion touche Escape pour fermer le drawer mobile
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isMobile && !isCollapsed) {
        toggleSidebar();
      }
    };

    document.addEventListener('keydown', handleEscape);
    return () => document.removeEventListener('keydown', handleEscape);
  }, [isMobile, isCollapsed, toggleSidebar]);

  // Focus trap pour le drawer mobile
  useEffect(() => {
    if (!isMobile || isCollapsed || !sidebarRef.current) return;

    const sidebar = sidebarRef.current;
    const focusableElements = sidebar.querySelectorAll<HTMLElement>(
      'a[href], button:not([disabled]), [tabindex]:not([tabindex="-1"])'
    );

    if (focusableElements.length > 0) {
      firstFocusableElementRef.current = focusableElements[0];
      lastFocusableElementRef.current = focusableElements[focusableElements.length - 1];

      // Focus sur le premier élément quand le drawer s'ouvre
      firstFocusableElementRef.current?.focus();
    }

    const handleTabKey = (e: KeyboardEvent) => {
      if (e.key !== 'Tab') return;

      if (e.shiftKey) {
        // Shift + Tab : si on est sur le premier élément, aller au dernier
        if (document.activeElement === firstFocusableElementRef.current) {
          e.preventDefault();
          lastFocusableElementRef.current?.focus();
        }
      } else {
        // Tab : si on est sur le dernier élément, aller au premier
        if (document.activeElement === lastFocusableElementRef.current) {
          e.preventDefault();
          firstFocusableElementRef.current?.focus();
        }
      }
    };

    document.addEventListener('keydown', handleTabKey);
    return () => document.removeEventListener('keydown', handleTabKey);
  }, [isMobile, isCollapsed]);

  // Variantes d'animation pour Framer Motion
  const sidebarVariants = {
    open: {
      x: 0,
      transition: {
        type: 'spring' as const,
        stiffness: 300,
        damping: 30,
      },
    },
    closed: {
      x: '-100%',
      transition: {
        type: 'spring' as const,
        stiffness: 300,
        damping: 30,
      },
    },
  };

  const overlayVariants = {
    open: {
      opacity: 1,
      transition: {
        duration: 0.3,
      },
    },
    closed: {
      opacity: 0,
      transition: {
        duration: 0.3,
      },
    },
  };

  return (
    <>
      {/* Overlay/Backdrop pour mobile */}
      <AnimatePresence>
        {isMobile && !isCollapsed && (
          <motion.div
            className="sidebar-overlay"
            initial="closed"
            animate="open"
            exit="closed"
            variants={overlayVariants}
            onClick={toggleSidebar}
            aria-hidden="true"
            role="presentation"
          />
        )}
      </AnimatePresence>

      {/* Sidebar avec animation */}
      {isMobile ? (
        <motion.aside
          ref={sidebarRef}
          className={`sidebar ${isMobile ? 'sidebar-mobile' : ''}`}
          initial="closed"
          animate={isCollapsed ? 'closed' : 'open'}
          variants={sidebarVariants}
          aria-label={t('sidebar.navigationLabel') || 'Navigation principale'}
          aria-expanded={!isCollapsed}
          role="navigation"
        >
          <div className="sidebar-header">
            <Image src="/images/logo.jpg" alt="" width={35} height={35} className="logo-image" aria-hidden="true" />
            <span className="app-name" aria-label={t('sidebar.appName')}>{t('sidebar.appName')}</span>
          </div>

          <nav className="main-nav" aria-label={t('sidebar.mainNavLabel') || 'Menu principal'}>
            <ul role="list">
              <li className={isActive('/dashboard/feed') ? 'active' : ''}>
                <Link
                  href="/dashboard/feed"
                  onClick={() => isMobile && toggleSidebar()}
                  aria-label={t('sidebar.feed')}
                  aria-current={isActive('/dashboard/feed') ? 'page' : undefined}
                >
                  <i className="fas fa-globe-americas icon" aria-hidden="true" /> <span>{t('sidebar.feed')}</span>
                </Link>
              </li>
              <li className={isActive('/dashboard/follow') ? 'active' : ''}>
                <Link
                  href="/dashboard/follow"
                  onClick={() => isMobile && toggleSidebar()}
                  aria-label={t('sidebar.subscriptions')}
                  aria-current={isActive('/dashboard/follow') ? 'page' : undefined}
                >
                  <i className="fas fa-bell icon" aria-hidden="true" /> <span>{t('sidebar.subscriptions')}</span>
                </Link>
              </li>
              <li className={isActive('/dashboard/project') ? 'active' : ''}>
                <Link
                  href="/dashboard/project"
                  onClick={() => isMobile && toggleSidebar()}
                  aria-label={t('sidebar.projects')}
                  aria-current={isActive('/dashboard/project') ? 'page' : undefined}
                >
                  <i className="fas fa-folder-open icon" aria-hidden="true" /> <span>{t('sidebar.projects')}</span>
                </Link>
              </li>
              <li className={isActive('/dashboard/account') ? 'active' : ''}>
                <Link
                  href="/dashboard/account"
                  onClick={() => isMobile && toggleSidebar()}
                  aria-label={t('sidebar.account')}
                  aria-current={isActive('/dashboard/account') ? 'page' : undefined}
                >
                  <i className="fas fa-user-circle icon" aria-hidden="true" /> <span>{t('sidebar.account')}</span>
                </Link>
              </li>
            </ul>
          </nav>

          <div className="sidebar-logout-container">
            <Link
              href="/"
              className="logout-button"
              aria-label={t('sidebar.logout')}
            >
              <i className="fas fa-sign-out-alt" aria-hidden="true" />
              <span>{t('sidebar.logout')}</span>
            </Link>
          </div>
        </motion.aside>
      ) : (
        // Version desktop (sans animation)
        <aside
          ref={sidebarRef}
          className={`sidebar ${isCollapsed ? 'collapsed' : ''}`}
          aria-label={t('sidebar.navigationLabel') || 'Navigation principale'}
          aria-expanded={!isCollapsed}
          role="navigation"
        >
          <div className="sidebar-header">
            <Image src="/images/logo.jpg" alt="" width={35} height={35} className="logo-image" aria-hidden="true" />
            <span className="app-name" aria-label={t('sidebar.appName')}>{t('sidebar.appName')}</span>
          </div>

          <nav className="main-nav" aria-label={t('sidebar.mainNavLabel') || 'Menu principal'}>
            <ul role="list">
              <li className={isActive('/dashboard/feed') ? 'active' : ''}>
                <Link
                  href="/dashboard/feed"
                  aria-label={t('sidebar.feed')}
                  aria-current={isActive('/dashboard/feed') ? 'page' : undefined}
                >
                  <i className="fas fa-globe-americas icon" aria-hidden="true" /> <span>{t('sidebar.feed')}</span>
                </Link>
              </li>
              <li className={isActive('/dashboard/follow') ? 'active' : ''}>
                <Link
                  href="/dashboard/follow"
                  aria-label={t('sidebar.subscriptions')}
                  aria-current={isActive('/dashboard/follow') ? 'page' : undefined}
                >
                  <i className="fas fa-bell icon" aria-hidden="true" /> <span>{t('sidebar.subscriptions')}</span>
                </Link>
              </li>
              <li className={isActive('/dashboard/project') ? 'active' : ''}>
                <Link
                  href="/dashboard/project"
                  aria-label={t('sidebar.projects')}
                  aria-current={isActive('/dashboard/project') ? 'page' : undefined}
                >
                  <i className="fas fa-folder-open icon" aria-hidden="true" /> <span>{t('sidebar.projects')}</span>
                </Link>
              </li>
              <li className={isActive('/dashboard/account') ? 'active' : ''}>
                <Link
                  href="/dashboard/account"
                  aria-label={t('sidebar.account')}
                  aria-current={isActive('/dashboard/account') ? 'page' : undefined}
                >
                  <i className="fas fa-user-circle icon" aria-hidden="true" /> <span>{t('sidebar.account')}</span>
                </Link>
              </li>
            </ul>
          </nav>

          <div className="sidebar-logout-container">
            <Link
              href="/"
              className="logout-button"
              aria-label={t('sidebar.logout')}
            >
              <i className="fas fa-sign-out-alt" aria-hidden="true" />
              <span>{t('sidebar.logout')}</span>
            </Link>
          </div>
        </aside>
      )}
    </>
  );
}
