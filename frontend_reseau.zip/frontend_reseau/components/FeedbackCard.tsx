'use client';

import React, { useState } from 'react';
import Link from 'next/link';

// Types
export interface Comment {
    id: string;
    author: string;
    text: string;
    avatar?: string;
    likes: number;
    liked: boolean;
    replies: Comment[];
    isAnonymous?: boolean;
}

export interface FeedbackData {
    id: string;
    // Informations entreprise/utilisateur propriétaire du groupe
    businessName: string;
    businessLogo: string;
    businessUsername?: string; // Pour la navigation

    // Informations projet
    projectName: string;
    projectAvatar: string;
    projectId?: string;

    // Contenu feedback
    time: string;
    content: string;
    likes: number;
    liked: boolean;
    comments: Comment[];

    // Backwards compatibility (deprecated)
    author?: string;
    authorAvatar?: string;
    type?: 'person' | 'business';
    isAnonymous?: boolean;
}

// Helper to generate IDs
const generateId = () => Math.random().toString(36).substr(2, 9);

// Recursive Comment Component
const CommentItem = ({
    comment,
    onLike,
    onReply
}: {
    comment: Comment;
    onLike: (id: string) => void;
    onReply: (parentId: string, text: string) => void;
}) => {
    return (
        <div style={{ marginTop: '12px', position: 'relative' }}>
            <div style={{ display: 'flex', gap: '10px', alignItems: 'flex-start' }}>
                {comment.isAnonymous ? (
                    <div style={{
                        width: '32px',
                        height: '32px',
                        borderRadius: '50%',
                        background: 'linear-gradient(135deg, #6A1B9A, #8E24AA)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        color: '#fff',
                        fontSize: '0.9rem',
                        flexShrink: 0
                    }}>
                        <i className="fas fa-user-secret"></i>
                    </div>
                ) : (
                    <img
                        src={comment.avatar || 'https://i.ibb.co/Qf983vG/avatar-placeholder.png'}
                        alt={comment.author}
                        width={32}
                        height={32}
                        style={{ borderRadius: '50%', flexShrink: 0 }}
                    />
                )}
                <div style={{ flex: 1 }}>
                    <div style={{ backgroundColor: '#f5f5f5', borderRadius: '12px', padding: '10px' }}>
                        <div style={{ fontSize: '0.85rem', fontWeight: 'bold', color: '#333', marginBottom: '4px' }}>
                            {comment.author}
                            {comment.isAnonymous && <span style={{ fontSize: '0.75rem', color: '#999', marginLeft: '6px' }}>
                                <i className="fas fa-mask"></i> Anonyme
                            </span>}
                        </div>
                        <p style={{ fontSize: '0.9rem', color: '#444', margin: 0, lineHeight: 1.4 }}>
                            {comment.text}
                        </p>
                    </div>

                    <div style={{ display: 'flex', gap: '15px', marginTop: '4px', marginLeft: '10px', fontSize: '0.8rem' }}>
                        <button
                            onClick={() => onLike(comment.id)}
                            style={{
                                background: 'none',
                                border: 'none',
                                cursor: 'pointer',
                                color: comment.liked ? '#6A1B9A' : '#666',
                                fontWeight: comment.liked ? 'bold' : 'normal',
                                display: 'flex',
                                alignItems: 'center',
                                gap: '4px'
                            }}
                        >
                            <i className="fas fa-thumbs-up"></i>
                            {comment.likes > 0 && <span> ({comment.likes})</span>}
                        </button>
                        <span style={{ color: '#999' }}>· 2h</span>
                    </div>
                </div>
            </div>
        </div>
    );
};

interface FeedbackCardProps {
    data: FeedbackData;
    hideProjectInfo?: boolean; // Masquer les infos du projet quand on est dans un groupe
}

export default function FeedbackCard({ data, hideProjectInfo = false }: FeedbackCardProps) {
    const [feedback, setFeedback] = useState<FeedbackData>(data);
    const [showComments, setShowComments] = useState(false);
    const [showCommentBox, setShowCommentBox] = useState(false);
    const [mainCommentText, setMainCommentText] = useState("");
    const [isAnonymousComment, setIsAnonymousComment] = useState(false);

    const emojis = ['😊', '❤️', '👍', '🎉', '🔥', '💯', '👏', '🙌'];

    const handleFeedbackLike = () => {
        setFeedback(prev => ({
            ...prev,
            liked: !prev.liked,
            likes: prev.liked ? prev.likes - 1 : prev.likes + 1
        }));
    };

    const findCommentAndAction = (comments: Comment[], targetId: string, action: (c: Comment) => Comment): Comment[] => {
        return comments.map(c => {
            if (c.id === targetId) return action(c);
            if (c.replies.length > 0) return { ...c, replies: findCommentAndAction(c.replies, targetId, action) };
            return c;
        });
    };

    const handleCommentLike = (commentId: string) => {
        setFeedback(prev => ({
            ...prev,
            comments: findCommentAndAction(prev.comments, commentId, (c) => ({
                ...c,
                liked: !c.liked,
                likes: c.liked ? c.likes - 1 : c.likes + 1
            }))
        }));
    };

    const handleMainCommentSubmit = () => {
        if (mainCommentText.trim()) {
            setFeedback(prev => ({
                ...prev,
                comments: [...prev.comments, {
                    id: generateId(),
                    author: isAnonymousComment ? 'Utilisateur anonyme' : 'Moi',
                    text: mainCommentText,
                    likes: 0,
                    liked: false,
                    replies: [],
                    isAnonymous: isAnonymousComment
                }]
            }));
            setMainCommentText("");
            setIsAnonymousComment(false);
        }
    };

    const handleCommentClick = () => {
        setShowComments(!showComments);
        if (!showComments) {
            setShowCommentBox(true);
        }
    };

    const addEmoji = (emoji: string) => setMainCommentText(prev => prev + emoji);

    // Construire l'URL du compte utilisateur (avec ancre projet pour les feedbacks)
    const userAccountUrl = feedback.businessUsername
        ? `/dashboard/account/user/${feedback.businessUsername}${feedback.projectId ? `#project-${feedback.projectId}` : ''}`
        : '#';

    // URL du profil utilisateur (sans ancre projet)
    const userProfileUrl = feedback.businessUsername
        ? `/dashboard/account/user/${feedback.businessUsername}`
        : '#';

    return (
        <div className="feedback-card">
            {/* Header avec logo entreprise et nom */}
            <div className="feedback-header">
                <Link href={userProfileUrl}>
                    <img
                        src={feedback.businessLogo}
                        alt={feedback.businessName}
                        width={45}
                        height={45}
                        className="feedback-avatar"
                        style={{ cursor: 'pointer' }}
                    />
                </Link>
                <div className="feedback-meta">
                    <Link
                        href={userProfileUrl}
                        className="feedback-author"
                        style={{
                            textDecoration: 'none',
                            color: 'inherit',
                            cursor: 'pointer',
                            transition: 'color 0.2s ease'
                        }}
                        onMouseEnter={(e) => e.currentTarget.style.color = '#7C3AED'}
                        onMouseLeave={(e) => e.currentTarget.style.color = 'inherit'}
                    >
                        {feedback.businessName}
                    </Link>
                    <span className="feedback-time">
                        <i className="fas fa-clock"></i> {feedback.time}
                    </span>
                </div>
            </div>

            {/* Mention du projet avec photo - masqué si on est dans le groupe */}
            {!hideProjectInfo && (
                <div className="feedback-project-info">
                    <span className="feedback-project-label">Feedback sur le projet</span>
                    <Link href={userAccountUrl} className="feedback-project-link">
                        <img
                            src={feedback.projectAvatar}
                            alt={feedback.projectName}
                            width={32}
                            height={32}
                            className="feedback-project-avatar"
                        />
                        <span className="feedback-project-name">{feedback.projectName}</span>
                    </Link>
                </div>
            )}

            {/* Contenu du feedback */}
            <div className="feedback-content">
                <p>{feedback.content}</p>
            </div>

            {/* Actions */}
            <div className="feedback-actions">
                <button
                    onClick={handleFeedbackLike}
                    className={`feedback-action-btn ${feedback.liked ? 'liked' : ''}`}
                    aria-label={`J'aime (${feedback.likes})`}
                >
                    <i className="fas fa-thumbs-up"></i> J&apos;aime ({feedback.likes})
                </button>
                <button
                    onClick={handleCommentClick}
                    className="feedback-action-btn"
                    aria-label="Commenter"
                >
                    <i className="fas fa-comment"></i> Commenter
                    {feedback.comments.length > 0 && ` (${feedback.comments.length})`}
                </button>
            </div>

            {/* Zone de commentaires */}
            {showComments && (
                <div className="feedback-comments-section">
                    {/* Liste des commentaires */}
                    {feedback.comments.length > 0 && (
                        <div className="feedback-comments-list">
                            {feedback.comments.map(comment => (
                                <CommentItem
                                    key={comment.id}
                                    comment={comment}
                                    onLike={handleCommentLike}
                                    onReply={() => { }}
                                />
                            ))}
                        </div>
                    )}

                    {/* Zone de saisie de commentaire */}
                    {showCommentBox && (
                        <div className="feedback-comment-box">
                            <div className="emoji-picker">
                                {emojis.map(emoji => (
                                    <button
                                        key={emoji}
                                        onClick={() => addEmoji(emoji)}
                                        className="emoji-btn"
                                        aria-label={`Ajouter ${emoji}`}
                                    >
                                        {emoji}
                                    </button>
                                ))}
                            </div>

                            <label className="anonymous-checkbox">
                                <input
                                    type="checkbox"
                                    checked={isAnonymousComment}
                                    onChange={(e) => setIsAnonymousComment(e.target.checked)}
                                />
                                <i className="fas fa-mask"></i>
                                Commenter anonymement
                            </label>

                            <div className="comment-input-container">
                                <input
                                    type="text"
                                    value={mainCommentText}
                                    onChange={(e) => setMainCommentText(e.target.value)}
                                    placeholder="Écrire un commentaire..."
                                    className="comment-input"
                                    onKeyDown={(e) => e.key === 'Enter' && handleMainCommentSubmit()}
                                    aria-label="Écrire un commentaire"
                                />
                                <button
                                    onClick={handleMainCommentSubmit}
                                    disabled={!mainCommentText.trim()}
                                    className="comment-submit-btn"
                                    aria-label="Envoyer le commentaire"
                                >
                                    Envoyer
                                </button>
                            </div>
                        </div>
                    )}
                </div>
            )}
        </div>
    );
}
