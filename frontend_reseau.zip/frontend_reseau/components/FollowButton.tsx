'use client';

import React, { useState } from 'react';

interface FollowButtonProps {
    username: string;
    initialFollowing?: boolean;
    size?: 'small' | 'medium' | 'large';
    className?: string;
}

export default function FollowButton({
    username,
    initialFollowing = false,
    size = 'medium',
    className = ''
}: FollowButtonProps) {
    const [isFollowing, setIsFollowing] = useState(initialFollowing);
    const [isLoading, setIsLoading] = useState(false);

    const handleToggleFollow = async () => {
        setIsLoading(true);

        // Simuler un appel API
        await new Promise(resolve => setTimeout(resolve, 500));

        setIsFollowing(!isFollowing);
        setIsLoading(false);
    };

    const sizeClasses = {
        small: 'follow-btn-small',
        medium: 'follow-btn-medium',
        large: 'follow-btn-large'
    };

    return (
        <button
            onClick={handleToggleFollow}
            disabled={isLoading}
            className={`follow-btn ${sizeClasses[size]} ${isFollowing ? 'following' : 'not-following'} ${className}`}
            aria-label={isFollowing ? `Ne plus suivre ${username}` : `Suivre ${username}`}
        >
            {isLoading ? (
                <i className="fas fa-spinner fa-spin"></i>
            ) : (
                <>
                    {isFollowing ? (
                        <>
                            <i className="fas fa-check"></i> Déjà abonné
                        </>
                    ) : (
                        <>
                            <i className="fas fa-plus"></i> À suivre
                        </>
                    )}
                </>
            )}
        </button>
    );
}
