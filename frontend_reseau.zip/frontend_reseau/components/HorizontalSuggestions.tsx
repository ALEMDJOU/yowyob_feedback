'use client';

import { useState } from 'react';
import Link from 'next/link';
import { SuggestionData } from '@/lib/mockData';
import './HorizontalSuggestions.css';

interface HorizontalSuggestionsProps {
  suggestions: SuggestionData[];
  title?: string;
}

export default function HorizontalSuggestions({
  suggestions,
  title = 'Personnes à suivre',
}: HorizontalSuggestionsProps) {
  // State local pour gérer le statut de suivi de chaque suggestion
  const [followStates, setFollowStates] = useState<Record<string, boolean>>(
    suggestions.reduce(
      (acc, suggestion) => ({
        ...acc,
        [suggestion.id]: suggestion.isFollowing,
      }),
      {}
    )
  );

  const handleToggleFollow = (suggestionId: string) => {
    setFollowStates((prev) => ({
      ...prev,
      [suggestionId]: !prev[suggestionId],
    }));
  };

  if (suggestions.length === 0) {
    return null;
  }

  return (
    <div className="horizontal-suggestions-container">
      <div className="suggestions-header">
        <h3 className="suggestions-title">
          <i className="fas fa-user-plus"></i> {title}
        </h3>
      </div>

      <div className="suggestions-scroll">
        {suggestions.map((suggestion) => (
          <div key={suggestion.id} className="suggestion-card">
            {/* Avatar */}
            <Link
              href={`/dashboard/account/user/${suggestion.username}`}
              className="suggestion-avatar-link"
            >
              <img
                src={suggestion.avatar}
                alt={suggestion.name}
                className="suggestion-avatar"
              />
            </Link>

            {/* Info */}
            <div className="suggestion-info">
              <Link
                href={`/dashboard/account/user/${suggestion.username}`}
                className="suggestion-name-link"
              >
                <h4 className="suggestion-name">{suggestion.name}</h4>
              </Link>

              <p className="suggestion-username">@{suggestion.username}</p>

              <p className="suggestion-bio">{suggestion.bio}</p>

              <div className="suggestion-stats">
                <span className="followers-count">
                  <i className="fas fa-users"></i>{' '}
                  {suggestion.followers.toLocaleString()} abonnés
                </span>
              </div>
            </div>

            {/* Bouton Suivre */}
            <button
              className={`follow-btn ${followStates[suggestion.id] ? 'following' : ''}`}
              onClick={() => handleToggleFollow(suggestion.id)}
            >
              {followStates[suggestion.id] ? (
                <>
                  <i className="fas fa-check"></i> Déjà abonné
                </>
              ) : (
                <>
                  <i className="fas fa-user-plus"></i> Suivre
                </>
              )}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
