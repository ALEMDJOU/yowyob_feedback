// components/JsonLd.tsx
import React from 'react';

export function OrganizationJsonLd() {
  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    name: 'Yowyob Feedback',
    url: 'https://yowyob-feedback.com',
    logo: 'https://yowyob-feedback.com/images/logo.jpg',
    description: 'Plateforme de feedbacks authentiques sur les stages et formations',
    sameAs: [
      'https://facebook.com/yowyob',
      'https://twitter.com/yowyob',
      'https://linkedin.com/company/yowyob',
    ],
    contactPoint: {
      '@type': 'ContactPoint',
      contactType: 'Customer Service',
      email: 'contact@yowyob-feedback.com',
    },
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
    />
  );
}

export function WebsiteJsonLd() {
  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'WebSite',
    name: 'Yowyob Feedback',
    url: 'https://yowyob-feedback.com',
    description: 'Consultez et partagez des feedbacks authentiques sur les stages, formations et expériences professionnelles',
    potentialAction: {
      '@type': 'SearchAction',
      target: {
        '@type': 'EntryPoint',
        urlTemplate: 'https://yowyob-feedback.com/search?q={search_term_string}',
      },
      'query-input': 'required name=search_term_string',
    },
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
    />
  );
}
