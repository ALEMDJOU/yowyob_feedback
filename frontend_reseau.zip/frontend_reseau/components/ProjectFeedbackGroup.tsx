'use client';

import React, { useState } from 'react';
import FeedbackCard, { FeedbackData } from './FeedbackCard';

interface ProjectFeedbackGroupProps {
    projectName: string;
    projectAvatar: string;
    projectId: string;
    feedbacks: FeedbackData[];
    initiallyExpanded?: boolean;
}

export default function ProjectFeedbackGroup({
    projectName,
    projectAvatar,
    projectId,
    feedbacks,
    initiallyExpanded = false
}: ProjectFeedbackGroupProps) {
    const [isExpanded, setIsExpanded] = useState(initiallyExpanded);

    return (
        <div className="project-feedback-group" id={`project-${projectId}`}>
            <button
                className="project-group-header"
                onClick={() => setIsExpanded(!isExpanded)}
                aria-expanded={isExpanded}
                aria-controls={`project-content-${projectId}`}
            >
                <div className="project-group-info">
                    <img
                        src={projectAvatar}
                        alt={projectName}
                        width={40}
                        height={40}
                        className="project-group-avatar"
                    />
                    <div className="project-group-text">
                        <h3 className="project-group-name">{projectName}</h3>
                        <span className="project-group-count">
                            {feedbacks.length} feedback{feedbacks.length > 1 ? 's' : ''}
                        </span>
                    </div>
                </div>
                <i className={`fas fa-chevron-${isExpanded ? 'up' : 'down'} project-group-icon`}></i>
            </button>

            {isExpanded && (
                <div
                    id={`project-content-${projectId}`}
                    className="project-group-content"
                >
                    {feedbacks.map(feedback => (
                        <FeedbackCard key={feedback.id} data={feedback} />
                    ))}
                </div>
            )}
        </div>
    );
}
