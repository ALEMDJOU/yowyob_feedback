// ============================================================================
// INTERFACES TYPESCRIPT
// ============================================================================

// Interface pour les commentaires (réutilisée de FeedbackCard)
export interface Comment {
  id: string;
  author: string;
  text: string;
  avatar?: string;
  likes: number;
  liked: boolean;
  replies: Comment[];
}

// Stagiaire (celui qui donne le feedback)
export interface Intern {
  id: string;
  username: string;
  displayName: string;
  avatar: string;
  bio: string;
  profession: string;
  followers: number;
  following: number;
  feedbacksCount: number;
  isVerified: boolean;
}

// Entreprise (propriétaire du projet)
export interface Company {
  id: string;
  username: string;
  displayName: string;
  logo: string;
  bio: string;
  website?: string;
  location: string;
  domain: string;
  isVerified: boolean;
  followers: number;
  following: number;
  projectsCount: number;
}

// Projet d'entreprise
export interface Project {
  id: string;
  name: string;
  companyId: string;
  coverImage: string;
  description: string;
  startDate: Date;
  endDate?: Date;
}

// Feedback (témoignage stagiaire sur un projet) - NOUVELLE STRUCTURE
export interface FeedbackData {
  id: string;

  // Qui a donné le feedback (stagiaire)
  intern: {
    id: string;
    name: string;
    username: string;
    avatar: string;
    role: string; // "Stagiaire chez Tech Innov"
  };

  // Sur quel projet (appartient à une entreprise)
  project: {
    id: string;
    name: string;
    image: string;
    companyId: string;
  };

  // Entreprise propriétaire du projet
  company: {
    id: string;
    name: string;
    username: string;
    logo: string;
  };

  content: string;
  timestamp: Date;
  likes: number;
  liked: boolean;
  comments: Comment[];
  isPublic: boolean;
}

// Suggestion pour "Personnes à suivre"
export interface SuggestionData {
  id: string;
  name: string;
  username: string;
  avatar: string;
  bio: string;
  followers: number;
  isFollowing: boolean;
  type: 'intern' | 'company';
}

// Groupe de projet avec ses feedbacks
export interface ProjectGroup {
  project: Project;
  feedbackCount: number;
  totalLikes: number;
  topContributors: { name: string; avatar: string }[];
  previewFeedbacks: FeedbackData[];
}

// ============================================================================
// DONNÉES MOCK - ENTREPRISES
// ============================================================================

export const mockCompanies: Company[] = [
  {
    id: 'comp-1',
    username: 'tech_innov_sa',
    displayName: 'Tech Innov S.A.',
    logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    bio: 'Leader de l\'innovation en solutions logicielles d\'entreprise',
    website: 'https://techinnov.com',
    location: 'Paris, France',
    domain: 'Technologies de l\'information',
    isVerified: true,
    followers: 5420,
    following: 234,
    projectsCount: 18,
  },
  {
    id: 'comp-2',
    username: 'global_corp',
    displayName: 'Global Corp',
    logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    bio: 'Solutions mondiales pour les entreprises du Fortune 500',
    website: 'https://globalcorp.com',
    location: 'Lyon, France',
    domain: 'Conseil en stratégie',
    isVerified: true,
    followers: 8920,
    following: 156,
    projectsCount: 24,
  },
  {
    id: 'comp-3',
    username: 'startup_x',
    displayName: 'StartupX',
    logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    bio: 'Startup innovante dans la fintech 🚀',
    website: 'https://startupx.io',
    location: 'Marseille, France',
    domain: 'Fintech',
    isVerified: false,
    followers: 1250,
    following: 89,
    projectsCount: 6,
  },
  {
    id: 'comp-4',
    username: 'digital_factory',
    displayName: 'Digital Factory',
    logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    bio: 'Agence digitale créative spécialisée en UX/UI',
    website: 'https://digitalfactory.fr',
    location: 'Toulouse, France',
    domain: 'Design & Créativité',
    isVerified: true,
    followers: 3680,
    following: 421,
    projectsCount: 32,
  },
  {
    id: 'comp-5',
    username: 'ecotech_solutions',
    displayName: 'EcoTech Solutions',
    logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    bio: 'Technologies vertes pour un avenir durable 🌱',
    website: 'https://ecotech.com',
    location: 'Bordeaux, France',
    domain: 'Énergies renouvelables',
    isVerified: true,
    followers: 2890,
    following: 167,
    projectsCount: 12,
  },
  {
    id: 'comp-6',
    username: 'data_analytics_pro',
    displayName: 'Data Analytics Pro',
    logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    bio: 'Experts en analyse de données et intelligence artificielle',
    location: 'Nantes, France',
    domain: 'Data Science & IA',
    isVerified: false,
    followers: 4120,
    following: 203,
    projectsCount: 15,
  },
  {
    id: 'comp-7',
    username: 'mobile_first_dev',
    displayName: 'Mobile First Dev',
    logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    bio: 'Développement d\'applications mobiles iOS et Android',
    website: 'https://mobilefirstdev.com',
    location: 'Lille, France',
    domain: 'Développement mobile',
    isVerified: true,
    followers: 5670,
    following: 312,
    projectsCount: 28,
  },
  {
    id: 'comp-8',
    username: 'cloud_masters',
    displayName: 'Cloud Masters',
    logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    bio: 'Infrastructure cloud et DevOps excellence',
    website: 'https://cloudmasters.io',
    location: 'Strasbourg, France',
    domain: 'Cloud Computing',
    isVerified: true,
    followers: 6890,
    following: 145,
    projectsCount: 19,
  },
  {
    id: 'comp-9',
    username: 'gaming_studio_fr',
    displayName: 'Gaming Studio FR',
    logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    bio: 'Studio de développement de jeux vidéo indépendant 🎮',
    website: 'https://gamingstudio.fr',
    location: 'Montpellier, France',
    domain: 'Jeux vidéo',
    isVerified: false,
    followers: 12450,
    following: 567,
    projectsCount: 8,
  },
  {
    id: 'comp-10',
    username: 'cyber_security_experts',
    displayName: 'Cyber Security Experts',
    logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    bio: 'Protection avancée contre les cybermenaces 🔒',
    website: 'https://cybersec-experts.com',
    location: 'Nice, France',
    domain: 'Cybersécurité',
    isVerified: true,
    followers: 7230,
    following: 98,
    projectsCount: 14,
  },
];

// ============================================================================
// DONNÉES MOCK - PROJETS
// ============================================================================

export const mockProjects: Project[] = [
  // Tech Innov S.A. projects
  {
    id: 'proj-1',
    name: 'Quantum Leap Platform',
    companyId: 'comp-1',
    coverImage: '/images/project-quantum.jpg',
    description: 'Plateforme d\'infrastructure cloud nouvelle génération',
    startDate: new Date('2024-01-15'),
    endDate: new Date('2024-06-30'),
  },
  {
    id: 'proj-2',
    name: 'SmartAI Dashboard',
    companyId: 'comp-1',
    coverImage: '/images/project-ai.jpg',
    description: 'Tableau de bord IA pour l\'analyse prédictive',
    startDate: new Date('2024-02-01'),
    endDate: new Date('2024-08-31'),
  },
  {
    id: 'proj-3',
    name: 'Enterprise Mobile Suite',
    companyId: 'comp-1',
    coverImage: '/images/project-mobile.jpg',
    description: 'Suite mobile pour la gestion d\'entreprise',
    startDate: new Date('2023-11-01'),
    endDate: new Date('2024-04-30'),
  },

  // Global Corp projects
  {
    id: 'proj-4',
    name: 'Digital Transformation Initiative',
    companyId: 'comp-2',
    coverImage: '/images/project-transform.jpg',
    description: 'Programme de transformation numérique pour grandes entreprises',
    startDate: new Date('2024-01-01'),
    endDate: new Date('2024-12-31'),
  },
  {
    id: 'proj-5',
    name: 'Supply Chain Optimizer',
    companyId: 'comp-2',
    coverImage: '/images/project-supply.jpg',
    description: 'Optimisation de la chaîne logistique par l\'IA',
    startDate: new Date('2024-03-01'),
  },

  // StartupX projects
  {
    id: 'proj-6',
    name: 'CryptoWallet Pro',
    companyId: 'comp-3',
    coverImage: '/images/project-crypto.jpg',
    description: 'Portefeuille crypto multi-devises sécurisé',
    startDate: new Date('2024-02-15'),
    endDate: new Date('2024-07-15'),
  },
  {
    id: 'proj-7',
    name: 'PayFast Integration',
    companyId: 'comp-3',
    coverImage: '/images/project-payment.jpg',
    description: 'API de paiement instantané pour e-commerce',
    startDate: new Date('2024-01-20'),
  },

  // Digital Factory projects
  {
    id: 'proj-8',
    name: 'Luxury Brand Website',
    companyId: 'comp-4',
    coverImage: '/images/project-luxury.jpg',
    description: 'Site web premium pour marque de luxe',
    startDate: new Date('2023-12-01'),
    endDate: new Date('2024-03-31'),
  },
  {
    id: 'proj-9',
    name: 'E-commerce UX Redesign',
    companyId: 'comp-4',
    coverImage: '/images/project-ecommerce.jpg',
    description: 'Refonte UX complète d\'une plateforme e-commerce',
    startDate: new Date('2024-02-10'),
    endDate: new Date('2024-06-10'),
  },
  {
    id: 'proj-10',
    name: 'Mobile Banking App',
    companyId: 'comp-4',
    coverImage: '/images/project-banking.jpg',
    description: 'Application bancaire mobile nouvelle génération',
    startDate: new Date('2024-01-05'),
  },

  // EcoTech Solutions projects
  {
    id: 'proj-11',
    name: 'Solar Panel Monitor',
    companyId: 'comp-5',
    coverImage: '/images/project-solar.jpg',
    description: 'Système de monitoring pour panneaux solaires',
    startDate: new Date('2024-01-10'),
    endDate: new Date('2024-05-31'),
  },
  {
    id: 'proj-12',
    name: 'Green Energy Analytics',
    companyId: 'comp-5',
    coverImage: '/images/project-green.jpg',
    description: 'Plateforme d\'analyse de données énergétiques',
    startDate: new Date('2024-03-01'),
  },

  // Data Analytics Pro projects
  {
    id: 'proj-13',
    name: 'Predictive Maintenance AI',
    companyId: 'comp-6',
    coverImage: '/images/project-maintenance.jpg',
    description: 'IA de maintenance prédictive industrielle',
    startDate: new Date('2024-02-01'),
    endDate: new Date('2024-09-30'),
  },
  {
    id: 'proj-14',
    name: 'Customer Insights Platform',
    companyId: 'comp-6',
    coverImage: '/images/project-insights.jpg',
    description: 'Analyse comportementale des clients',
    startDate: new Date('2024-01-15'),
  },

  // Mobile First Dev projects
  {
    id: 'proj-15',
    name: 'Fitness Tracker App',
    companyId: 'comp-7',
    coverImage: '/images/project-fitness.jpg',
    description: 'Application de suivi sportif et nutrition',
    startDate: new Date('2023-11-15'),
    endDate: new Date('2024-05-15'),
  },
  {
    id: 'proj-16',
    name: 'Social Network Lite',
    companyId: 'comp-7',
    coverImage: '/images/project-social.jpg',
    description: 'Réseau social léger pour marchés émergents',
    startDate: new Date('2024-02-20'),
  },

  // Cloud Masters projects
  {
    id: 'proj-17',
    name: 'Kubernetes Auto-Scaler',
    companyId: 'comp-8',
    coverImage: '/images/project-k8s.jpg',
    description: 'Solution d\'auto-scaling intelligent pour Kubernetes',
    startDate: new Date('2024-01-01'),
    endDate: new Date('2024-06-30'),
  },
  {
    id: 'proj-18',
    name: 'Multi-Cloud Manager',
    companyId: 'comp-8',
    coverImage: '/images/project-multicloud.jpg',
    description: 'Gestion unifiée multi-cloud (AWS, Azure, GCP)',
    startDate: new Date('2024-03-01'),
  },

  // Gaming Studio FR projects
  {
    id: 'proj-19',
    name: 'Fantasy RPG Quest',
    companyId: 'comp-9',
    coverImage: '/images/project-rpg.jpg',
    description: 'Jeu de rôle fantastique multi-joueurs',
    startDate: new Date('2023-09-01'),
    endDate: new Date('2025-03-31'),
  },
  {
    id: 'proj-20',
    name: 'Mobile Puzzle Game',
    companyId: 'comp-9',
    coverImage: '/images/project-puzzle.jpg',
    description: 'Jeu de puzzle casual pour mobile',
    startDate: new Date('2024-01-10'),
    endDate: new Date('2024-07-10'),
  },

  // Cyber Security Experts projects
  {
    id: 'proj-21',
    name: 'Threat Detection System',
    companyId: 'comp-10',
    coverImage: '/images/project-threat.jpg',
    description: 'Système de détection de menaces en temps réel',
    startDate: new Date('2024-02-01'),
    endDate: new Date('2024-11-30'),
  },
  {
    id: 'proj-22',
    name: 'Security Audit Tool',
    companyId: 'comp-10',
    coverImage: '/images/project-audit.jpg',
    description: 'Outil d\'audit de sécurité automatisé',
    startDate: new Date('2024-01-20'),
  },
];

// ============================================================================
// DONNÉES MOCK - STAGIAIRES
// ============================================================================

export const mockInterns: Intern[] = [
  {
    id: 'intern-1',
    username: 'sophie_martin_dev',
    displayName: 'Sophie Martin',
    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
    bio: 'Développeuse Full-stack passionnée | React & Node.js',
    profession: 'Développeuse Web',
    followers: 342,
    following: 89,
    feedbacksCount: 12,
    isVerified: false,
  },
  {
    id: 'intern-2',
    username: 'lucas_dubois_ai',
    displayName: 'Lucas Dubois',
    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
    bio: 'Ingénieur IA | Passionné par le Machine Learning 🤖',
    profession: 'Data Scientist',
    followers: 567,
    following: 123,
    feedbacksCount: 8,
    isVerified: false,
  },
  {
    id: 'intern-3',
    username: 'marie_lefevre_ux',
    displayName: 'Marie Lefevre',
    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
    bio: 'Designer UX/UI créative | Figma addict ✨',
    profession: 'Designer UX/UI',
    followers: 892,
    following: 234,
    feedbacksCount: 15,
    isVerified: true,
  },
  {
    id: 'intern-4',
    username: 'thomas_bernard_mobile',
    displayName: 'Thomas Bernard',
    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
    bio: 'Développeur mobile iOS & Android | Swift, Kotlin',
    profession: 'Développeur Mobile',
    followers: 421,
    following: 167,
    feedbacksCount: 10,
    isVerified: false,
  },
  {
    id: 'intern-5',
    username: 'emma_rousseau_data',
    displayName: 'Emma Rousseau',
    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
    bio: 'Analyste de données | Python & SQL expert 📊',
    profession: 'Analyste de Données',
    followers: 654,
    following: 201,
    feedbacksCount: 14,
    isVerified: false,
  },
  {
    id: 'intern-6',
    username: 'julien_moreau_devops',
    displayName: 'Julien Moreau',
    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
    bio: 'DevOps Engineer | Kubernetes & Docker 🚀',
    profession: 'Ingénieur DevOps',
    followers: 789,
    following: 145,
    feedbacksCount: 9,
    isVerified: true,
  },
  {
    id: 'intern-7',
    username: 'chloe_petit_frontend',
    displayName: 'Chloé Petit',
    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
    bio: 'Frontend Developer | Vue.js & Tailwind CSS 💅',
    profession: 'Développeuse Frontend',
    followers: 512,
    following: 178,
    feedbacksCount: 11,
    isVerified: false,
  },
  {
    id: 'intern-8',
    username: 'antoine_garcia_backend',
    displayName: 'Antoine Garcia',
    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
    bio: 'Backend Engineer | Java Spring & Microservices',
    profession: 'Développeur Backend',
    followers: 623,
    following: 134,
    feedbacksCount: 7,
    isVerified: false,
  },
  {
    id: 'intern-9',
    username: 'lea_roux_product',
    displayName: 'Léa Roux',
    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
    bio: 'Product Manager junior | Agile & Scrum',
    profession: 'Product Manager',
    followers: 1123,
    following: 312,
    feedbacksCount: 13,
    isVerified: true,
  },
  {
    id: 'intern-10',
    username: 'hugo_durand_cyber',
    displayName: 'Hugo Durand',
    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
    bio: 'Cybersecurity specialist | Ethical hacker 🔐',
    profession: 'Analyste Cybersécurité',
    followers: 934,
    following: 89,
    feedbacksCount: 6,
    isVerified: false,
  },
  {
    id: 'intern-11',
    username: 'camille_laurent_qa',
    displayName: 'Camille Laurent',
    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
    bio: 'QA Engineer | Automatisation des tests avec Selenium',
    profession: 'Ingénieure QA',
    followers: 387,
    following: 156,
    feedbacksCount: 8,
    isVerified: false,
  },
  {
    id: 'intern-12',
    username: 'maxime_vincent_game',
    displayName: 'Maxime Vincent',
    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
    bio: 'Game Developer | Unity & C# 🎮',
    profession: 'Développeur Jeux Vidéo',
    followers: 1567,
    following: 423,
    feedbacksCount: 10,
    isVerified: true,
  },
  {
    id: 'intern-13',
    username: 'lisa_mercier_cloud',
    displayName: 'Lisa Mercier',
    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
    bio: 'Cloud Architect | AWS & Azure certifiée ☁️',
    profession: 'Architecte Cloud',
    followers: 712,
    following: 198,
    feedbacksCount: 11,
    isVerified: false,
  },
  {
    id: 'intern-14',
    username: 'nathan_simon_blockchain',
    displayName: 'Nathan Simon',
    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
    bio: 'Blockchain Developer | Solidity & Web3',
    profession: 'Développeur Blockchain',
    followers: 845,
    following: 267,
    feedbacksCount: 9,
    isVerified: false,
  },
  {
    id: 'intern-15',
    username: 'sarah_michel_marketing',
    displayName: 'Sarah Michel',
    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
    bio: 'Digital Marketing | SEO & Content Strategy 📈',
    profession: 'Responsable Marketing Digital',
    followers: 1234,
    following: 445,
    feedbacksCount: 16,
    isVerified: true,
  },
  {
    id: 'intern-16',
    username: 'pierre_fontaine_sysadmin',
    displayName: 'Pierre Fontaine',
    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
    bio: 'System Administrator | Linux & Bash scripting',
    profession: 'Administrateur Système',
    followers: 456,
    following: 123,
    feedbacksCount: 7,
    isVerified: false,
  },
  {
    id: 'intern-17',
    username: 'clara_robin_design',
    displayName: 'Clara Robin',
    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
    bio: 'Graphic Designer | Branding & Illustration 🎨',
    profession: 'Designer Graphique',
    followers: 987,
    following: 298,
    feedbacksCount: 12,
    isVerified: false,
  },
  {
    id: 'intern-18',
    username: 'arthur_bonnet_embedded',
    displayName: 'Arthur Bonnet',
    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
    bio: 'Embedded Systems Engineer | C/C++ & IoT',
    profession: 'Ingénieur Systèmes Embarqués',
    followers: 534,
    following: 167,
    feedbacksCount: 8,
    isVerified: false,
  },
  {
    id: 'intern-19',
    username: 'elise_lambert_pm',
    displayName: 'Élise Lambert',
    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
    bio: 'Project Manager | PMP certified | Lean Six Sigma',
    profession: 'Chef de Projet',
    followers: 1456,
    following: 389,
    feedbacksCount: 14,
    isVerified: true,
  },
  {
    id: 'intern-20',
    username: 'romain_girard_ml',
    displayName: 'Romain Girard',
    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
    bio: 'Machine Learning Engineer | TensorFlow & PyTorch',
    profession: 'Ingénieur ML',
    followers: 1892,
    following: 456,
    feedbacksCount: 15,
    isVerified: true,
  },
  // Ajout de 10 stagiaires supplémentaires pour atteindre 30+
  {
    id: 'intern-21',
    username: 'oceane_durand_scrum',
    displayName: 'Océane Durand',
    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
    bio: 'Scrum Master | Agilité et facilitation d\'équipe',
    profession: 'Scrum Master',
    followers: 678,
    following: 234,
    feedbacksCount: 10,
    isVerified: false,
  },
  {
    id: 'intern-22',
    username: 'theo_morel_fullstack',
    displayName: 'Théo Morel',
    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
    bio: 'Full-stack Developer | MERN Stack enthusiast',
    profession: 'Développeur Full-stack',
    followers: 523,
    following: 189,
    feedbacksCount: 9,
    isVerified: false,
  },
  {
    id: 'intern-23',
    username: 'manon_andre_dataviz',
    displayName: 'Manon André',
    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
    bio: 'Data Visualization Specialist | D3.js & Tableau',
    profession: 'Spécialiste Dataviz',
    followers: 745,
    following: 201,
    feedbacksCount: 11,
    isVerified: false,
  },
  {
    id: 'intern-24',
    username: 'gabriel_blanc_network',
    displayName: 'Gabriel Blanc',
    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
    bio: 'Network Engineer | Cisco & Juniper certified',
    profession: 'Ingénieur Réseau',
    followers: 412,
    following: 145,
    feedbacksCount: 6,
    isVerified: false,
  },
  {
    id: 'intern-25',
    username: 'jade_chevalier_uxresearch',
    displayName: 'Jade Chevalier',
    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
    bio: 'UX Researcher | User interviews & testing expert',
    profession: 'Chercheuse UX',
    followers: 856,
    following: 267,
    feedbacksCount: 13,
    isVerified: true,
  },
  {
    id: 'intern-26',
    username: 'louis_renard_automation',
    displayName: 'Louis Renard',
    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
    bio: 'Automation Engineer | Python & Jenkins',
    profession: 'Ingénieur Automatisation',
    followers: 589,
    following: 178,
    feedbacksCount: 8,
    isVerified: false,
  },
  {
    id: 'intern-27',
    username: 'noemie_leclerc_seo',
    displayName: 'Noémie Leclerc',
    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
    bio: 'SEO Specialist | Optimisation et stratégie de contenu',
    profession: 'Spécialiste SEO',
    followers: 923,
    following: 312,
    feedbacksCount: 12,
    isVerified: false,
  },
  {
    id: 'intern-28',
    username: 'timéo_perrin_arvr',
    displayName: 'Timéo Perrin',
    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
    bio: 'AR/VR Developer | Unity & Unreal Engine 🥽',
    profession: 'Développeur AR/VR',
    followers: 1345,
    following: 401,
    feedbacksCount: 10,
    isVerified: true,
  },
  {
    id: 'intern-29',
    username: 'valentine_dumas_content',
    displayName: 'Valentine Dumas',
    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
    bio: 'Content Creator | Vidéo & Copywriting ✍️',
    profession: 'Créatrice de Contenu',
    followers: 2134,
    following: 567,
    feedbacksCount: 18,
    isVerified: true,
  },
  {
    id: 'intern-30',
    username: 'eliott_faure_devsec',
    displayName: 'Éliott Faure',
    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
    bio: 'DevSecOps Engineer | Security automation',
    profession: 'Ingénieur DevSecOps',
    followers: 667,
    following: 192,
    feedbacksCount: 7,
    isVerified: false,
  },
];

// ============================================================================
// DONNÉES MOCK - FEEDBACKS (50+)
// ============================================================================

export const mockFeedbacks: FeedbackData[] = [
  // Feedbacks sur Quantum Leap Platform (proj-1, Tech Innov)
  {
    id: 'fb-1',
    intern: {
      id: 'intern-1',
      name: 'Sophie Martin',
      username: 'sophie_martin_dev',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez Tech Innov S.A.',
    },
    project: {
      id: 'proj-1',
      name: 'Quantum Leap Platform',
      image: '/images/project-quantum.jpg',
      companyId: 'comp-1',
    },
    company: {
      id: 'comp-1',
      name: 'Tech Innov S.A.',
      username: 'tech_innov_sa',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "Expérience incroyable sur le projet Quantum Leap ! L'équipe était très accueillante et j'ai pu apprendre énormément sur l'architecture cloud moderne. Le mentorat était exceptionnel, avec des code reviews constructives quotidiennes. Je recommande vivement cette entreprise aux futurs stagiaires !",
    timestamp: new Date('2024-01-20T14:30:00'),
    likes: 45,
    liked: false,
    comments: [
      {
        id: 'c-1-1',
        author: 'Lucas Dubois',
        text: 'Super retour Sophie ! 👏',
        avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
        likes: 3,
        liked: false,
        replies: [],
      },
    ],
    isPublic: true,
  },
  {
    id: 'fb-2',
    intern: {
      id: 'intern-2',
      name: 'Lucas Dubois',
      username: 'lucas_dubois_ai',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez Tech Innov S.A.',
    },
    project: {
      id: 'proj-1',
      name: 'Quantum Leap Platform',
      image: '/images/project-quantum.jpg',
      companyId: 'comp-1',
    },
    company: {
      id: 'comp-1',
      name: 'Tech Innov S.A.',
      username: 'tech_innov_sa',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "J'ai eu l'opportunité de travailler sur des fonctionnalités d'auto-scaling et c'était passionnant. Les sprints étaient bien organisés et les objectifs clairs. Excellente première expérience en entreprise !",
    timestamp: new Date('2024-01-22T10:15:00'),
    likes: 32,
    liked: false,
    comments: [],
    isPublic: true,
  },

  // Feedbacks sur SmartAI Dashboard (proj-2, Tech Innov)
  {
    id: 'fb-3',
    intern: {
      id: 'intern-5',
      name: 'Emma Rousseau',
      username: 'emma_rousseau_data',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez Tech Innov S.A.',
    },
    project: {
      id: 'proj-2',
      name: 'SmartAI Dashboard',
      image: '/images/project-ai.jpg',
      companyId: 'comp-1',
    },
    company: {
      id: 'comp-1',
      name: 'Tech Innov S.A.',
      username: 'tech_innov_sa',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "Travailler sur les algorithmes de prédiction était un rêve devenu réalité. L'équipe data science m'a beaucoup appris sur le machine learning en production. Un grand merci à mon tuteur pour sa patience et son expertise !",
    timestamp: new Date('2024-02-05T16:45:00'),
    likes: 58,
    liked: true,
    comments: [
      {
        id: 'c-3-1',
        author: 'Romain Girard',
        text: "Content de voir ton évolution Emma ! L'équipe est top 💯",
        avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
        likes: 5,
        liked: false,
        replies: [],
      },
    ],
    isPublic: true,
  },

  // Feedbacks sur Digital Transformation Initiative (proj-4, Global Corp)
  {
    id: 'fb-4',
    intern: {
      id: 'intern-9',
      name: 'Léa Roux',
      username: 'lea_roux_product',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez Global Corp',
    },
    project: {
      id: 'proj-4',
      name: 'Digital Transformation Initiative',
      image: '/images/project-transform.jpg',
      companyId: 'comp-2',
    },
    company: {
      id: 'comp-2',
      name: 'Global Corp',
      username: 'global_corp',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "Stage enrichissant en tant que PM junior. J'ai pu participer aux cérémonies agiles, rédiger des user stories et interagir avec les stakeholders. L'environnement est très professionnel et formateur.",
    timestamp: new Date('2024-01-28T11:20:00'),
    likes: 41,
    liked: false,
    comments: [],
    isPublic: true,
  },

  // Feedbacks sur CryptoWallet Pro (proj-6, StartupX)
  {
    id: 'fb-5',
    intern: {
      id: 'intern-14',
      name: 'Nathan Simon',
      username: 'nathan_simon_blockchain',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez StartupX',
    },
    project: {
      id: 'proj-6',
      name: 'CryptoWallet Pro',
      image: '/images/project-crypto.jpg',
      companyId: 'comp-3',
    },
    company: {
      id: 'comp-3',
      name: 'StartupX',
      username: 'startup_x',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "Startup dynamique avec une ambiance de travail exceptionnelle ! J'ai développé des smart contracts en Solidity et intégré Web3.js. L'autonomie donnée aux stagiaires est vraiment appréciable. 🚀",
    timestamp: new Date('2024-02-10T09:30:00'),
    likes: 67,
    liked: false,
    comments: [
      {
        id: 'c-5-1',
        author: 'Pierre Fontaine',
        text: "La blockchain c'est l'avenir ! Belle expérience 🔥",
        avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
        likes: 8,
        liked: true,
        replies: [],
      },
    ],
    isPublic: true,
  },

  // Feedbacks sur Luxury Brand Website (proj-8, Digital Factory)
  {
    id: 'fb-6',
    intern: {
      id: 'intern-3',
      name: 'Marie Lefevre',
      username: 'marie_lefevre_ux',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez Digital Factory',
    },
    project: {
      id: 'proj-8',
      name: 'Luxury Brand Website',
      image: '/images/project-luxury.jpg',
      companyId: 'comp-4',
    },
    company: {
      id: 'comp-4',
      name: 'Digital Factory',
      username: 'digital_factory',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "Projet de rêve pour une designer ! J'ai travaillé sur les wireframes, prototypes Figma et user testing. Les clients étaient exigeants mais le résultat final était magnifique. Équipe créative et bienveillante.",
    timestamp: new Date('2024-01-18T14:00:00'),
    likes: 89,
    liked: true,
    comments: [],
    isPublic: true,
  },

  // Continuation des feedbacks...
  {
    id: 'fb-7',
    intern: {
      id: 'intern-17',
      name: 'Clara Robin',
      username: 'clara_robin_design',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez Digital Factory',
    },
    project: {
      id: 'proj-9',
      name: 'E-commerce UX Redesign',
      image: '/images/project-ecommerce.jpg',
      companyId: 'comp-4',
    },
    company: {
      id: 'comp-4',
      name: 'Digital Factory',
      username: 'digital_factory',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "Refonte UX complète d'une boutique en ligne ! J'ai appris les principes de conversion, A/B testing et design system. Les workshops avec les clients étaient super enrichissants. 🎨",
    timestamp: new Date('2024-02-14T10:30:00'),
    likes: 52,
    liked: false,
    comments: [
      {
        id: 'c-7-1',
        author: 'Marie Lefevre',
        text: 'Ton travail sur les micro-interactions était génial ! 👍',
        avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
        likes: 4,
        liked: false,
        replies: [],
      },
    ],
    isPublic: true,
  },

  {
    id: 'fb-8',
    intern: {
      id: 'intern-11',
      name: 'Camille Laurent',
      username: 'camille_laurent_qa',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez Mobile First Dev',
    },
    project: {
      id: 'proj-15',
      name: 'Fitness Tracker App',
      image: '/images/project-fitness.jpg',
      companyId: 'comp-7',
    },
    company: {
      id: 'comp-7',
      name: 'Mobile First Dev',
      username: 'mobile_first_dev',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "En tant que QA, j'ai automatisé les tests avec Appium et détecté des bugs critiques avant la release. L'équipe valorise vraiment la qualité et m'a donné de vraies responsabilités. Top !",
    timestamp: new Date('2024-01-25T15:45:00'),
    likes: 38,
    liked: false,
    comments: [],
    isPublic: true,
  },

  {
    id: 'fb-9',
    intern: {
      id: 'intern-4',
      name: 'Thomas Bernard',
      username: 'thomas_bernard_mobile',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez Mobile First Dev',
    },
    project: {
      id: 'proj-15',
      name: 'Fitness Tracker App',
      image: '/images/project-fitness.jpg',
      companyId: 'comp-7',
    },
    company: {
      id: 'comp-7',
      name: 'Mobile First Dev',
      username: 'mobile_first_dev',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "Développer une app mobile de A à Z était mon objectif et je l'ai réalisé ! Kotlin pour Android, intégration API REST, gestion de l'état avec Room. Mentors au top, je suis très reconnaissant. 💪",
    timestamp: new Date('2024-02-01T09:15:00'),
    likes: 71,
    liked: true,
    comments: [
      {
        id: 'c-9-1',
        author: 'Antoine Garcia',
        text: 'Belle perf Thomas ! La partie backend fonctionne nickel 🙌',
        avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
        likes: 6,
        liked: false,
        replies: [],
      },
    ],
    isPublic: true,
  },

  {
    id: 'fb-10',
    intern: {
      id: 'intern-6',
      name: 'Julien Moreau',
      username: 'julien_moreau_devops',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez Cloud Masters',
    },
    project: {
      id: 'proj-17',
      name: 'Kubernetes Auto-Scaler',
      image: '/images/project-k8s.jpg',
      companyId: 'comp-8',
    },
    company: {
      id: 'comp-8',
      name: 'Cloud Masters',
      username: 'cloud_masters',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "Projet DevOps de haut niveau ! J'ai configuré des pipelines CI/CD, géré des clusters Kubernetes et optimisé les coûts cloud. L'équipe est composée de vrais experts qui partagent leurs connaissances. 🚀",
    timestamp: new Date('2024-01-30T11:00:00'),
    likes: 64,
    liked: false,
    comments: [],
    isPublic: true,
  },

  // Ajout de 40 feedbacks supplémentaires pour atteindre 50+
  {
    id: 'fb-11',
    intern: {
      id: 'intern-13',
      name: 'Lisa Mercier',
      username: 'lisa_mercier_cloud',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez Cloud Masters',
    },
    project: {
      id: 'proj-18',
      name: 'Multi-Cloud Manager',
      image: '/images/project-multicloud.jpg',
      companyId: 'comp-8',
    },
    company: {
      id: 'comp-8',
      name: 'Cloud Masters',
      username: 'cloud_masters',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "Gérer une infrastructure multi-cloud (AWS, Azure, GCP) était un défi passionnant. J'ai appris Terraform, CloudFormation et bien plus. Expérience professionnelle exceptionnelle ! ☁️",
    timestamp: new Date('2024-02-08T13:20:00'),
    likes: 49,
    liked: false,
    comments: [],
    isPublic: true,
  },

  {
    id: 'fb-12',
    intern: {
      id: 'intern-12',
      name: 'Maxime Vincent',
      username: 'maxime_vincent_game',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez Gaming Studio FR',
    },
    project: {
      id: 'proj-19',
      name: 'Fantasy RPG Quest',
      image: '/images/project-rpg.jpg',
      companyId: 'comp-9',
    },
    company: {
      id: 'comp-9',
      name: 'Gaming Studio FR',
      username: 'gaming_studio_fr',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "Développer un RPG avec Unity était un rêve ! J'ai codé des systèmes de combat, quêtes et IA des ennemis. L'ambiance dans le studio est incroyable, comme une grande famille de gamers. 🎮",
    timestamp: new Date('2024-01-15T10:00:00'),
    likes: 156,
    liked: true,
    comments: [
      {
        id: 'c-12-1',
        author: 'Timéo Perrin',
        text: "J'ai hâte de jouer à ce jeu ! Super boulot 🔥",
        avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
        likes: 12,
        liked: false,
        replies: [],
      },
    ],
    isPublic: true,
  },

  {
    id: 'fb-13',
    intern: {
      id: 'intern-10',
      name: 'Hugo Durand',
      username: 'hugo_durand_cyber',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez Cyber Security Experts',
    },
    project: {
      id: 'proj-21',
      name: 'Threat Detection System',
      image: '/images/project-threat.jpg',
      companyId: 'comp-10',
    },
    company: {
      id: 'comp-10',
      name: 'Cyber Security Experts',
      username: 'cyber_security_experts',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "Travailler sur la détection de menaces en temps réel m'a ouvert les yeux sur la cybersécurité moderne. Analyse de logs, machine learning pour détecter les anomalies... Passionnant ! 🔐",
    timestamp: new Date('2024-02-12T14:30:00'),
    likes: 55,
    liked: false,
    comments: [],
    isPublic: true,
  },

  {
    id: 'fb-14',
    intern: {
      id: 'intern-30',
      name: 'Éliott Faure',
      username: 'eliott_faure_devsec',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez Cyber Security Experts',
    },
    project: {
      id: 'proj-22',
      name: 'Security Audit Tool',
      image: '/images/project-audit.jpg',
      companyId: 'comp-10',
    },
    company: {
      id: 'comp-10',
      name: 'Cyber Security Experts',
      username: 'cyber_security_experts',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "Automatiser les audits de sécurité avec Python et des outils comme Nmap, OWASP ZAP était super formateur. L'équipe m'a fait confiance pour des pentests sur des environnements de prod !",
    timestamp: new Date('2024-02-15T16:00:00'),
    likes: 42,
    liked: false,
    comments: [],
    isPublic: true,
  },

  {
    id: 'fb-15',
    intern: {
      id: 'intern-7',
      name: 'Chloé Petit',
      username: 'chloe_petit_frontend',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez Digital Factory',
    },
    project: {
      id: 'proj-10',
      name: 'Mobile Banking App',
      image: '/images/project-banking.jpg',
      companyId: 'comp-4',
    },
    company: {
      id: 'comp-4',
      name: 'Digital Factory',
      username: 'digital_factory',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "Développer l'interface d'une app bancaire avec Vue.js et Tailwind était un défi stimulant. Accessibilité, performance, sécurité... J'ai tout appris ! Équipe bienveillante et pédagogue. 💅",
    timestamp: new Date('2024-01-12T11:45:00'),
    likes: 61,
    liked: false,
    comments: [],
    isPublic: true,
  },

  {
    id: 'fb-16',
    intern: {
      id: 'intern-8',
      name: 'Antoine Garcia',
      username: 'antoine_garcia_backend',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez Tech Innov S.A.',
    },
    project: {
      id: 'proj-3',
      name: 'Enterprise Mobile Suite',
      image: '/images/project-mobile.jpg',
      companyId: 'comp-1',
    },
    company: {
      id: 'comp-1',
      name: 'Tech Innov S.A.',
      username: 'tech_innov_sa',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "Backend Java Spring Boot avec architecture microservices. J'ai développé des API REST, géré les bases de données et implémenté Redis pour le caching. Stage ultra professionnalisant !",
    timestamp: new Date('2024-01-19T09:30:00'),
    likes: 47,
    liked: false,
    comments: [],
    isPublic: true,
  },

  {
    id: 'fb-17',
    intern: {
      id: 'intern-15',
      name: 'Sarah Michel',
      username: 'sarah_michel_marketing',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez StartupX',
    },
    project: {
      id: 'proj-7',
      name: 'PayFast Integration',
      image: '/images/project-payment.jpg',
      companyId: 'comp-3',
    },
    company: {
      id: 'comp-3',
      name: 'StartupX',
      username: 'startup_x',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "J'ai géré le lancement marketing de PayFast ! SEO, content marketing, campagnes ads... Résultats impressionnants avec +300% de trafic en 2 mois. Startup ultra dynamique ! 📈",
    timestamp: new Date('2024-02-07T14:15:00'),
    likes: 93,
    liked: true,
    comments: [
      {
        id: 'c-17-1',
        author: 'Noémie Leclerc',
        text: 'Ta stratégie SEO était brillante Sarah ! 🎉',
        avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
        likes: 7,
        liked: false,
        replies: [],
      },
    ],
    isPublic: true,
  },

  {
    id: 'fb-18',
    intern: {
      id: 'intern-16',
      name: 'Pierre Fontaine',
      username: 'pierre_fontaine_sysadmin',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez Cloud Masters',
    },
    project: {
      id: 'proj-17',
      name: 'Kubernetes Auto-Scaler',
      image: '/images/project-k8s.jpg',
      companyId: 'comp-8',
    },
    company: {
      id: 'comp-8',
      name: 'Cloud Masters',
      username: 'cloud_masters',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "Administration système Linux au plus haut niveau. Scripts Bash, monitoring Prometheus/Grafana, gestion des incidents... J'ai progressé de fou en 6 mois !",
    timestamp: new Date('2024-01-27T10:20:00'),
    likes: 39,
    liked: false,
    comments: [],
    isPublic: true,
  },

  {
    id: 'fb-19',
    intern: {
      id: 'intern-18',
      name: 'Arthur Bonnet',
      username: 'arthur_bonnet_embedded',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez EcoTech Solutions',
    },
    project: {
      id: 'proj-11',
      name: 'Solar Panel Monitor',
      image: '/images/project-solar.jpg',
      companyId: 'comp-5',
    },
    company: {
      id: 'comp-5',
      name: 'EcoTech Solutions',
      username: 'ecotech_solutions',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "Développer un système embarqué IoT pour panneaux solaires était fascinant. C/C++, MQTT, capteurs... Mission à impact environnemental positif ! 🌱",
    timestamp: new Date('2024-02-03T13:40:00'),
    likes: 51,
    liked: false,
    comments: [],
    isPublic: true,
  },

  {
    id: 'fb-20',
    intern: {
      id: 'intern-19',
      name: 'Élise Lambert',
      username: 'elise_lambert_pm',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez Global Corp',
    },
    project: {
      id: 'proj-5',
      name: 'Supply Chain Optimizer',
      image: '/images/project-supply.jpg',
      companyId: 'comp-2',
    },
    company: {
      id: 'comp-2',
      name: 'Global Corp',
      username: 'global_corp',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "Gérer un projet complexe de supply chain avec des équipes internationales ! Méthodologie PMP, gestion des risques, communication avec les stakeholders... Expérience inestimable.",
    timestamp: new Date('2024-01-24T15:30:00'),
    likes: 68,
    liked: false,
    comments: [],
    isPublic: true,
  },

  // Ajout de 30 feedbacks supplémentaires pour compléter...
  {
    id: 'fb-21',
    intern: {
      id: 'intern-20',
      name: 'Romain Girard',
      username: 'romain_girard_ml',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez Data Analytics Pro',
    },
    project: {
      id: 'proj-13',
      name: 'Predictive Maintenance AI',
      image: '/images/project-maintenance.jpg',
      companyId: 'comp-6',
    },
    company: {
      id: 'comp-6',
      name: 'Data Analytics Pro',
      username: 'data_analytics_pro',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "Développer des modèles de ML pour prédire les pannes machines était passionnant ! TensorFlow, feature engineering, déploiement en production... J'ai tout appris sur le ML en conditions réelles.",
    timestamp: new Date('2024-02-11T12:00:00'),
    likes: 87,
    liked: true,
    comments: [],
    isPublic: true,
  },

  {
    id: 'fb-22',
    intern: {
      id: 'intern-21',
      name: 'Océane Durand',
      username: 'oceane_durand_scrum',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez Global Corp',
    },
    project: {
      id: 'proj-4',
      name: 'Digital Transformation Initiative',
      image: '/images/project-transform.jpg',
      companyId: 'comp-2',
    },
    company: {
      id: 'comp-2',
      name: 'Global Corp',
      username: 'global_corp',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "Faciliter les cérémonies Scrum pour une équipe de 15 personnes ! Rétrospectives, plannings, daily meetings... L'agilité n'a plus de secret pour moi. Équipe formidable !",
    timestamp: new Date('2024-01-31T10:30:00'),
    likes: 44,
    liked: false,
    comments: [],
    isPublic: true,
  },

  {
    id: 'fb-23',
    intern: {
      id: 'intern-22',
      name: 'Théo Morel',
      username: 'theo_morel_fullstack',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez StartupX',
    },
    project: {
      id: 'proj-6',
      name: 'CryptoWallet Pro',
      image: '/images/project-crypto.jpg',
      companyId: 'comp-3',
    },
    company: {
      id: 'comp-3',
      name: 'StartupX',
      username: 'startup_x',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "Stack MERN complète : MongoDB, Express, React, Node.js. J'ai développé des features end-to-end en autonomie. Startup où on apprend vite et on a de vraies responsabilités !",
    timestamp: new Date('2024-02-09T11:15:00'),
    likes: 53,
    liked: false,
    comments: [],
    isPublic: true,
  },

  {
    id: 'fb-24',
    intern: {
      id: 'intern-23',
      name: 'Manon André',
      username: 'manon_andre_dataviz',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez Data Analytics Pro',
    },
    project: {
      id: 'proj-14',
      name: 'Customer Insights Platform',
      image: '/images/project-insights.jpg',
      companyId: 'comp-6',
    },
    company: {
      id: 'comp-6',
      name: 'Data Analytics Pro',
      username: 'data_analytics_pro',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "Créer des dashboards interactifs avec D3.js et Tableau ! Visualiser les données clients de manière claire et actionnable. Les retours utilisateurs étaient très positifs. 📊",
    timestamp: new Date('2024-01-29T14:45:00'),
    likes: 59,
    liked: false,
    comments: [],
    isPublic: true,
  },

  {
    id: 'fb-25',
    intern: {
      id: 'intern-24',
      name: 'Gabriel Blanc',
      username: 'gabriel_blanc_network',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez Cloud Masters',
    },
    project: {
      id: 'proj-18',
      name: 'Multi-Cloud Manager',
      image: '/images/project-multicloud.jpg',
      companyId: 'comp-8',
    },
    company: {
      id: 'comp-8',
      name: 'Cloud Masters',
      username: 'cloud_masters',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "Configuration réseau multi-cloud complexe. VPN, load balancing, firewall rules... J'ai passé mes certifications Cisco pendant le stage grâce au support de l'entreprise !",
    timestamp: new Date('2024-02-13T09:00:00'),
    likes: 41,
    liked: false,
    comments: [],
    isPublic: true,
  },

  {
    id: 'fb-26',
    intern: {
      id: 'intern-25',
      name: 'Jade Chevalier',
      username: 'jade_chevalier_uxresearch',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez Digital Factory',
    },
    project: {
      id: 'proj-9',
      name: 'E-commerce UX Redesign',
      image: '/images/project-ecommerce.jpg',
      companyId: 'comp-4',
    },
    company: {
      id: 'comp-4',
      name: 'Digital Factory',
      username: 'digital_factory',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "Recherche UX approfondie : interviews utilisateurs, tests d'usabilité, personas, parcours clients... J'ai vraiment compris l'importance de l'empathie en design. Équipe super !",
    timestamp: new Date('2024-01-16T13:30:00'),
    likes: 72,
    liked: true,
    comments: [],
    isPublic: true,
  },

  {
    id: 'fb-27',
    intern: {
      id: 'intern-26',
      name: 'Louis Renard',
      username: 'louis_renard_automation',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez Mobile First Dev',
    },
    project: {
      id: 'proj-16',
      name: 'Social Network Lite',
      image: '/images/project-social.jpg',
      companyId: 'comp-7',
    },
    company: {
      id: 'comp-7',
      name: 'Mobile First Dev',
      username: 'mobile_first_dev',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "Automatisation complète des tests et déploiements avec Jenkins et Python. CI/CD pipelines performants qui ont réduit le temps de release de 50% ! Fier du travail accompli.",
    timestamp: new Date('2024-02-06T10:45:00'),
    likes: 46,
    liked: false,
    comments: [],
    isPublic: true,
  },

  {
    id: 'fb-28',
    intern: {
      id: 'intern-27',
      name: 'Noémie Leclerc',
      username: 'noemie_leclerc_seo',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez Digital Factory',
    },
    project: {
      id: 'proj-8',
      name: 'Luxury Brand Website',
      image: '/images/project-luxury.jpg',
      companyId: 'comp-4',
    },
    company: {
      id: 'comp-4',
      name: 'Digital Factory',
      username: 'digital_factory',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "Optimisation SEO pour une marque de luxe. Recherche de mots-clés, link building, technical SEO... +200% de trafic organique en 3 mois. Résultats concrets et mesurables !",
    timestamp: new Date('2024-01-21T15:00:00'),
    likes: 81,
    liked: false,
    comments: [],
    isPublic: true,
  },

  {
    id: 'fb-29',
    intern: {
      id: 'intern-28',
      name: 'Timéo Perrin',
      username: 'timéo_perrin_arvr',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez Gaming Studio FR',
    },
    project: {
      id: 'proj-20',
      name: 'Mobile Puzzle Game',
      image: '/images/project-puzzle.jpg',
      companyId: 'comp-9',
    },
    company: {
      id: 'comp-9',
      name: 'Gaming Studio FR',
      username: 'gaming_studio_fr',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "Développer un jeu mobile en réalité augmentée ! Unity ARKit, interactions gestuelles, level design... Projet innovant dans un studio créatif et bienveillant. 🥽",
    timestamp: new Date('2024-02-04T12:30:00'),
    likes: 124,
    liked: true,
    comments: [],
    isPublic: true,
  },

  {
    id: 'fb-30',
    intern: {
      id: 'intern-29',
      name: 'Valentine Dumas',
      username: 'valentine_dumas_content',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez StartupX',
    },
    project: {
      id: 'proj-7',
      name: 'PayFast Integration',
      image: '/images/project-payment.jpg',
      companyId: 'comp-3',
    },
    company: {
      id: 'comp-3',
      name: 'StartupX',
      username: 'startup_x',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "Création de contenu vidéo et copywriting pour le lancement produit. Scripts, tournage, montage, publication... Contenu devenu viral avec 500K vues ! Startup ultra créative. ✍️",
    timestamp: new Date('2024-01-26T11:20:00'),
    likes: 198,
    liked: true,
    comments: [
      {
        id: 'c-30-1',
        author: 'Sarah Michel',
        text: 'Ton contenu était incroyable Valentine ! 🎉',
        avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
        likes: 15,
        liked: true,
        replies: [],
      },
    ],
    isPublic: true,
  },

  // Feedbacks 31-50 (continuation pour compléter les 50+)
  {
    id: 'fb-31',
    intern: {
      id: 'intern-1',
      name: 'Sophie Martin',
      username: 'sophie_martin_dev',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez Global Corp',
    },
    project: {
      id: 'proj-5',
      name: 'Supply Chain Optimizer',
      image: '/images/project-supply.jpg',
      companyId: 'comp-2',
    },
    company: {
      id: 'comp-2',
      name: 'Global Corp',
      username: 'global_corp',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "Après mon stage chez Tech Innov, j'ai continué avec Global Corp. Projet ambitieux d'optimisation logistique avec des algorithmes IA complexes. Équipe internationale top niveau !",
    timestamp: new Date('2024-02-16T10:00:00'),
    likes: 37,
    liked: false,
    comments: [],
    isPublic: true,
  },

  {
    id: 'fb-32',
    intern: {
      id: 'intern-2',
      name: 'Lucas Dubois',
      username: 'lucas_dubois_ai',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez Data Analytics Pro',
    },
    project: {
      id: 'proj-14',
      name: 'Customer Insights Platform',
      image: '/images/project-insights.jpg',
      companyId: 'comp-6',
    },
    company: {
      id: 'comp-6',
      name: 'Data Analytics Pro',
      username: 'data_analytics_pro',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "Analyse comportementale clients avec NLP et clustering. Modèles prédictifs qui ont augmenté la rétention de 25%. Data science appliquée au business, génial !",
    timestamp: new Date('2024-02-17T14:20:00'),
    likes: 63,
    liked: false,
    comments: [],
    isPublic: true,
  },

  // ... Continuons avec les 18 derniers feedbacks
  {
    id: 'fb-33',
    intern: {
      id: 'intern-3',
      name: 'Marie Lefevre',
      username: 'marie_lefevre_ux',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez Mobile First Dev',
    },
    project: {
      id: 'proj-15',
      name: 'Fitness Tracker App',
      image: '/images/project-fitness.jpg',
      companyId: 'comp-7',
    },
    company: {
      id: 'comp-7',
      name: 'Mobile First Dev',
      username: 'mobile_first_dev',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "Design UX/UI d'une app fitness. User flows, wireframes, prototypes interactifs. Collaboration étroite avec les développeurs pour un résultat pixel-perfect. ✨",
    timestamp: new Date('2024-02-18T09:30:00'),
    likes: 76,
    liked: true,
    comments: [],
    isPublic: true,
  },

  {
    id: 'fb-34',
    intern: {
      id: 'intern-4',
      name: 'Thomas Bernard',
      username: 'thomas_bernard_mobile',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez EcoTech Solutions',
    },
    project: {
      id: 'proj-12',
      name: 'Green Energy Analytics',
      image: '/images/project-green.jpg',
      companyId: 'comp-5',
    },
    company: {
      id: 'comp-5',
      name: 'EcoTech Solutions',
      username: 'ecotech_solutions',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "App mobile pour le suivi de consommation énergétique. Flutter multi-plateformes, graphiques temps réel. Contribuer à l'écologie par la tech, c'est motivant ! 🌱",
    timestamp: new Date('2024-02-19T11:00:00'),
    likes: 54,
    liked: false,
    comments: [],
    isPublic: true,
  },

  {
    id: 'fb-35',
    intern: {
      id: 'intern-5',
      name: 'Emma Rousseau',
      username: 'emma_rousseau_data',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez EcoTech Solutions',
    },
    project: {
      id: 'proj-11',
      name: 'Solar Panel Monitor',
      image: '/images/project-solar.jpg',
      companyId: 'comp-5',
    },
    company: {
      id: 'comp-5',
      name: 'EcoTech Solutions',
      username: 'ecotech_solutions',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "Analyse de données des panneaux solaires pour optimiser la production. ETL, dashboards, alertes automatiques. Mission à impact positif pour la planète !",
    timestamp: new Date('2024-02-20T13:45:00'),
    likes: 48,
    liked: false,
    comments: [],
    isPublic: true,
  },

  {
    id: 'fb-36',
    intern: {
      id: 'intern-6',
      name: 'Julien Moreau',
      username: 'julien_moreau_devops',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez Tech Innov S.A.',
    },
    project: {
      id: 'proj-2',
      name: 'SmartAI Dashboard',
      image: '/images/project-ai.jpg',
      companyId: 'comp-1',
    },
    company: {
      id: 'comp-1',
      name: 'Tech Innov S.A.',
      username: 'tech_innov_sa',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "Infrastructure DevOps pour dashboard IA. Pipelines CI/CD, monitoring, scaling automatique. Tech de pointe et équipe soudée. Expérience exceptionnelle !",
    timestamp: new Date('2024-02-21T10:30:00'),
    likes: 57,
    liked: false,
    comments: [],
    isPublic: true,
  },

  {
    id: 'fb-37',
    intern: {
      id: 'intern-7',
      name: 'Chloé Petit',
      username: 'chloe_petit_frontend',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez StartupX',
    },
    project: {
      id: 'proj-6',
      name: 'CryptoWallet Pro',
      image: '/images/project-crypto.jpg',
      companyId: 'comp-3',
    },
    company: {
      id: 'comp-3',
      name: 'StartupX',
      username: 'startup_x',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "Interface moderne pour wallet crypto. Vue.js, animations, gestion d'état complexe. Environnement startup dynamique avec beaucoup d'autonomie !",
    timestamp: new Date('2024-02-22T14:00:00'),
    likes: 69,
    liked: false,
    comments: [],
    isPublic: true,
  },

  {
    id: 'fb-38',
    intern: {
      id: 'intern-8',
      name: 'Antoine Garcia',
      username: 'antoine_garcia_backend',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez Data Analytics Pro',
    },
    project: {
      id: 'proj-13',
      name: 'Predictive Maintenance AI',
      image: '/images/project-maintenance.jpg',
      companyId: 'comp-6',
    },
    company: {
      id: 'comp-6',
      name: 'Data Analytics Pro',
      username: 'data_analytics_pro',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "Backend pour IA de maintenance prédictive. API Java Spring, intégration modèles ML, traitement temps réel. Projet technique de haut niveau !",
    timestamp: new Date('2024-02-23T09:15:00'),
    likes: 43,
    liked: false,
    comments: [],
    isPublic: true,
  },

  {
    id: 'fb-39',
    intern: {
      id: 'intern-9',
      name: 'Léa Roux',
      username: 'lea_roux_product',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez Mobile First Dev',
    },
    project: {
      id: 'proj-16',
      name: 'Social Network Lite',
      image: '/images/project-social.jpg',
      companyId: 'comp-7',
    },
    company: {
      id: 'comp-7',
      name: 'Mobile First Dev',
      username: 'mobile_first_dev',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "Product management d'un réseau social mobile. User stories, priorisation features, A/B tests. J'ai adoré travailler entre tech et business !",
    timestamp: new Date('2024-02-24T11:45:00'),
    likes: 52,
    liked: false,
    comments: [],
    isPublic: true,
  },

  {
    id: 'fb-40',
    intern: {
      id: 'intern-10',
      name: 'Hugo Durand',
      username: 'hugo_durand_cyber',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez Tech Innov S.A.',
    },
    project: {
      id: 'proj-1',
      name: 'Quantum Leap Platform',
      image: '/images/project-quantum.jpg',
      companyId: 'comp-1',
    },
    company: {
      id: 'comp-1',
      name: 'Tech Innov S.A.',
      username: 'tech_innov_sa',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "Sécurisation d'une plateforme cloud critque. Pentests, audits, mise en place de pare-feu. Responsabilités importantes et apprentissage accéléré ! 🔐",
    timestamp: new Date('2024-02-25T15:30:00'),
    likes: 61,
    liked: false,
    comments: [],
    isPublic: true,
  },

  {
    id: 'fb-41',
    intern: {
      id: 'intern-11',
      name: 'Camille Laurent',
      username: 'camille_laurent_qa',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez Gaming Studio FR',
    },
    project: {
      id: 'proj-19',
      name: 'Fantasy RPG Quest',
      image: '/images/project-rpg.jpg',
      companyId: 'comp-9',
    },
    company: {
      id: 'comp-9',
      name: 'Gaming Studio FR',
      username: 'gaming_studio_fr',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "QA sur un jeu RPG ! Tests fonctionnels, détection de bugs, automation avec Unity Test Framework. Travailler dans le gaming était un rêve ! 🎮",
    timestamp: new Date('2024-02-26T10:00:00'),
    likes: 95,
    liked: true,
    comments: [],
    isPublic: true,
  },

  {
    id: 'fb-42',
    intern: {
      id: 'intern-12',
      name: 'Maxime Vincent',
      username: 'maxime_vincent_game',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez Gaming Studio FR',
    },
    project: {
      id: 'proj-20',
      name: 'Mobile Puzzle Game',
      image: '/images/project-puzzle.jpg',
      companyId: 'comp-9',
    },
    company: {
      id: 'comp-9',
      name: 'Gaming Studio FR',
      username: 'gaming_studio_fr',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "Développement d'un jeu puzzle addictif. Unity, level design, monétisation. Le jeu a atteint 100K téléchargements en 1 mois ! Fierté immense.",
    timestamp: new Date('2024-02-27T13:20:00'),
    likes: 142,
    liked: true,
    comments: [],
    isPublic: true,
  },

  {
    id: 'fb-43',
    intern: {
      id: 'intern-13',
      name: 'Lisa Mercier',
      username: 'lisa_mercier_cloud',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez Tech Innov S.A.',
    },
    project: {
      id: 'proj-3',
      name: 'Enterprise Mobile Suite',
      image: '/images/project-mobile.jpg',
      companyId: 'comp-1',
    },
    company: {
      id: 'comp-1',
      name: 'Tech Innov S.A.',
      username: 'tech_innov_sa',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "Architecture cloud pour suite mobile enterprise. AWS, microservices, scalabilité. J'ai validé mes certifications AWS Solutions Architect ! ☁️",
    timestamp: new Date('2024-02-28T09:45:00'),
    likes: 58,
    liked: false,
    comments: [],
    isPublic: true,
  },

  {
    id: 'fb-44',
    intern: {
      id: 'intern-14',
      name: 'Nathan Simon',
      username: 'nathan_simon_blockchain',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez Data Analytics Pro',
    },
    project: {
      id: 'proj-14',
      name: 'Customer Insights Platform',
      image: '/images/project-insights.jpg',
      companyId: 'comp-6',
    },
    company: {
      id: 'comp-6',
      name: 'Data Analytics Pro',
      username: 'data_analytics_pro',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "Intégration blockchain pour traçabilité des données clients. Smart contracts, IPFS, cryptographie. Combiner blockchain et analytics était fascinant !",
    timestamp: new Date('2024-03-01T11:30:00'),
    likes: 72,
    liked: false,
    comments: [],
    isPublic: true,
  },

  {
    id: 'fb-45',
    intern: {
      id: 'intern-15',
      name: 'Sarah Michel',
      username: 'sarah_michel_marketing',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez Digital Factory',
    },
    project: {
      id: 'proj-8',
      name: 'Luxury Brand Website',
      image: '/images/project-luxury.jpg',
      companyId: 'comp-4',
    },
    company: {
      id: 'comp-4',
      name: 'Digital Factory',
      username: 'digital_factory',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "Stratégie marketing digital pour marque de luxe. Campagnes Instagram, influenceurs, storytelling premium. ROI exceptionnel de 400% ! 📈",
    timestamp: new Date('2024-03-02T14:15:00'),
    likes: 86,
    liked: true,
    comments: [],
    isPublic: true,
  },

  {
    id: 'fb-46',
    intern: {
      id: 'intern-16',
      name: 'Pierre Fontaine',
      username: 'pierre_fontaine_sysadmin',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez Cyber Security Experts',
    },
    project: {
      id: 'proj-21',
      name: 'Threat Detection System',
      image: '/images/project-threat.jpg',
      companyId: 'comp-10',
    },
    company: {
      id: 'comp-10',
      name: 'Cyber Security Experts',
      username: 'cyber_security_experts',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "Administration des serveurs de sécurité. Linux hardening, scripts de surveillance, gestion des incidents. Environnement exigeant mais formateur !",
    timestamp: new Date('2024-03-03T10:00:00'),
    likes: 44,
    liked: false,
    comments: [],
    isPublic: true,
  },

  {
    id: 'fb-47',
    intern: {
      id: 'intern-17',
      name: 'Clara Robin',
      username: 'clara_robin_design',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez EcoTech Solutions',
    },
    project: {
      id: 'proj-11',
      name: 'Solar Panel Monitor',
      image: '/images/project-solar.jpg',
      companyId: 'comp-5',
    },
    company: {
      id: 'comp-5',
      name: 'EcoTech Solutions',
      username: 'ecotech_solutions',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "Design graphique pour application monitoring solaire. Branding, iconographie, illustrations. Contribuer à l'énergie verte par le design ! 🎨",
    timestamp: new Date('2024-03-04T12:45:00'),
    likes: 67,
    liked: false,
    comments: [],
    isPublic: true,
  },

  {
    id: 'fb-48',
    intern: {
      id: 'intern-18',
      name: 'Arthur Bonnet',
      username: 'arthur_bonnet_embedded',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez EcoTech Solutions',
    },
    project: {
      id: 'proj-12',
      name: 'Green Energy Analytics',
      image: '/images/project-green.jpg',
      companyId: 'comp-5',
    },
    company: {
      id: 'comp-5',
      name: 'EcoTech Solutions',
      username: 'ecotech_solutions',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "Systèmes embarqués pour collecte de données énergétiques. Capteurs IoT, protocoles MQTT, edge computing. Tech de pointe pour l'écologie !",
    timestamp: new Date('2024-03-05T09:30:00'),
    likes: 53,
    liked: false,
    comments: [],
    isPublic: true,
  },

  {
    id: 'fb-49',
    intern: {
      id: 'intern-19',
      name: 'Élise Lambert',
      username: 'elise_lambert_pm',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez Tech Innov S.A.',
    },
    project: {
      id: 'proj-2',
      name: 'SmartAI Dashboard',
      image: '/images/project-ai.jpg',
      companyId: 'comp-1',
    },
    company: {
      id: 'comp-1',
      name: 'Tech Innov S.A.',
      username: 'tech_innov_sa',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "Gestion de projet complexe dashboard IA. Coordination équipes multiples, gestion des risques, reporting exécutif. Métier passionnant et stratégique !",
    timestamp: new Date('2024-03-06T13:00:00'),
    likes: 71,
    liked: false,
    comments: [],
    isPublic: true,
  },

  {
    id: 'fb-50',
    intern: {
      id: 'intern-20',
      name: 'Romain Girard',
      username: 'romain_girard_ml',
      avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
      role: 'Stagiaire chez Tech Innov S.A.',
    },
    project: {
      id: 'proj-1',
      name: 'Quantum Leap Platform',
      image: '/images/project-quantum.jpg',
      companyId: 'comp-1',
    },
    company: {
      id: 'comp-1',
      name: 'Tech Innov S.A.',
      username: 'tech_innov_sa',
      logo: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    },
    content:
      "Machine learning pour optimisation cloud. Prédiction de charge, auto-scaling intelligent, réduction coûts de 30%. ML appliqué à l'infrastructure, génial !",
    timestamp: new Date('2024-03-07T10:45:00'),
    likes: 94,
    liked: true,
    comments: [],
    isPublic: true,
  },
];

// ============================================================================
// DONNÉES MOCK - SUGGESTIONS (20+)
// ============================================================================

export const mockSuggestions: SuggestionData[] = [
  {
    id: 'sug-1',
    name: 'Sophie Martin',
    username: 'sophie_martin_dev',
    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
    bio: 'Développeuse Full-stack passionnée | React & Node.js',
    followers: 342,
    isFollowing: false,
    type: 'intern',
  },
  {
    id: 'sug-2',
    name: 'Tech Innov S.A.',
    username: 'tech_innov_sa',
    avatar: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    bio: 'Leader de l\'innovation en solutions logicielles',
    followers: 5420,
    isFollowing: false,
    type: 'company',
  },
  {
    id: 'sug-3',
    name: 'Marie Lefevre',
    username: 'marie_lefevre_ux',
    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
    bio: 'Designer UX/UI créative | Figma addict ✨',
    followers: 892,
    isFollowing: true,
    type: 'intern',
  },
  {
    id: 'sug-4',
    name: 'Global Corp',
    username: 'global_corp',
    avatar: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    bio: 'Solutions mondiales pour les entreprises du Fortune 500',
    followers: 8920,
    isFollowing: false,
    type: 'company',
  },
  {
    id: 'sug-5',
    name: 'Lucas Dubois',
    username: 'lucas_dubois_ai',
    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
    bio: 'Ingénieur IA | Passionné par le Machine Learning 🤖',
    followers: 567,
    isFollowing: false,
    type: 'intern',
  },
  {
    id: 'sug-6',
    name: 'StartupX',
    username: 'startup_x',
    avatar: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    bio: 'Startup innovante dans la fintech 🚀',
    followers: 1250,
    isFollowing: false,
    type: 'company',
  },
  {
    id: 'sug-7',
    name: 'Thomas Bernard',
    username: 'thomas_bernard_mobile',
    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
    bio: 'Développeur mobile iOS & Android | Swift, Kotlin',
    followers: 421,
    isFollowing: false,
    type: 'intern',
  },
  {
    id: 'sug-8',
    name: 'Digital Factory',
    username: 'digital_factory',
    avatar: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    bio: 'Agence digitale créative spécialisée en UX/UI',
    followers: 3680,
    isFollowing: true,
    type: 'company',
  },
  {
    id: 'sug-9',
    name: 'Emma Rousseau',
    username: 'emma_rousseau_data',
    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
    bio: 'Analyste de données | Python & SQL expert 📊',
    followers: 654,
    isFollowing: false,
    type: 'intern',
  },
  {
    id: 'sug-10',
    name: 'Cloud Masters',
    username: 'cloud_masters',
    avatar: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    bio: 'Infrastructure cloud et DevOps excellence',
    followers: 6890,
    isFollowing: false,
    type: 'company',
  },
  {
    id: 'sug-11',
    name: 'Julien Moreau',
    username: 'julien_moreau_devops',
    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
    bio: 'DevOps Engineer | Kubernetes & Docker 🚀',
    followers: 789,
    isFollowing: true,
    type: 'intern',
  },
  {
    id: 'sug-12',
    name: 'Gaming Studio FR',
    username: 'gaming_studio_fr',
    avatar: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    bio: 'Studio de développement de jeux vidéo indépendant 🎮',
    followers: 12450,
    isFollowing: false,
    type: 'company',
  },
  {
    id: 'sug-13',
    name: 'Chloé Petit',
    username: 'chloe_petit_frontend',
    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
    bio: 'Frontend Developer | Vue.js & Tailwind CSS 💅',
    followers: 512,
    isFollowing: false,
    type: 'intern',
  },
  {
    id: 'sug-14',
    name: 'EcoTech Solutions',
    username: 'ecotech_solutions',
    avatar: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    bio: 'Technologies vertes pour un avenir durable 🌱',
    followers: 2890,
    isFollowing: false,
    type: 'company',
  },
  {
    id: 'sug-15',
    name: 'Maxime Vincent',
    username: 'maxime_vincent_game',
    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
    bio: 'Game Developer | Unity & C# 🎮',
    followers: 1567,
    isFollowing: true,
    type: 'intern',
  },
  {
    id: 'sug-16',
    name: 'Cyber Security Experts',
    username: 'cyber_security_experts',
    avatar: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    bio: 'Protection avancée contre les cybermenaces 🔒',
    followers: 7230,
    isFollowing: false,
    type: 'company',
  },
  {
    id: 'sug-17',
    name: 'Léa Roux',
    username: 'lea_roux_product',
    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
    bio: 'Product Manager junior | Agile & Scrum',
    followers: 1123,
    isFollowing: false,
    type: 'intern',
  },
  {
    id: 'sug-18',
    name: 'Mobile First Dev',
    username: 'mobile_first_dev',
    avatar: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    bio: 'Développement d\'applications mobiles iOS et Android',
    followers: 5670,
    isFollowing: false,
    type: 'company',
  },
  {
    id: 'sug-19',
    name: 'Romain Girard',
    username: 'romain_girard_ml',
    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
    bio: 'Machine Learning Engineer | TensorFlow & PyTorch',
    followers: 1892,
    isFollowing: true,
    type: 'intern',
  },
  {
    id: 'sug-20',
    name: 'Data Analytics Pro',
    username: 'data_analytics_pro',
    avatar: 'https://i.ibb.co/6P8N9zR/company-logo.png',
    bio: 'Experts en analyse de données et intelligence artificielle',
    followers: 4120,
    isFollowing: false,
    type: 'company',
  },
  {
    id: 'sug-21',
    name: 'Sarah Michel',
    username: 'sarah_michel_marketing',
    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
    bio: 'Digital Marketing | SEO & Content Strategy 📈',
    followers: 1234,
    isFollowing: false,
    type: 'intern',
  },
  {
    id: 'sug-22',
    name: 'Hugo Durand',
    username: 'hugo_durand_cyber',
    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
    bio: 'Cybersecurity specialist | Ethical hacker 🔐',
    followers: 934,
    isFollowing: false,
    type: 'intern',
  },
  {
    id: 'sug-23',
    name: 'Lisa Mercier',
    username: 'lisa_mercier_cloud',
    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
    bio: 'Cloud Architect | AWS & Azure certifiée ☁️',
    followers: 712,
    isFollowing: false,
    type: 'intern',
  },
  {
    id: 'sug-24',
    name: 'Valentine Dumas',
    username: 'valentine_dumas_content',
    avatar: 'https://i.ibb.co/Qf983vG/avatar-placeholder.png',
    bio: 'Content Creator | Vidéo & Copywriting ✍️',
    followers: 2134,
    isFollowing: true,
    type: 'intern',
  },
];

// ============================================================================
// FONCTIONS UTILITAIRES
// ============================================================================

// Obtenir une entreprise par ID
export function getCompanyById(companyId: string): Company | undefined {
  return mockCompanies.find((c) => c.id === companyId);
}

// Obtenir un projet par ID
export function getProjectById(projectId: string): Project | undefined {
  return mockProjects.find((p) => p.id === projectId);
}

// Obtenir un stagiaire par ID
export function getInternById(internId: string): Intern | undefined {
  return mockInterns.find((i) => i.id === internId);
}

// Obtenir tous les projets d'une entreprise
export function getProjectsByCompanyId(companyId: string): Project[] {
  return mockProjects.filter((p) => p.companyId === companyId);
}

// Obtenir tous les feedbacks d'un projet
export function getFeedbacksByProjectId(projectId: string): FeedbackData[] {
  return mockFeedbacks.filter((f) => f.project.id === projectId);
}

// Obtenir tous les feedbacks d'une entreprise
export function getFeedbacksByCompanyId(companyId: string): FeedbackData[] {
  return mockFeedbacks.filter((f) => f.company.id === companyId);
}

// Obtenir tous les feedbacks d'un stagiaire
export function getFeedbacksByInternId(internId: string): FeedbackData[] {
  return mockFeedbacks.filter((f) => f.intern.id === internId);
}

// Obtenir les feedbacks récents (triés par date décroissante)
export function getRecentFeedbacks(limit?: number): FeedbackData[] {
  const sorted = [...mockFeedbacks].sort(
    (a, b) => b.timestamp.getTime() - a.timestamp.getTime()
  );
  return limit ? sorted.slice(0, limit) : sorted;
}

// Obtenir des suggestions aléatoires
export function getRandomSuggestions(count: number = 6): SuggestionData[] {
  const shuffled = [...mockSuggestions].sort(() => 0.5 - Math.random());
  return shuffled.slice(0, count);
}
