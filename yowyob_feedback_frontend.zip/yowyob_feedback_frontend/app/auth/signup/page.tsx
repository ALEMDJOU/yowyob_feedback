"use client"
import React, { useState, ChangeEvent } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { motion, AnimatePresence } from 'framer-motion';
import { authService } from '@/lib/services';
import { UserType, RegisterRequestDTO } from '@/lib/types/api';
import { useRouter } from 'next/navigation';
import { supabase } from '@/lib/supabase';

export default function SignupPage() {
    const router = useRouter();
    const [userType, setUserType] = useState<UserType>(UserType.PERSON);
    const [uploading, setUploading] = useState(false);
    const [showPassword, setShowPassword] = useState(false);
    const [confirmPassword, setConfirmPassword] = useState('');
    
    const [formData, setFormData] = useState<Partial<RegisterRequestDTO>>({
        user_type: UserType.PERSON,
        email: '',
        password: '',
        contact: '',
        user_firstname: '',
        user_lastname: '',
        occupation: '',
        organization_name: '',
        user_logo: '',
        location: ''
    });

    const [error, setError] = useState<string | null>(null);
    const [loading, setLoading] = useState(false);

    // Animations Variants
    const containerVariants = {
        hidden: { opacity: 0, scale: 0.98 },
        visible: { 
            opacity: 1, 
            scale: 1,
            transition: { duration: 0.4, staggerChildren: 0.05 } 
        }
    };

    const itemVariants = {
        hidden: { opacity: 0, y: 15 },
        visible: { opacity: 1, y: 0 }
    };

    const handleInputChange = (field: keyof RegisterRequestDTO, value: any) => {
        setFormData(prev => ({ ...prev, [field]: value }));
    };

    const handleImageUpload = async (e: ChangeEvent<HTMLInputElement>) => {
        try {
            setUploading(true);
            setError(null);
            if (!e.target.files || e.target.files.length === 0) return;
            const file = e.target.files[0];
            const filePath = `profiles/${Date.now()}-${file.name}`;
            const { error: uploadError } = await supabase.storage.from('yowyob_feedback').upload(filePath, file);
            if (uploadError) throw uploadError;
            const { data } = supabase.storage.from('yowyob_feedback').getPublicUrl(filePath);
            handleInputChange('user_logo', data.publicUrl);
        } catch (err: any) {
            setError("Erreur upload image: " + err.message);
        } finally {
            setUploading(false);
        }
    };

    const handleSignup = async (e: React.FormEvent) => {
        e.preventDefault();
        setError(null);
        if (formData.password !== confirmPassword) return setError("Les mots de passe ne correspondent pas.");
        setLoading(true);
        try {
            await authService.register(formData as RegisterRequestDTO);
            router.push('/dashboard/feed');
        } catch (err: any) {
            setError(err.message || 'Erreur lors de l\'inscription.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="auth-page" style={{ backgroundColor: '#f0f2f5', minHeight: '100vh', padding: '40px 20px' }}>
            <motion.div 
                variants={containerVariants}
                initial="hidden"
                animate="visible"
                className="auth-card" 
                style={{ 
                    maxWidth: '700px', 
                    margin: '0 auto', 
                    padding: '40px', 
                    boxShadow: '0 10px 30px rgba(0,0,0,0.08)', 
                    borderRadius: '16px', 
                    backgroundColor: '#fff' 
                }}
            >
                <motion.div variants={itemVariants} style={{ textAlign: 'center', marginBottom: '30px' }}>
                    <motion.div whileHover={{ rotate: 10 }}>
                        <Image src="/images/logo.jpg" alt="Logo" width={80} height={80} style={{ borderRadius: '50%' }} />
                    </motion.div>
                    <h2 style={{ color: '#6A1B9A', marginTop: '15px', fontWeight: '800' }}>Rejoignez l'aventure</h2>
                    <p style={{ color: '#888' }}>Créez votre profil en quelques secondes</p>
                </motion.div>

                <AnimatePresence>
                    {error && (
                        <motion.div 
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: 'auto' }}
                            exit={{ opacity: 0, height: 0 }}
                            style={{ overflow: 'hidden' }}
                        >
                            <div style={{ color: '#D32F2F', backgroundColor: '#FFEBEE', padding: '12px', borderRadius: '8px', marginBottom: '20px', fontSize: '0.9em', border: '1px solid #FFCDD2' }}>
                                ⚠️ {error}
                            </div>
                        </motion.div>
                    )}
                </AnimatePresence>

                <form onSubmit={handleSignup}>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
                        
                        <motion.div variants={itemVariants} style={{ gridColumn: 'span 2' }}>
                            <label style={{ display: 'block', marginBottom: '8px', fontWeight: '600', color: '#444' }}>Type de compte</label>
                            <select 
                                className="auth-form-control" 
                                style={{ width: '100%', padding: '12px', borderRadius: '8px', border: '2px solid #eee', outline: 'none', transition: 'border-color 0.3s' }}
                                value={userType} 
                                onChange={(e) => {
                                    const val = e.target.value as UserType;
                                    setUserType(val);
                                    handleInputChange('user_type', val);
                                }}
                            >
                                <option value={UserType.PERSON}>👤 Particulier</option>
                                <option value={UserType.ORGANIZATION}>🏢 Entreprise / Organisation</option>
                            </select>
                        </motion.div>

                        {/* CHAMPS DYNAMIQUES AVEC ANIMATION DE PRÉSENCE */}
                        <motion.div variants={itemVariants} style={{ gridColumn: userType === UserType.ORGANIZATION ? 'span 2' : 'auto' }}>
                            <label style={{ display: 'block', marginBottom: '5px', fontWeight: '600' }}>
                                {userType === UserType.PERSON ? "Prénom" : "Prénom du responsable"}
                            </label>
                            <input type="text" className="auth-form-control" style={{ width: '100%', padding: '12px', borderRadius: '8px', border: '1px solid #ddd' }} onChange={(e) => handleInputChange('user_firstname', e.target.value)} required />
                        </motion.div>

                        <motion.div variants={itemVariants}>
                            <label style={{ display: 'block', marginBottom: '5px', fontWeight: '600' }}>
                                {userType === UserType.PERSON ? "Nom" : "Nom du responsable"}
                            </label>
                            <input type="text" className="auth-form-control" style={{ width: '100%', padding: '12px', borderRadius: '8px', border: '1px solid #ddd' }} onChange={(e) => handleInputChange('user_lastname', e.target.value)} required />
                        </motion.div>

                        <AnimatePresence mode="popLayout">
                            {userType === UserType.ORGANIZATION && (
                                <motion.div 
                                    initial={{ opacity: 0, y: -10 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    exit={{ opacity: 0, y: -10 }}
                                    style={{ gridColumn: 'span 2' }}
                                >
                                    <label style={{ display: 'block', marginBottom: '5px', fontWeight: '600' }}>Nom de l'organisation</label>
                                    <input type="text" className="auth-form-control" style={{ width: '100%', padding: '12px', borderRadius: '8px', border: '1px solid #ddd' }} onChange={(e) => handleInputChange('organization_name', e.target.value)} required />
                                </motion.div>
                            )}
                        </AnimatePresence>

                        <motion.div variants={itemVariants} style={{ gridColumn: 'span 2' }}>
                            <label style={{ display: 'block', marginBottom: '5px', fontWeight: '600' }}>📍 Localisation</label>
                            <input type="text" className="auth-form-control" placeholder="Ex: Douala, Cameroun" style={{ width: '100%', padding: '12px', borderRadius: '8px', border: '1px solid #ddd' }} onChange={(e) => handleInputChange('location', e.target.value)} required />
                        </motion.div>

                        <motion.div variants={itemVariants}>
                            <label style={{ display: 'block', marginBottom: '5px', fontWeight: '600' }}>Email</label>
                            <input type="email" className="auth-form-control" placeholder="votre@mail.com" style={{ width: '100%', padding: '12px', borderRadius: '8px', border: '1px solid #ddd' }} onChange={(e) => handleInputChange('email', e.target.value)} required />
                        </motion.div>

                        <motion.div variants={itemVariants}>
                            <label style={{ display: 'block', marginBottom: '5px', fontWeight: '600' }}>Téléphone</label>
                            <input type="text" className="auth-form-control" style={{ width: '100%', padding: '12px', borderRadius: '8px', border: '1px solid #ddd' }} onChange={(e) => handleInputChange('contact', e.target.value)} required />
                        </motion.div>

                        <motion.div variants={itemVariants} style={{ gridColumn: 'span 2' }}>
                            <label style={{ display: 'block', marginBottom: '5px', fontWeight: '600' }}>🖼️ Photo / Logo</label>
                            <div style={{ position: 'relative', width: '100%' }}>
                                <input type="file" accept="image/*" onChange={handleImageUpload} style={{ width: '100%', padding: '10px', backgroundColor: '#f9f9f9', borderRadius: '8px', border: '1px dashed #ccc' }} />
                                {uploading && (
                                    <motion.div 
                                        animate={{ opacity: [0.5, 1, 0.5] }} 
                                        transition={{ repeat: Infinity, duration: 1.5 }}
                                        style={{ color: '#6A1B9A', fontSize: '0.8em', marginTop: '5px' }}
                                    >
                                        ⏳ Téléchargement du logo...
                                    </motion.div>
                                )}
                            </div>
                        </motion.div>

                        <motion.div variants={itemVariants}>
                            <label style={{ display: 'block', marginBottom: '5px', fontWeight: '600' }}>Mot de passe</label>
                            <div style={{ position: 'relative' }}>
                                <input type={showPassword ? "text" : "password"} className="auth-form-control" style={{ width: '100%', padding: '12px', borderRadius: '8px', border: '1px solid #ddd' }} onChange={(e) => handleInputChange('password', e.target.value)} required />
                                <span onClick={() => setShowPassword(!showPassword)} style={{ position: 'absolute', right: '12px', top: '50%', transform: 'translateY(-50%)', cursor: 'pointer' }}>
                                    {showPassword ? '🙈' : '👁️'}
                                </span>
                            </div>
                        </motion.div>

                        <motion.div variants={itemVariants}>
                            <label style={{ display: 'block', marginBottom: '5px', fontWeight: '600' }}>Confirmer</label>
                            <input type={showPassword ? "text" : "password"} className="auth-form-control" style={{ width: '100%', padding: '12px', borderRadius: '8px', border: '1px solid #ddd' }} value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} required />
                        </motion.div>

                        <AnimatePresence>
                            {userType === UserType.PERSON && (
                                <motion.div 
                                    initial={{ opacity: 0, x: -20 }}
                                    animate={{ opacity: 1, x: 0 }}
                                    exit={{ opacity: 0, x: 20 }}
                                    style={{ gridColumn: 'span 2' }}
                                >
                                    <label style={{ display: 'block', marginBottom: '5px', fontWeight: '600' }}>💼 Occupation</label>
                                    <input type="text" className="auth-form-control" style={{ width: '100%', padding: '12px', borderRadius: '8px', border: '1px solid #ddd' }} placeholder="Ex: Étudiant, Ingénieur..." onChange={(e) => handleInputChange('occupation', e.target.value)} required />
                                </motion.div>
                            )}
                        </AnimatePresence>
                    </div>

                    <motion.button 
                        variants={itemVariants}
                        whileHover={{ scale: 1.02, backgroundColor: '#4A148C' }}
                        whileTap={{ scale: 0.98 }}
                        type="submit" 
                        className="btn btn-primary" 
                        style={{ 
                            width: '100%', 
                            padding: '16px', 
                            marginTop: '30px', 
                            backgroundColor: '#6A1B9A', 
                            color: 'white', 
                            border: 'none', 
                            borderRadius: '10px', 
                            cursor: 'pointer', 
                            fontWeight: 'bold',
                            fontSize: '1.1em',
                            boxShadow: '0 4px 15px rgba(106, 27, 154, 0.3)'
                        }} 
                        disabled={loading || uploading}
                    >
                        {loading ? '🚀 Création en cours...' : 'Finaliser mon inscription'}
                    </motion.button>
                </form>

                <motion.div variants={itemVariants} style={{ marginTop: '25px', textAlign: 'center', color: '#666' }}>
                    Déjà un compte ? <Link href="/auth/login" style={{ color: '#6A1B9A', fontWeight: '800', textDecoration: 'none' }}>Connectez-vous</Link>
                </motion.div>
            </motion.div>
        </div>
    );
}